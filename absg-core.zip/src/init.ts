import { getConnection, getRepository } from "typeorm";
import { Fleet, VehicleType, MissionType, Vehicle, Mission, MissionExpectation, Equipment, TransportOrder, User }  from "./entities";
import { VehicleStatus } from "./entities/VehicleStatus";
import { Squad } from "./entities/Squad";
import { Regiment } from "./entities/Regiment";
import { Driver } from "./entities/Driver";
import { Part } from "./entities/Part";
import { MissionStatus } from "./entities/MissionStatus";
import * as D from './data/data';
import { MaintenancePlan } from "./entities/MaintenancePlan";
import { MaintenanceOperation } from "./entities/MaintenanceOperation";
import { Issue } from "./entities/Issue";

export class Init {

    async initData(init = false, clear = false, cleanHums = false) {
        if (clear) {
            console.info('Clear all data...');
            await this.clearAll();
        }
        if (cleanHums) {
            console.info('Clean HUMS data...');
            await this.cleanHums();
        }
        if (init) {
            console.info('Init data...');
            await this.initFleets();
            await this.initDrivers();
            await this.initSquads();
            await this.initParts();
            await this.initEquipments();
            await this.initVehicles();
            await this.initMissions();
            await this.initMaintenance();
            await this.initIssues();
            await this.initUsers();
            console.info('Init done.');
        }
    }

    async cleanHums() {
        const connection = getConnection('hums');
        const entities = [
            "Odometre", "TransmissionCurrentGear", "batteryVoltage", "ambientAirTemperature", "barometricPressure", "engineCoolantTemperature",
            "engineFuelRate", "engineIntakeManifoldPressure", "engineFuelTemperature", "engineIntakeManifoldTemperature", "engineMomentaryOverspeedEnable",
            "engineOilPressure", "engineOilTemperature", "engineProtectionSystemHasShutdownEngine", "engineSpeed", "engineTotalFuelUsed",
            "engineTotalHoursOfOperation", "engineTotalRevolutions", "fanDriveState", "fuelLevel", "grade", "linearAccelerationX", "linearAccelerationZ",
            "linearAccelerationY", "location", "pitchAndRollVectorMagnitude", "pitch", "protectLamp", "roll", "ptoGovernorState", "retarderTorqueMode",
            "rmsLinearAccelerationX", "transmissionSelectedGear", "vehicle_Name", "wheelBasedVehicleSpeed", "yaw"
        ];
        for (const entity of entities) {
            await connection.query(`DELETE FROM "Vehicle_${entity}_Records" WHERE "vehicleName" != $1 OR "recordTime" > $2;`, ['Thales.CholetVehicle', 'NOW()']);
            await connection.query(`UPDATE "Vehicle_${entity}_Records" SET "vehicleName" = $1 WHERE "vehicleName" = $2;`, ['ZCNSM8845DP610527', 'Thales.CholetVehicle']);
        }
    }

    async clearAll() {
        const entities = (await getConnection().entityMetadatas).map(x => ({ name: x.name, tableName: x.tableName }));
        for (const entity of entities) {
            const repository = await getRepository(entity.name);
            await repository.query(`TRUNCATE TABLE "${entity.tableName}" CASCADE;`);
            if (entity.tableName !== 'vehicle_equipment' && entity.tableName !== 'vehicle_part') {
                await repository.query(`ALTER SEQUENCE ${entity.tableName}_id_seq RESTART WITH 1;`);
            }
        }
    }
    
    async insert(entity, items: any[]) {
        const data = [];
        for (let item of items) {
            const dataItem = await getRepository(entity).save(item);
            data.push(dataItem);
        }
        return data;
    }

    async initFleets() {
        await this.insert(Fleet, D.FLEETS);
    }

    async initDrivers() {
        await this.insert(Driver, D.DRIVERS);
    }

    async initSquads() {
        await this.insert(Regiment, D.REGIMENTS);

        D.SQUADS[0].regiment = D.REGIMENTS[0];
        D.SQUADS[1].regiment = D.REGIMENTS[0];
        D.SQUADS[2].regiment = D.REGIMENTS[0];
        D.SQUADS[3].regiment = D.REGIMENTS[1];
        await this.insert(Squad, D.SQUADS);
    }

    async initParts() {
        await this.insert(Part, D.PARTS);
    }

    async initEquipments() {
        await this.insert(Equipment, D.EQUIPMENTS);
    }

    async initVehicles() {
        await this.insert(VehicleType, D.VEHICLE_TYPES);
        await this.insert(VehicleStatus, D.VEHICLE_STATUS);

        for (let i = 0; i < D.VEHICLES.length; i++) {
            D.VEHICLES[i].type = D.VEHICLES[i].name.indexOf('NP') > -1 ? D.VEHICLE_TYPES[1] : D.VEHICLE_TYPES[0];
            D.VEHICLES[i].squad = D.SQUADS.find(s => s.name === D.VEHICLES[i].squad.name);
            D.VEHICLES[i].fleet = this.randomItem(D.FLEETS);
            D.VEHICLES[i].status = this.randomItem(D.VEHICLE_STATUS);
        }

        D.VEHICLES[0].fleet = D.FLEETS[0];
        D.VEHICLES[0].equipments.push(D.EQUIPMENTS[0]);
        D.VEHICLES[0].status = D.VEHICLE_STATUS[0];
        D.VEHICLES[0].parts.push(D.PARTS[0]);
        D.VEHICLES[0].parts.push(D.PARTS[1]);
        D.VEHICLES[0].parts.push(D.PARTS[2]);
        D.VEHICLES[0].parts.push(D.PARTS[3]);
        D.VEHICLES[0].parts.push(D.PARTS[4]);
        D.VEHICLES[0].parts.push(D.PARTS[5]);
        D.VEHICLES[0].parts.push(D.PARTS[6]);

        D.VEHICLES[1].fleet = D.FLEETS[0];
        D.VEHICLES[1].equipments.push(D.EQUIPMENTS[0]);
        D.VEHICLES[1].equipments.push(D.EQUIPMENTS[1]);
        D.VEHICLES[1].squad = D.SQUADS[0];
        D.VEHICLES[1].status = D.VEHICLE_STATUS[1];
        D.VEHICLES[1].parts.push(D.PARTS[0]);

        await this.insert(Vehicle, D.VEHICLES);
    }

    async initMissions() {
        await this.insert(MissionType, D.MISSION_TYPES);
        await this.insert(MissionStatus, D.MISSION_STATUS);

        D.MISSIONS[0].type = D.MISSION_TYPES[0];
        D.MISSIONS[0].regiment = D.REGIMENTS[0];
        D.MISSIONS[0].status = D.MISSION_STATUS[1];
        D.MISSIONS[1].type = D.MISSION_TYPES[0];
        D.MISSIONS[1].regiment = D.REGIMENTS[0];
        D.MISSIONS[1].status = D.MISSION_STATUS[2];
        D.MISSIONS[2].status = D.MISSION_STATUS[0];
        await this.insert(Mission, D.MISSIONS);

        D.MISSION_EXPECTATIONS[0].mission = D.MISSIONS[0];
        D.MISSION_EXPECTATIONS[0].vehicleType = D.VEHICLE_TYPES[0];
        D.MISSION_EXPECTATIONS[0].comments = '/!\ Important !';
        D.MISSION_EXPECTATIONS[1].mission = D.MISSIONS[0];
        D.MISSION_EXPECTATIONS[1].vehicleType = D.VEHICLE_TYPES[1];
        D.MISSION_EXPECTATIONS[2].mission = D.MISSIONS[1];
        D.MISSION_EXPECTATIONS[2].vehicleType = D.VEHICLE_TYPES[1];
        await this.insert(MissionExpectation, D.MISSION_EXPECTATIONS);

        D.TRANSPORT_ORDERS[0].mission = D.MISSIONS[1];
        D.TRANSPORT_ORDERS[0].vehicle = D.VEHICLES[1];
        D.TRANSPORT_ORDERS[0].driver1 = D.DRIVERS[0];
        D.TRANSPORT_ORDERS[0].driver2 = D.DRIVERS[1];
        await this.insert(TransportOrder, D.TRANSPORT_ORDERS);
    }

    async initMaintenance() {
        for (let i = 0; i < D.MAINTENANCE_PLANS.length; i++) {
            if (i < 20) {
                D.MAINTENANCE_PLANS[i].vehicleType = D.VEHICLE_TYPES[0];
            } else {
                D.MAINTENANCE_PLANS[i].vehicleType = D.VEHICLE_TYPES[1];
            }
        }
        await this.insert(MaintenancePlan, D.MAINTENANCE_PLANS);

        for (let i = 0; i < D.MAINTENANCE_OPERATIONS.length; i++) {
            let mpId = D.MAINTENANCE_OPERATIONS[i].maintenancePlan.id;
            let vPlate = D.MAINTENANCE_OPERATIONS[i].vehicle.plate;
            (D.MAINTENANCE_OPERATIONS[i].maintenancePlan as any) = D.MAINTENANCE_PLANS.find(mp => mp['id'] === mpId);
            (D.MAINTENANCE_OPERATIONS[i].vehicle as any) = D.VEHICLES.find(v => v['plate'].replace(/\s/g, '') === vPlate);
        }
        await this.insert(MaintenanceOperation, D.MAINTENANCE_OPERATIONS);
    }

    async initIssues() {
        for (let i = 0; i < D.ISSUES.length; i++) {
            const plate = D.ISSUES[i].vehiclePlate.replace(/\s/g, '');
            const vehicle = D.VEHICLES.find(v => v['plate'].replace(/\s/g, '') === plate);
            if (vehicle) {
                D.ISSUES[i].vehicle = vehicle;
            } else {
                delete D.ISSUES[i];
            }
        }
        await this.insert(Issue, D.ISSUES.filter(Boolean));
    }

    async initUsers() {
        await this.insert(User, D.USERS);
    }

    randomItem(arr: any[], nullable = true) {
        return (nullable && Math.random() < 0.5)
        ? null 
        : arr[Math.floor(Math.random() * arr.length)];
    }

}