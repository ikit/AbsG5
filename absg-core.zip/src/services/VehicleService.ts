import { getRepository } from "typeorm";
import { differenceInMonths } from "date-fns";
import { Vehicle, Mission } from "../entities";
import { HumsService } from "./HumsService";

export class VehicleService {

    private humsService = new HumsService();

    /**
     * Calcul le pourcentage d'utilisation du véhicule
     * @param vehicleId 
     */
    async getVehicleUsage(vehicleId: number) {
        const vehicle = await getRepository(Vehicle).findOne(vehicleId);
        const missions = await getRepository(Mission).createQueryBuilder('mission')
            .leftJoinAndSelect("mission.transportOrders", "transportOrders")
            .leftJoinAndSelect("transportOrders.vehicle", "vehicle")
            .where('"vehicleId" = :vehicleId', { vehicleId })
            .getMany();

        if (!missions.length) {
            return null;
        }

        const nbMonthsOpintOrIdle = differenceInMonths(new Date(), vehicle.registrationDate);
        const nbMonthsOpex = missions
            .filter(m => m.destination === 'OPEX')
            .reduce((total, m) => total + differenceInMonths(m.departureDate, m.arrivalDate) || 1, 0);

        const totalDistanceOpex = nbMonthsOpex * vehicle.type.nominalDistanceOpexByMonth;
        const totalDistanceOpintOrIdle = (nbMonthsOpintOrIdle - nbMonthsOpex) * vehicle.type.nominalDistanceOpintByMonth;
        const totalDistance = totalDistanceOpex + totalDistanceOpintOrIdle;

        const odometre = await this.humsService.getLastValueOf('Odometre', vehicle.vinNumber);
        if (odometre) {
            const realDistance =  +odometre.value;
            const usage = realDistance * 100 / totalDistance;
            return { value: usage, time: odometre.time };
        } else {
            return null;
        }
    }
    
}