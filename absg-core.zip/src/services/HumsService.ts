import { getConnection, getRepository, Equal } from "typeorm";
import { format } from "date-fns";
import { Vehicle } from "../entities";

export class HumsService {

    private hums = getConnection('hums');
    private vehicleRepo = getRepository(Vehicle);

    async getHumsByVehicle(vehicleName: string) {
        // Health and usage monitoring systems (HUMS)
        const hums: any = {
            sensors: {},
            engine: {},
            fuel: {},
            gear: {},
            environment: {},
            distance: {},
            acceleration: {},
            lastUpdatedAt: null
        };
        
        const sensorsXYZ = await this.getLastValueOf('location', vehicleName);
        if (sensorsXYZ && sensorsXYZ.value) {
            const coords = sensorsXYZ.value.split(',');
            hums.sensors.x = { value: coords[0], time: sensorsXYZ.time };
            hums.sensors.y = { value: coords[1], time: sensorsXYZ.time };
            hums.sensors.z = { value: coords[2], time: sensorsXYZ.time };
        }
        hums.sensors.pitch = await this.getLastValueOf('pitch', vehicleName);
        hums.sensors.roll = await this.getLastValueOf('roll', vehicleName);
        hums.sensors.yaw = await this.getLastValueOf('yaw', vehicleName);
        hums.sensors.magnitude = await this.getLastValueOf('pitchAndRollVectorMagnitude', vehicleName);
        hums.sensors.grade = await this.getLastValueOf('grade', vehicleName);
        hums.engine.rpm = await this.getLastValueOf('engineSpeed', vehicleName);
        hums.engine.oil = await this.getLastValueOf('engineOilTemperature', vehicleName);
        hums.engine.coolant = await this.getLastValueOf('engineCoolantTemperature', vehicleName);
        hums.engine.hours = await this.getLastValueOf('engineTotalHoursOfOperation', vehicleName);
        hums.engine.battery = await this.getLastValueOf('batteryVoltage', vehicleName);
        hums.fuel.level = await this.getLastValueOf('fuelLevel', vehicleName);
        hums.fuel.total = await this.getLastValueOf('engineTotalFuelUsed', vehicleName);
        hums.fuel.rate = await this.getLastValueOf('engineFuelRate', vehicleName);
        hums.fuel.temp = await this.getLastValueOf('engineFuelTemperature', vehicleName);
        hums.gear.speed = await this.getLastValueOf('wheelBasedVehicleSpeed', vehicleName);
        hums.gear.selectedGear = await this.getLastValueOf('transmissionSelectedGear', vehicleName);
        hums.environment.air = await this.getLastValueOf('ambientAirTemperature', vehicleName);
        hums.environment.barometricPressure = await this.getLastValueOf('barometricPressure', vehicleName);
        hums.distance.total = await this.getLastValueOf('Odometre', vehicleName);
        hums.acceleration.x = await this.getLastValueOf('linearAccelerationX', vehicleName);
        hums.acceleration.y = await this.getLastValueOf('linearAccelerationY', vehicleName);
        hums.acceleration.z = await this.getLastValueOf('linearAccelerationZ', vehicleName);
        hums.acceleration.rmsX = await this.getLastValueOf('rmsLinearAccelerationX', vehicleName);
        
        // on récupère l'ensemble des ".time" pour en déduire le plus récent
        const times = [];
        Object.keys(hums).filter(x => !!hums[x]).forEach((x) => {
            Object.keys(hums[x]).filter(y => !!hums[x][y]).forEach((y) => {
                if (hums[x][y].time) {
                    times.push(hums[x][y].time);
                }
            });
        });
        if (times.length) {
            hums.lastUpdatedAt = times.reduce((lastDate, currDate) => currDate > lastDate ? currDate : lastDate);
        }

        return hums;
    }
    
    /**
     * Retourne l'historique de valeurs pour un champs donné
     * @param field 
     * @param start 
     * @param end 
     * @param labels 
     */
    async getHistoryFromField(field: string, start, end, labels = [], vehicleName: string) {
        // on récupère les données depuis la base
        const table = `Vehicle_${field}_Records`;
        const query = `
            SELECT *
            FROM "${table}"
            WHERE "vehicleName" = $1
            AND "recordTime" BETWEEN $2 AND $3
            ORDER BY "recordTime" ASC`;
        const dbData = await this.hums.query(query, [vehicleName, start, end]);

        // si aucun label n'est fourni, on retourne l'historique brut
        if (!labels || !labels.length) {
            return dbData;
        }

        // on prépare le tableau de valeurs de retour en initialisant tout à null
        const data = labels.map(label => ([label, null]));

        // pour chaque valeur
        dbData.forEach((row) => {
            // on détermine sa position en fonction du timestamp le plus proche
            const ts = +format(row.recordTime, 'x');
            const closestTs = labels.reduce((prev, curr) => Math.abs(curr - ts) < Math.abs(prev - ts) ? curr : prev);
            const index = labels.indexOf(closestTs);
            // et on y insère la valeur
            data[index][1] = +row[field];
        });

        return data;
    }

    /**
     * Retourne la dernière valeur enregistrée pour un champs et un véhicule donné
     * @param field 
     * @param vehicleName
     */
    async getLastValueOf(field: string, vehicleName: string) {
        const table = `Vehicle_${field}_Records`;
        const query = `SELECT "${field}", "recordTime" FROM "${table}" WHERE "vehicleName" = $1 ORDER BY "recordTime" DESC LIMIT 1`;
        const result = await getConnection('hums').query(query, [vehicleName]);

        if (!result || !result.length) {
            return null;
        } else {
            return {
                value: result[0][field],
                time: result[0]['recordTime']
            };
        }
    }

    /**
     * Retourne les dernières valeurs enregistrées pour un champs donné pour tout les véhicules en base
     * @param field 
     */
    async getLastValuesOf(field: string) {
        const table = `Vehicle_${field}_Records`;
        const query = `SELECT "vehicleName", MAX("recordTime") AS "time", MAX("${field}") AS "${field}" 
        FROM "${table}" GROUP BY "vehicleName"`;

        const result = await getConnection('hums').query(query);

        if (!result || !result.length) {
            return null;
        } else {
            let map = {};
            result.forEach(row => {
                map[row.vehicleName] = row.location;
            });
            return map;
        }
    }

    async getEventCountFromField(field: string, start, end, categories = [], vehicleName: string) {
        // on récupère les données depuis la base
        const table = `Vehicle_${field}_Records`;
        const query = `
            SELECT "${field}", count(*) as nbEvents
            FROM "${table}"
            WHERE "vehicleName" = $1
            AND "recordTime" BETWEEN $2 AND $3
            GROUP BY "${field}"
            ORDER BY nbEvents DESC`;
        const dbData = await this.hums.query(query, [vehicleName, start, end]);

        // on prépare le tableau de valeurs de retour en initialisant tout à 0
        const data = Array(categories.length).fill(0);

        // pour chaque valeur
        dbData.forEach((row) => {
            // on converti le code en binaire
            const codesLength = categories[0].split(' ')[0].length;
            const code = (+row[field]).toString(2).padStart(codesLength, '0');
            
            // on incrémente le bon compteur
            const index = categories.findIndex((cat) => cat.substring(0, codesLength) === code);
            data[index] = +row.nbevents;
        });

        return data;
    }

    async getRetarderEvents(start, end, categories = [], vehicleName: string) {
        // on récupère les données depuis la base
        const table = `Vehicle_retarderTorqueMode_Records`;
        const query = `
            SELECT "retarderTorqueMode", count(*) as nbEvents
            FROM "${table}"
            WHERE "vehicleName" = $1
            AND "recordTime" BETWEEN $2 AND $3
            GROUP BY "retarderTorqueMode"
            ORDER BY nbEvents DESC`;
        const dbData = await this.hums.query(query, [vehicleName, start, end]);

        // on prépare le tableau de valeurs de retour en initialisant tout à 0
        const data = Array(categories.length).fill(0);

        // pour chaque valeur
        dbData.forEach((row) => {
            // on converti le code en binaire
            const code = (+row.retarderTorqueMode).toString(2).padStart(4, '0');
            
            // on incrémente le bon compteur
            if (code === '0000') {
                data[0] += +row.nbevents;
            } else {
                data[1] += +row.nbevents;
            }
        });

        return data;
    }

    async getPositions(vehicleName: string) {
        // on récupère les données depuis la base
        const table = `Vehicle_location_Records`;
        const query = `
            SELECT "recordTime", "location"
            FROM "${table}"
            WHERE "vehicleName" = $1
            ORDER BY "recordTime" DESC
            LIMIT 100`;
            
        return await this.hums.query(query, [vehicleName]);
    }

    async getDiagnoticTroubleCode(vehicleName: string) {
        // on récupère les données depuis la base
        const table = `Vehicle_DiagnosticTroubleCode`;
        const query = `
            SELECT "dtcCode" AS "code", MAX("recordTime") as "lastTrouble", count(*), "status"
            FROM "${table}"
            WHERE "vehicleName" = $1
            GROUP BY "dtcCode", "status"
            ORDER BY "dtcCode" ASC`;
            
        return await this.hums.query(query, [vehicleName]);
    }
    
    // Active le script d'insertion de data toutes les 5 secondes, pendant 3 min
    async toggleLive(vehicleId: number) {
        const vehicleName = await this.getVehicleName(vehicleId);
        const timer = setInterval(() => this.live(vehicleName), 5 * 1000);
        setTimeout(() => clearInterval(timer), 3 * 60000);

        return { success: true };
    }

    async live(vehicleName: string) {
        const date = new Date().toISOString();

        // vitesse
        await this.hums.query(`INSERT INTO "Vehicle_wheelBasedVehicleSpeed_Records" VALUES($1, $2, $3);`, [
            vehicleName, 
            date, 
            this.rand(0, 85)
        ]);

        // niveau d'essence
        await this.hums.query(`INSERT INTO "Vehicle_fuelLevel_Records" VALUES($1, $2, 
            (SELECT "fuelLevel" - 0.02 FROM "Vehicle_fuelLevel_Records" ORDER BY "recordTime" DESC LIMIT 1));`, [
            vehicleName, 
            date
        ]);

        // position
        const lastLocation = await this.hums.query(`SELECT "location" FROM "Vehicle_location_Records" WHERE "vehicleName" = $1 ORDER BY "recordTime" DESC LIMIT 1`, [
            vehicleName
        ]);
        const location = lastLocation[0].location.split(',');
        const sign = Math.random() < 0.5 ? -1 : 1;
        const newLocation = [
            (+location[0] + (this.rand(0.6, 1) / 1000)),
            (+location[1] + (sign * this.rand(0.5, 1.2) / 100)),
            this.rand(10, 100)
        ].join(',');
        await this.hums.query(`INSERT INTO "Vehicle_location_Records" VALUES($1, $2, $3);`, [
            vehicleName, 
            date,
            newLocation
        ]);

        // rpm
        await this.hums.query(`INSERT INTO "Vehicle_engineSpeed_Records" VALUES($1, $2, $3);`, [
            vehicleName, 
            date, 
            this.rand(1200, 2600)
        ]);
    }

    rand(min = 0, max = 100) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }

    async getVehicleName(vehicleId: number) {
        // on recupère le vehicleName à partir du vehicleId
        const vehicle = await this.vehicleRepo.findOne({
            where: {
                id: Equal(vehicleId)
            },
            select: ['vinNumber']
        });

        return (vehicle && vehicle.vinNumber) ? vehicle.vinNumber : null;
    }

}