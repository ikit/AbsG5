import { getRepository, MoreThan, Equal } from "typeorm";
import { MaintenanceOperation } from "../entities/MaintenanceOperation";
import { Vehicle, MaintenancePlan } from "../entities";
import { HumsService } from "./HumsService";
import { subDays, subMonths, subYears, isAfter } from "date-fns";
import { NotFoundError } from "routing-controllers";

export class MaintenanceService {
    
    private humsService = new HumsService();

    /**
     * Retourne la date de la prochaine maintenance du véhicule
     * @param vehicleId 
     */
    async getNextMaintenanceDate(vehicleId: number) {
        const maintenanceOperation = await getRepository(MaintenanceOperation).findOne({
            order: {
                nextDueAt: 'ASC'
            },
            where: {
                nextDueAt: MoreThan('now()'),
                vehicle: Equal(vehicleId)
            }
        });

        return maintenanceOperation ? maintenanceOperation.nextDueAt : null;
    }

    async getVehicleMaintenancePlanWithOperations(vehicle: Vehicle) {
        if (!vehicle) {
            throw new NotFoundError(`Vehicle not found.`);
        }

        if (!vehicle.type) {
            throw new NotFoundError(`The vehicle is not associated to a type, so there is no maintenance plan.`);
        }

        // on récupère le kilometrage actuel du véhicule
        const currentOdometre = await this.humsService.getLastValueOf('Odometre', vehicle.vinNumber);
        const currentKm = currentOdometre ? +currentOdometre.value : null;

        // on récupère ses plans de maintenance et les opérations associées
        const mpRepo = getRepository(MaintenancePlan);
        const moRepo = getRepository(MaintenanceOperation);
        const maintenancePlans = await mpRepo.find({
            order: {
                serviceTask: 'ASC'
            },
            where: {
                vehicleType: Equal(vehicle.type.id)
            }
        });

        if (currentKm && maintenancePlans.length) {
            // pour chaque plan de maintenance, on récupère l'opération liée au véhicule
            for (let maintenancePlan of maintenancePlans) {
                const operation = await moRepo.findOne({
                    where: {
                        vehicle: Equal(vehicle.id),
                        maintenancePlan: Equal(maintenancePlan.id)
                    }
                });
                if (operation) {
                    // on calcul les seuils d'alerte en km et en temps
                    const thresholdKm = operation.nextDueMeterValue - maintenancePlan.dueSoonMeterThreshold;
                    const thresholdTime = this.getThresholdTimeFromOperation(operation, maintenancePlan);

                    // on détermine si l'opération de maintenance est bientot dûe ou si elle est dépassée
                    const isDueSoonKm = (thresholdKm <= currentKm) && (currentKm <= operation.nextDueMeterValue);
                    const isDueSoonTime = !!thresholdTime && isAfter(new Date(), thresholdTime);
                    const isOverdueKm = currentKm > operation.nextDueMeterValue;
                    const isOverdueTime = !!operation.nextDueAt && isAfter(new Date(), operation.nextDueAt);

                    operation.isDueSoon = !!(isDueSoonKm || isDueSoonTime);
                    operation.isOverdue = !!(isOverdueKm && isOverdueTime);
                }
                maintenancePlan.operation = operation;
            }
        }
        
        return maintenancePlans;
    }
    
    /**
     * Retourne la date correspondant au seuil d'alerte 
     * @param operation l'opération à calculer
     * @param mp le plan de maintenant associé à l'opération
     */
    getThresholdTimeFromOperation(operation: MaintenanceOperation, mp: MaintenancePlan): Date|null {
        if (!operation.nextDueAt || !mp || mp.dueSoonTimeThresholdInterval || mp.dueSoonTimeThresholdFrequency) {
            return null;
        }

        return {
            'jours': () => subDays(operation.nextDueAt, mp.dueSoonTimeThresholdInterval),
            'mois': () => subMonths(operation.nextDueAt, mp.dueSoonTimeThresholdInterval),
            'années': () => subYears(operation.nextDueAt, mp.dueSoonTimeThresholdInterval)
        }[mp.dueSoonTimeThresholdFrequency];
    }

}