const issues = require('./issues.json');
const vehicles = require('./vehicles.json');
const vehicleSpecs = require('./vehicleSpecs.json');
const maintenanceOperations = require('./maintenanceOperations.json');

export const FLEETS = [
    { name: 'PA' },
    { name: 'PSP' },
    { name: 'PE' },
    { name: 'PG' }
];

export const REGIMENTS = [
    { name: '516° RT' },
    { name: '121° RT' },
    { name: '503° RT' },
    { name: '511° RT' },
    { name: '515° RT' },
    { name: 'R. MED' },
    { name: '14° RISLP' }
];

export const SQUADS = [
    { name: 'ET', regiment: null },
    { name: 'ER', regiment: null },
    { name: 'NTI1', regiment: null },
    { name: 'NTI2', regiment: null }
];

export const DRIVERS = [
    { name: 'SURET', surname: 'RIDSY', type: 'driver', grade: 'SOLDAT 2CL TERRE', registrationNumber: '1 697 140 646' },
    { name: 'John', surname: 'DOE', type: 'driver', grade: 'SOLDAT 1CL TERRE', registrationNumber: '0 526 240 568' },
];

export const PARTS = [
    { name: 'Moteur', level: 11, type: 'Moteur Equipé', code: '245227' },
    { name: 'Boite de vitesses', level: 21, type: 'Boite de vitesses assemblée', code: '311044' },
    { name: 'Boite de transfert', level: 31, type: 'Boite de transfert assemblee', code: '1101' },
    { name: 'Pont avant n°1', level: 41, type: 'Train de roulement', code: '35023896' },
    { name: 'Pont avant n°2', level: 42, type: 'Train de roulement', code: '35024011' },
    { name: 'Pont avant n°3', level: 43, type: 'Train de roulement', code: '33112401' },
    { name: 'Pont avant n°4', level: 44, type: 'Train de roulement', code: '33112335' }
];

export const VEHICLE_TYPES = [
    { name: 'PPLOG DP', emat: '24 42 18 01', specs: vehicleSpecs[0], nominalDistanceOpexByMonth: 4000, nominalDistanceOpintByMonth: 1000 },
    { name: 'PPLOG NP', emat: '00 06 64 01', specs: vehicleSpecs[1], nominalDistanceOpexByMonth: 10000, nominalDistanceOpintByMonth: 1500 }
];

export const VEHICLE_STATUS = [
    { name: 'Disponible' },
    { name: 'En mission' },
    { name: 'En mission (STAGE)' },
    { name: 'En mission (TTIA)' },
    { name: 'Maintenance (NTI1)' },
    { name: 'Maintenance (NTI2)' },
    { name: 'En panne' },
    { name: 'En prêt' }
];

export const VEHICLES = [
    ...vehicles,
    // // 14x C380
    // ...['6143 0100', '6143 0103', '6143 0106', '6143 0118', '6143 0121', '6143 0123', '6143 0125', '6143 0127', 
    //     '6143 0129', '6143 0131', '6153 0014', '6153 0031', '6153 0058', '6153 0059'].map((plate, index) => ({
    //     name: `C380 ${(index+1)}`,
    //     plate,
    //     vinNumber: '61 439 482',
    //     registrationDate: '2011-08-20 00:00:00',
    //     status: null, type: null, fleet: null, equipments: [], parts: [], squad: null
    // })),
];

export const MISSION_TYPES = [
    { name: 'Transport (Métropole)' }
];

export const MISSION_STATUS = [
    { code: 'created', name: 'Créée' },
    { code: 'waiting', name: 'En attente' },
    { code: 'confirmed', name: 'Confirmée' },
    { code: 'cancelled', name: 'Annulée' },
    { code: 'running', name: 'En cours' },
    { code: 'terminated', name: 'Terminée' }
];

export const EQUIPMENTS = [
    { name: 'Radio', serialNumber: 'A144584PM', partNumber: '115489964', category: 'communication', manufacturer: 'IVECO', version: '1', nno: '7021-14-5849792' },
    { name: 'PORTEUR BASE M320.45W 055', serialNumber: '055', partNumber: '20125', category: 'SYSTEME PPLOG/R', manufacturer: 'IVECO', version: '1.0.0', nno: '2456-56-98544875' },
];

export const MISSIONS = [
    { 
        name: 'Alpha',
        reference: 'M#001',
        applicant: 'COMLOG',
        destination: 'OPINT',
        status: null,
        goal: `Observer l'activité dans le village.`,
        orders: `Ne pas interagir avec les civils.`,
        departureDate: '2018-10-22 10:00:00',
        arrivalDate: '2018-10-26 10:00:00',
        regiment: null,
        type: null
    },
    { 
        name: 'Beta',
        reference: 'M#002',
        applicant: 'CCTS',
        destination: 'OPEX',
        status: null,
        goal: `Prend possession des lieux au plus vite.`,
        orders: `Respecter la formation`,
        departureDate: '2018-10-23 15:00:00',
        arrivalDate: '2018-10-26 20:00:00',
        regiment: null,
        type: null
    },
    { 
        name: 'Lorem',
        reference: 'M#003',
        applicant: 'CCTS',
        status: null,
        goal: `Prend possession des lieux au plus vite.`,
        orders: ``,
        departureDate: '2018-10-24 10:00:00',
        arrivalDate: '2018-10-31 15:00:00',
        regiment: null,
        type: null
    }
];

export const MISSION_EXPECTATIONS = [
    {
        count: 2,
        comments: '',
        mission: null,
        vehicleType: null,
        expectedKm: 3000
    },
    {
        count: 1,
        comments: '',
        mission: null,
        vehicleType: null,
        expectedKm: 5000
    },
    {
        count: 1,
        comments: '',
        mission: null,
        vehicleType: null,
        expectedKm: 250
    }
];

export const TRANSPORT_ORDERS = [
    { reference: '20180928105126 CTS/BT/VRM', goal: 'Transport par voie routière', description: 'Le CTS ordonne à 516RT…', orders: '- Vous devez impérativement…', 
    driver1: null, driver2: null, mission: null, vehicle: null }
];

export const MAINTENANCE_PLANS = [
    { serviceTask: 'VP', meterInterval: 40000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency: null },
    { serviceTask: 'VP DEPOSE FREINS', meterInterval: 60000, timeInterval: 4, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency: null },
    { serviceTask: 'SOUPAPES INJECTEURS', meterInterval: null, timeInterval: 1600, timeFrequency: 'heures', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'COURROIES', meterInterval: null, timeInterval: 3200, timeFrequency: 'heures', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'COS', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'CT IVECO', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'STS', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VM / AG / ECD', meterInterval: 40000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'BT PTS RED', meterInterval: 80000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'BV', meterInterval: 10000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'AMPLI CAB RS', meterInterval: null, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VID DIRECTION', meterInterval: 200000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VS LEV', meterInterval: null, timeInterval: 6, timeFrequency: 'mois', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'APG', meterInterval: null, timeInterval: 15, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'CORPS CREUX', meterInterval: null, timeInterval: 5, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'LIMITEUR DE VITESSE', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'CHRONO', meterInterval: null, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'ECHANGE PILE CHRONO', meterInterval: null, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'ADR', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'BANC FREIN', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VP', meterInterval: 40000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VP DEPOSE FREINS', meterInterval: 60000, timeInterval: 4, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'SOUPAPES INJECTEURS', meterInterval: null, timeInterval: 1600, timeFrequency: 'heures', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'COURROIES', meterInterval: null, timeInterval: 3200, timeFrequency: 'heures', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'COS', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'CT IVECO', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'STS', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VM / AG / ECD', meterInterval: 40000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'BT PTS RED', meterInterval: 80000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'BV', meterInterval: 10000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'AMPLI CAB RS', meterInterval: null, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VID DIRECTION', meterInterval: 200000, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'VS LEV', meterInterval: null, timeInterval: 6, timeFrequency: 'mois', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'APG', meterInterval: null, timeInterval: 15, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'CORPS CREUX', meterInterval: null, timeInterval: 5, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'LIMITEUR DE VITESSE', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'CHRONO', meterInterval: null, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'ECHANGE PILE CHRONO', meterInterval: null, timeInterval: 2, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'ADR', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency:null },
    { serviceTask: 'BANC FREIN', meterInterval: null, timeInterval: 1, timeFrequency: 'ans', vehicleType: null, dueSoonMeterThreshold: null, dueSoonTimeThresholdInterval: null, dueSoonTimeThresholdFrequency: null }
];

export const ISSUES = issues;
export const VEHICLES_SPECS = vehicleSpecs;
export const MAINTENANCE_OPERATIONS = maintenanceOperations;

export const USERS = [
    { name: 'Admin', username: 'admin', password: '$2b$10$6YARbo4FLzXz5Wx.ug.V4eDXOiB3uTPhmRloK5fHNDg1xKzxBzFUa', email: 'noreply@thalesgroup.com' }
];