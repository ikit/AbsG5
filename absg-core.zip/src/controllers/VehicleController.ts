import { getRepository, In, Equal } from "typeorm";
import { JsonController, Param, Body, Get, Post, Delete, NotFoundError } from "routing-controllers";
import { startOfDay, subDays, addMinutes, format, differenceInDays } from "date-fns";
import { Vehicle, VehicleType, Mission, VehicleStatus, GasStation, Issue } from "../entities";
import { HumsService, VehicleService, MaintenanceService } from "../services";

const DTC_CODES = require('../data/dtc.json');

@JsonController('/vehicles')
export class VehicleController {

    private vehicleRepo = getRepository(Vehicle);
    private humsService = new HumsService();
    private vehicleService = new VehicleService();
    private maintenanceService = new MaintenanceService();

    @Get('')
    async all() {
        const vehicles = await this.vehicleRepo.find({
            order: {
                id: 'ASC'
            }
        });

        for (let vehicle of vehicles) {
            const vehicleName = vehicle.vinNumber;
            const vehicleUsage = await this.vehicleService.getVehicleUsage(vehicle.id);
            const nextMaintDate = await this.maintenanceService.getNextMaintenanceDate(vehicle.id);

            vehicle['hums'] = await this.humsService.getHumsByVehicle(vehicleName);
            vehicle['stats'] = {
                nextMaintenanceDate: nextMaintDate,
                usage: vehicleUsage
            }
        }

        return vehicles;
    }

    @Get('/locations')
    async allLocations() {
        return await this.humsService.getLastValuesOf('location');
    }

    @Get('/:id([0-9]+)')
    async one(@Param("id") id: number) {
        // on récupère le véhicule
        const vehicle = await this.vehicleRepo.findOne(id, {
            relations: ['parts']
        });

        // on va chercher ses plans de maintenance, les opérations associées et calculer les seuils d'alerte
        vehicle.maintenancePlans = await this.maintenanceService.getVehicleMaintenancePlanWithOperations(vehicle);

        return vehicle;
    }

    @Post('/')
    save(@Body() vehicle: Vehicle) {
        return this.vehicleRepo.save(vehicle);
    }

    @Delete('/:id')
    async remove(@Param("id") id: number) {
        let vehicle = await this.vehicleRepo.findOne(id);
        if (!vehicle) {
            throw new NotFoundError(`Vehicle was not found.`);
        }
        return this.vehicleRepo.remove(vehicle);
    }

    @Get('/search-for-mission/:missionId')
    async find(@Param('missionId') missionId: number) {
        // on récupère les infos de la mission
        const mission = await getRepository(Mission).findOne(missionId);
        if (!mission) {
            throw new NotFoundError(`Mission was not found.`);
        }
        if (!mission.departureDate || !mission.arrivalDate) {
            throw new NotFoundError(`Mission dates are missing.`);
        }
        if (!mission.regiment) {
            throw new NotFoundError(`Mission is not associated with a regiment.`);
        }

        // on récupère les véhicules qui ne sont pas associés à un ordre de transport dont les dates de mission chevauchent celles de la mission actuelle
        // et dont l'escadron appartient au régiment associé à la mission
        // si la mission contient des attentes alors on filtre le type de vehicule
        const vehiclesIds = await getRepository(Vehicle).query(`
            SELECT id FROM vehicle
            WHERE "id" NOT IN (
                SELECT "vehicleId"
                FROM transport_order
                WHERE "missionId" IN (
                    SELECT "id"
                    FROM mission
                    WHERE "departureDate" <= $1
                    AND "arrivalDate" >= $2
                    AND "id" != $3
                )
            )
            AND "squadId" IN (
                SELECT "id"
                FROM squad
                WHERE "regimentId" = $4
            )
            ${!mission.expectations.length ? '' : `
            AND "typeId" IN (
                SELECT "vehicleTypeId"
                FROM mission_expectation
                WHERE "missionId" = $3
            )`}`,
            [mission.arrivalDate, mission.departureDate, mission.id, mission.regiment.id]
        );

        // on récupère les entités
        const vehicles = await getRepository(Vehicle).find({
            id: In(vehiclesIds.map(v => v.id))
        });

        return vehicles;
    }

    @Get('/:id/hums')
    async getHums(@Param("id") vehicleId: number) {
        const vehicleName = await this.humsService.getVehicleName(vehicleId);
        return this.humsService.getHumsByVehicle(vehicleName);
    }

    @Get('/:id/diagnostic-trouble-codes')
    async getDtc(@Param("id") vehicleId: number) {
        const vehicleName = await this.humsService.getVehicleName(vehicleId);
        const dbData = await this.humsService.getDiagnoticTroubleCode(vehicleName);

        return DTC_CODES.map((dtc) => {
            const dbCodeData = dbData.find(d => d.code === dtc.code);

            return {
                ...dtc,
                count: dbCodeData ? dbCodeData.count : 0,
                lastTrouble: dbCodeData ? dbCodeData.lastTrouble : null,
                opened: dbCodeData && dbCodeData.status && dbCodeData.status === 'OPEN'
            }
        }).filter(c => c.opened);
    }

    @Get('/:id/missions')
    async getVehicleMissions(@Param('id') id: number) {
        return await getRepository(Mission).createQueryBuilder('mission')
            .leftJoinAndSelect("mission.transportOrders", "transportOrders")
            .leftJoinAndSelect("transportOrders.driver1", "driver1")
            .leftJoinAndSelect("transportOrders.driver2", "driver2")
            .leftJoinAndSelect("transportOrders.vehicle", "vehicle")
            .where('"vehicleId" = :vehicleId', { vehicleId: id })
            .getMany();
    }

    @Get('/:id/maintenance')
    async getVehicleMaintenance(@Param('id') id: number) {
        // on récupère le véhicule
        const vehicle = await this.vehicleRepo.findOne(id);

        // on va chercher ses plans de maintenance et calculer les seuils d'alerte
        return await this.maintenanceService.getVehicleMaintenancePlanWithOperations(vehicle);
    }

    @Get('/:id/issues')
    async getVehicleIssues(@Param('id') id: number) {
        return await getRepository(Issue).find({
            where: {
                vehicle: Equal(id)
            }
        });
    }

    @Get('/stations/:latitude/:longitude/:radius')
    @Get('/stations/:latitude/:longitude')
    async getgasStation(@Param('latitude') latitude: number, @Param('longitude') longitude: number, radius: number = 30) {
        
        // Retrieve station within a given radius (30 miles)
        return await getRepository(GasStation).createQueryBuilder('stations')
            .where(
                'ST_Distance_Sphere("localization", ST_MakePoint(:longitude, :latitude)) <= :radius * 1609.34',
                { longitude, latitude, radius })
            .getMany();
    }
    
    @Post('/:id/live')
    async toggleLive(@Param("id") vehicleId: number) {
        return await this.humsService.toggleLive(vehicleId);
    }

    @Post('/:id/hums/:type')
    async getHumsByType(
        @Param("id") vehicleId: number, 
        @Param("type") type: string, 
        @Body() params: any = {}
    ) {
        // parametres
        const vehicleName = await this.humsService.getVehicleName(vehicleId);
        params = { vehicleName, ...this.getDefaultParams(params) };
        
        // on appelle la bonne méthode en fonction du type de HUMS demandé
        const fns = {
            'fuel': this.getHumsFuel,
            'environment': this.getHumsEnvironment,
            'accelerometer': this.getHumsAccelerometer,
            'temperatures': this.getHumsTemperatures,
            'fan': this.getHumsFan,
            'retarder': this.getHumsRetarder,
            'pto': this.getHumsPto,
            'positions': this.getPositions,
            'electrical-power': this.getHumsElectricalPower,
            'manifold': this.getHumsManifold,
            'engine': this.getHumsEngine,
            'tric': this.getHumsTric,
            'truck-load': this.getHumsTruckLoad
        }

        if (!fns[type]) {
            throw new NotFoundError(`HUMS type not implemented.`);
        }

        return await fns[type].bind(this)(params);
    }

    /**
     * Retourne 2 graphiques concernant le carburant :
     * - la consommation moyenne dans le temps (engine_fuel_rate)
     * - le niveau de carburant dans le temps (fuel_level)
     * @param params 
     */
    async getHumsFuel(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = [
            {
                title: {
                    text: 'Consommation moyenne (L/h)'
                },
                series: [
                    {
                        name: 'Consommation moyenne',
                        data: await this.humsService.getHistoryFromField('engineFuelRate', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' L/h' // C'est pas plutot 'L/100km' ?
                }
            },
            {
                title: {
                    text: 'Niveau de carburant (%)'
                },
                series: [
                    {
                        name: 'Niveau de carburant',
                        data: await this.humsService.getHistoryFromField('fuelLevel', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' %'
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 2 graphiques concernant l'environnement :
     * - la température de l'air ambiant (ambient_air_temperature)
     * - la pression barométrique (barometric_pressure)
     * @param params 
     */
    async getHumsEnvironment(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = [
            {
                title: {
                    text: 'Température air ambiant (°C)'
                },
                series: [
                    {
                        name: 'Température air ambiant',
                        data: await this.humsService.getHistoryFromField('ambientAirTemperature', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' °C'
                }
            },
            {
                title: {
                    text: 'Pression barométrique (kPa)'
                },
                series: [
                    {
                        name: 'Pression barométrique',
                        data: await this.humsService.getHistoryFromField('barometricPressure', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' kPa'
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 1 nuage de points concernant les accélérations dans le temps :
     * - linear_acceleration_x
     * - linear_acceleration_y
     * - linear_acceleration_z
     * @param params 
     */
    async getHumsAccelerometer(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const accX = await this.humsService.getHistoryFromField('linearAccelerationX', params.start, params.end, labels, params.vehicleName);
        const accY = await this.humsService.getHistoryFromField('linearAccelerationY', params.start, params.end, labels, params.vehicleName);
        const accZ = await this.humsService.getHistoryFromField('linearAccelerationZ', params.start, params.end, labels, params.vehicleName);

        const hums = [
            {
                title: {
                    text: 'Accélération (en g)'
                },
                series: [
                    { name: 'X', data: accX, lineWidth: 0.5 },
                    { name: 'Y', data: accY, lineWidth: 0.5 },
                    { name: 'Z', data: accZ, lineWidth: 0.5 }
                ],
                tooltip: {
                    valueSuffix: ' g',
                    valueDecimals: null
                }
            },
            {
                title: { text: 'X' },
                series: [{ name: 'X', data: accX, lineWidth: 0.5 }],
                tooltip: {
                    valueSuffix: ' g',
                    valueDecimals: null
                }
            },
            {
                title: { text: 'Y' },
                series: [{ name: 'Y', data: accY, lineWidth: 0.5 }],
                tooltip: {
                    valueSuffix: ' g',
                    valueDecimals: null
                }
            },
            {
                title: { text: 'Z' },
                series: [{ name: 'Z', data: accZ, lineWidth: 0.5 }],
                tooltip: {
                    valueSuffix: ' g',
                    valueDecimals: null
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 1 graphique concernant 3 courbes de données de température :
     * - Liquide de refroidissement (engine_coolant_temperature)
     * - Carburant (engine_fuel_temperature)
     * - Huile moteur (engine_oil_temperature)
     * @param params 
     */
    async getHumsTemperatures(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = {
            title: {
                text: 'Températures (°C)'
            },
            series: [
                {
                    name: 'Liquide de refroidissement',
                    data: await this.humsService.getHistoryFromField('engineCoolantTemperature', params.start, params.end, labels, params.vehicleName),
                    lineWidth: 0.5
                }, {
                    name: 'Carburant',
                    data: await this.humsService.getHistoryFromField('engineFuelTemperature', params.start, params.end, labels, params.vehicleName),
                    lineWidth: 0.5
                }, {
                    name: 'Huile moteur',
                    data: await this.humsService.getHistoryFromField('engineOilTemperature', params.start, params.end, labels, params.vehicleName),
                    lineWidth: 0.5
                }
            ],
            tooltip: {
              valueSuffix: ' °C'
            }
        };

        return hums;
    }
    
    /**
     * Retourne 1 histogramme avec le nombre d'évenements par valeur possible
     * @param params 
     */
    async getHumsFan(params: any = {}) {
        const categories = [
            '0000 Fan off',
            '0001 Engine system–General',
            '0010 Excessive engine air temperature',
            '0011 Excessive engine oil temperature',
            '0100 Excessive engine coolant temperature',
            '0101 Excessive transmission oil temperature',
            '0110 Excessive hydraulic oil temperature',
            '0111 Default Operation',
            '1000 Reverse Operation',
            '1001 Manual control',
            '1010 Transmission retarder',
            '1011 A/C system',
            '1100 Timer',
            '1101 Engine brake',
            '1110 Other',
            '1111 Not available'
        ];

        const hums = [
            {
                chart: {
                    type: 'column'
                },
                title: {
                    text: `Nombre d'évènements par état`
                },
                xAxis: {
                    type: 'category',
                    categories
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: `Nombre d'évènements`
                    }
                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        dataLabels: {
                            enabled: true,
                            color: 'white'
                        }
                    }
                },
                series: [
                    {
                        name: 'État',
                        data: await this.humsService.getEventCountFromField('fanDriveState', params.start, params.end, categories, params.vehicleName)
                    }
                ],
                tooltip: {
                  valueDecimals: 0
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 1 histogramme avec le nombre d'évenements par valeur possible sur le ralentisseur
     * @param params 
     */
    async getHumsRetarder(params: any = {}) {
        const categories = [
            '0000 No braking',
            '0001 - 1111 Used'
        ];

        const hums = [
            {
                chart: {
                    type: 'column'
                },
                title: {
                    text: `Nombre d'évènements par état`
                },
                xAxis: {
                    type: 'category',
                    categories
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: `Nombre d'évènements`
                    }
                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        dataLabels: {
                            enabled: true,
                            color: 'white'
                        }
                    }
                },
                series: [
                    {
                        name: 'État',
                        data: await this.humsService.getRetarderEvents(params.start, params.end, categories, params.vehicleName)
                    }
                ],
                tooltip: {
                  valueDecimals: 0
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 1 histogramme avec le nombre d'évenements par valeur possible sur le ralentisseur
     * @param params 
     */
    async getHumsPto(params: any = {}) {
        const categories = [
            '00000 Off/Disabled',
            '00001 Hold',
            '00010 Remote Hold',
            '00011 Standby',
            '00100 Remote Standby',
            '00101 Set',
            '00110 Decelerate/Coast',
            '00111 Resume',
            '01000 Accelerate',
            '01001 Accelerator Override',
            '01010 Preprogrammed set speed 1',
            '01011 Preprogrammed set speed 2',
            '01100 Preprogrammed set speed 3',
            '01101 Preprogrammed set speed 4',
            '01110 Preprogrammed set speed 5',
            '01111 Preprogrammed set speed 6',
            '10000 Preprogrammed set speed 7',
            '10001 Preprogrammed set speed 8',
            '10010 PTO set speed memory 1',
            '10011 PTO set speed memory 2',
            '10100 - 11110  Not defined',
            '11111 Not available'
        ];

        const hums = [
            {
                chart: {
                    type: 'column'
                },
                title: {
                    text: `Nombre d'évènements par état`
                },
                xAxis: {
                    type: 'category',
                    categories
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: `Nombre d'évènements`
                    }
                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        dataLabels: {
                            enabled: true,
                            color: 'white'
                        }
                    }
                },
                series: [
                    {
                        name: 'État',
                        data: await this.humsService.getEventCountFromField('ptoGovernorState', params.start, params.end, categories, params.vehicleName)
                    }
                ],
                tooltip: {
                  valueDecimals: 0
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 1 graphique concernant le niveau de batterie
     * @param params 
     */
    async getHumsElectricalPower(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = [
            {
                title: {
                    text: 'Batterie (V)'
                },
                series: [
                    {
                        name: 'Batterie',
                        data: await this.humsService.getHistoryFromField('batteryVoltage', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }, 
                    // Limite acceptable
                    {
                        type: 'line',
                        name: 'Tension acceptable (22.4 V)',
                        lineWidth: 0.5,
                        color: '#f44336',
                        data: [
                            { x: labels[0], y: 22.4 },
                            { x: labels[labels.length-1], y: 22.4 }
                        ]
                    }
                ],
                tooltip: {
                    valueSuffix: ' V'
                }
            }
        ];

        return hums;
    }

    async getPositions(params: any = {}) {
        return this.humsService.getPositions(params.vehicleName);
    }

    /**
     * Retourne 2 graphiques concernant l'admission :
     * - température du collecteur d'admission du moteur (engine_intake_manifold_temperature)
     * - pression du collecteur d'admission du moteur (engine_intake_manifold_pressure)
     * @param params 
     */
    async getHumsManifold(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = [
            {
                title: {
                    text: `Températures du collecteur d'admission moteur (°C)`
                },
                series: [
                    {
                        name: 'Température',
                        data: await this.humsService.getHistoryFromField('engineIntakeManifoldTemperature', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' °C'
                }
            },
            {
                title: {
                    text: `Pression du collecteur d'admission moteur (kPa)`
                },
                series: [
                    {
                        name: 'Pression',
                        data: await this.humsService.getHistoryFromField('engineIntakeManifoldPressure', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' kPa'
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne 3 graphiques concernant le moteur :
     * - le compteur odomètre (Odometre)
     * - la vitesse de rotation du moteur (engine_speed)
     * - durée totale de fonctionnement du moteur (engine_total_hours_of_operation)
     * - la pression de l'huile moteur (engine_oil_pressure)
     * @param params 
     */
    async getHumsEngine(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = [
            {
                title: {
                    text: `Odomètre (km)`
                },
                series: [
                    {
                        name: 'Odomètre',
                        data: await this.humsService.getHistoryFromField('Odometre', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' km'
                }
            },
            {
                title: {
                    text: `Vitesse de rotation du moteur (RPM)`
                },
                series: [
                    {
                        name: 'Vitesse de rotation',
                        data: await this.humsService.getHistoryFromField('engineSpeed', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' RPM'
                }
            },
            {
                title: {
                    text: `Total d'heures de fonctionnement du moteur (h)`
                },
                series: [
                    {
                        name: `Nombre total d'heures`,
                        data: await this.humsService.getHistoryFromField('engineTotalHoursOfOperation', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' h'
                }
            },
            {
                title: {
                    text: `Pression d'huile moteur (kPa)`
                },
                series: [
                    {
                        name: 'Pression',
                        data: await this.humsService.getHistoryFromField('engineOilPressure', params.start, params.end, labels, params.vehicleName),
                        lineWidth: 0.5
                    }
                ],
                tooltip: {
                    valueSuffix: ' kPa'
                }
            }
        ];

        return hums;
    }

    /**
     * Retourne les conditions de roulage
     * @param params 
     */
    async getHumsTric(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const accelerations = await this.humsService.getHistoryFromField('rmsLinearAccelerationX', params.start, params.end, labels, params.vehicleName);
        const speeds = await this.humsService.getHistoryFromField('wheelBasedVehicleSpeed', params.start, params.end, labels, params.vehicleName);
        // const gyroscopes = await this.humsService.getHistoryFromField('wheelBasedVehicleSpeed', params.start, params.end, labels, params.vehicleName);
        const gyroscopes = [];

        const trics = accelerations.map(acceleration => {
            const nearestSpeed = speeds.filter(
                s => s[1] 
                && s[0] >= acceleration[0] - 10000 
                && s[0] <= acceleration[0] + 10000 
            );
            const nearestGyr = gyroscopes.filter(
                s => s[1] 
                && s[0] >= acceleration[0] - 10000 
                && s[0] <= acceleration[0] + 10000 
            );

            return {
                time: new Date(acceleration[0]),
                acc: acceleration[1],
                gyr: nearestGyr.length ? nearestGyr[0][1] : null,
                speed: nearestSpeed.length ? nearestSpeed[0][1] : null
            };
        });

        const hums = [
            {
                chart: {
                  type: 'scatter',
                  zoomType: 'xy'
                },
                title: {
                    text: `Détection du revêtement d'un parcours`
                },
                xAxis: {
                    title: {
                        enabled: true,
                        text: 'Vitesse (en km/h)'
                    },
                    showLastLabel: true,
                    type: 'linear',
                    min: 0,
                    max: 100
                },
                yAxis: {
                    title: {
                        text: 'Accélération (en g)'
                    },
                    min: 0,
                    max: 8
                },
                plotOptions: {
                    scatter: {
                        tooltip: {
                            headerFormat: '',
                            pointFormat: `
                                <b>Accélération:</b> {point.y} g <br>
                                <b>Vitesse:</b> {point.x} km/h <br>
                                <b>Heure:</b> {point.time}
                            `
                        }
                    }
                },
                series: [{
                    type: 'scatter',
                    name: 'Accélération',
                    color: 'rgba(119, 152, 191, .8)',
                    data: [
                        ...trics.filter(t => t.acc && t.speed).map(tric => ({
                            x: tric.speed,
                            y: tric.acc,
                            time: format(tric.time, 'DD/MM/YYYY HH:mm:ss')
                        }))
                    ]
                },
                // limites acceptables
                {
                    type: 'line',
                    name: 'Green',
                    lineWidth: 0.5,
                    color: '#43a047',
                    data: [
                        { x: 0, y: 1 }, 
                        { x: 100, y: 2 }
                    ]
                }, {
                    type: 'line',
                    name: 'Red',
                    lineWidth: 0.5,
                    color: '#f44336',
                    data: [
                        { x: 0, y: 1 },
                        { x: 100, y: 8 }
                    ]
                }
                ]
            }
        ];

        return hums;
    }
    
    /**
     * Retourne la charge du camion
     * @param params 
     */
    async getHumsTruckLoad(params: any = {}) {
        const nbQuarters = params.displayedDays * 24 * (60 / params.gap);

        // labels, on construit un tableaux avec une case toutes les {gap}min
        const labels = [];
        for (let i = nbQuarters; i > 0; i--) {
          const dayHour = addMinutes(params.end, params.gap * -i);
          labels.push(+format(dayHour, 'x'));
        }

        const hums = [
            {
                chart: {
                  type: 'scatter',
                  zoomType: 'xy'
                },
                title: {
                    text: `Charge du véhicule en fonction du temps`
                },
                xAxis: {
                    title: {
                        enabled: true,
                        text: 'Temps'
                    },
                    showLastLabel: true,
                    type: 'linear',
                    min: 0,
                    max: 100
                },
                yAxis: {
                    title: {
                        text: 'Charge (en tonnes)'
                    },
                    min: 0,
                    max: 50
                },
                plotOptions: {
                    scatter: {
                        tooltip: {
                            headerFormat: '',
                            pointFormat: `
                                <b>Charge:</b> {point.y} tonnes <br>
                                <b>Date:</b> {point.time}
                            `
                        }
                    }
                },
                series: [{
                    type: 'scatter',
                    name: 'Charge',
                    color: 'rgba(119, 152, 191, .8)',
                    data: []
                }]
            }
        ];

        return hums;
    }

    getDefaultParams(params: any = {}) {
        params.end = params.end || new Date();
        params.start = params.start || startOfDay(subDays(params.end, 5));
        params.displayedDays = differenceInDays(params.end, params.start);
        params.gap = params.gap || 15;
        return params;
    }

}

@JsonController('/vehicles-types')
export class VehicleTypeController {

    private vehicleTypeRepo = getRepository(VehicleType);

    @Get('')
    all() {
        return this.vehicleTypeRepo.find({order: { name: 'ASC' }});
    }

}

@JsonController('/vehicles-status')
export class VehicleStatusController {

    private vehicleStatusRepo = getRepository(VehicleStatus);

    @Get('')
    all() {
        return this.vehicleStatusRepo.find({order: { name: 'ASC' }});
    }

}