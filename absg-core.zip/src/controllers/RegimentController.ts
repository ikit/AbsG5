import { getRepository } from "typeorm";
import { JsonController, Param, Body, Get, Post, Delete, NotFoundError } from "routing-controllers";
import { Regiment } from "../entities/Regiment";

@JsonController('/regiments')
export class RegimentController {

    private regimentRepo = getRepository(Regiment);

    @Get('')
    all() {
        return this.regimentRepo.find();
    }

    @Get('/:id')
    one(@Param("id") id: number) {
        return this.regimentRepo.findOne(id);
    }

    @Post('/')
    save(@Body() regiment: Regiment) {
        return this.regimentRepo.save(regiment);
    }

    @Delete('/:id')
    async remove(@Param("id") id: number) {
        let regiment = await this.regimentRepo.findOne(id);
        if (!regiment) {
            throw new NotFoundError(`Regiment was not found.`);
        }
        return this.regimentRepo.remove(regiment);
    }

}