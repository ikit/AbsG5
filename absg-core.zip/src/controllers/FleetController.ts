import { getRepository } from "typeorm";
import { JsonController, Param, Body, Get, Post, Delete, NotFoundError } from "routing-controllers";
import { Fleet } from "../entities";

@JsonController('/fleets')
export class FleetController {

    private fleetRepo = getRepository(Fleet);

    @Get('')
    all() {
        return this.fleetRepo.find();
    }

    @Get('/:id')
    one(@Param("id") id: number) {
        return this.fleetRepo.findOne(id);
    }

    @Post('/')
    save(@Body() fleet: Fleet) {
        return this.fleetRepo.save(fleet);
    }

    @Delete('/:id')
    async remove(@Param("id") id: number) {
        let fleet = await this.fleetRepo.findOne(id);
        if (!fleet) {
            throw new NotFoundError(`Fleet was not found.`);
        }
        return this.fleetRepo.remove(fleet);
    }

}