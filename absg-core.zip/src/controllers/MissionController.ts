import { getRepository } from "typeorm";
import { JsonController, Param, Body, Get, Post, Delete, NotFoundError } from "routing-controllers";
import { Mission, MissionType } from "../entities";
import { MissionStatus } from "../entities/MissionStatus";

@JsonController('/missions')
export class MissionController {

    private missionRepo = getRepository(Mission);
    
    @Get('')
    all() {
        return this.missionRepo.find({
            order: {
                id: 'DESC'
            }
        });
    }

    @Get('/:id')
    one(@Param("id") id: number) {
        return this.missionRepo.findOne(id);
    }

    @Post('/')
    async save(@Body() mission: Mission) {
        const missionStatus = await getRepository(MissionStatus).find();
        mission.status = missionStatus.find(s => s.code === (mission.status ? mission.status.code : 'created'));

        // on vérifie s'il faut mettre à jour le status de la mission avant de sauvegarder
        if (mission.status.code === 'created') {
            // liste des types des véhicules selectionnés
            const selectedVehiclesTypeIds = (mission.transportOrders || []).map(to => to.vehicle.type.id);
            const hasMissing = (mission.expectations || []).some(e => !selectedVehiclesTypeIds.includes(e.vehicleType.id));

            if (!mission.expectations.length && mission.transportOrders.length) {
                // si une mission est créée sans attentes, on ne peut pas savoir si elle rempli tout les besoins
                // donc on la considère comme prête à être validée
                mission.status = missionStatus.find(s => s.code === 'waiting');
            } else if (selectedVehiclesTypeIds.length && !hasMissing) {
                // si la mission a des attentes et qu'elles ont toutes des transport order associés
                mission.status = missionStatus.find(s => s.code === 'waiting');
            }
        }

        return this.missionRepo.save(mission);
    }

    @Delete('/:id')
    async remove(@Param("id") id: number) {
        let mission = await this.missionRepo.findOne(id);
        if (!mission) {
            throw new NotFoundError(`Mission was not found.`);
        }
        return this.missionRepo.remove(mission);
    }

}

@JsonController('/missions-types')
export class MissionTypeController {

    private missionTypeRepo = getRepository(MissionType);

    @Get('')
    all() {
        return this.missionTypeRepo.find({ order: { name: 'ASC' } });
    }

}
