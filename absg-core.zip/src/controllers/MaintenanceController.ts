import { getRepository } from "typeorm";
import { JsonController, Body, Post } from "routing-controllers";
import { MaintenanceOperation } from "../entities";

@JsonController('/maintenance')
export class MaintenanceController {

    private maintOpeRepo = getRepository(MaintenanceOperation);

    @Post('/operation')
    save(@Body() maintOpe: MaintenanceOperation) {
        return this.maintOpeRepo.save(maintOpe);
    }

}