import { getRepository } from "typeorm";
import { JsonController, Get, Authorized } from "routing-controllers";
import { Vehicle } from "../entities";

@JsonController('/dashboard')
export class VehicleController {

    private vehicleRepo = getRepository(Vehicle);

    @Get('')
    @Authorized()
    async all() {
        let availability = (await this.vehicleRepo.createQueryBuilder('vehicle')
            .select('COUNT(*) AS count')
            .innerJoinAndSelect("vehicle.status", "status")
            .groupBy('vehicle.status')
            .addGroupBy('status.id')
            .getRawMany())
            .map(a => ({
                count: +a.count,
                status: {
                    id: a.status_id,
                    name: a.status_name
                }
            })
        );

        let vehiclesByType = (await this.vehicleRepo.createQueryBuilder('vehicle')
            .select('vehicle.type')
            .innerJoinAndSelect("vehicle.type", "type")
            .addSelect('COUNT(*) AS count')
            .groupBy('vehicle.type')
            .addGroupBy('type.id')
            .getRawMany())
            .map(a => ({
            count: +a.count,
                type: {
                    id: a.type_id,
                    name: a.type_name,
                    emat: a.type_emat
                }
            })
        );
            
        return {
            availability,
            vehiclesByType
        };
    }

}