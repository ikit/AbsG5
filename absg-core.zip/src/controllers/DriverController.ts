import { getRepository } from "typeorm";
import { JsonController, Param, Body, Get, Post, Delete, NotFoundError } from "routing-controllers";
import { Driver } from "../entities/Driver";

@JsonController('/drivers')
export class DriverController {

    private driverRepo = getRepository(Driver);

    @Get('')
    all() {
        return this.driverRepo.find();
    }

    @Get('/:id')
    one(@Param("id") id: number) {
        return this.driverRepo.findOne(id);
    }

    @Post('/search')
    search(@Body() terms) {
        const query = this.driverRepo.createQueryBuilder('driver');

        if (terms.type) {
            query.where('type = :type', { type: terms.type });
        }
        if (terms.name) {
            query.andWhere('(name ILIKE :name', { name: `%${terms.name}%` });
            query.orWhere('surname ILIKE :surname)', { surname: `%${terms.name}%` });
        }

        return query.getMany();
    }

    @Post('/')
    save(@Body() driver: Driver) {
        return this.driverRepo.save(driver);
    }

    @Delete('/:id')
    async remove(@Param("id") id: number) {
        let driver = await this.driverRepo.findOne(id);
        if (!driver) {
            throw new NotFoundError(`Driver was not found.`);
        }
        return this.driverRepo.remove(driver);
    }

}