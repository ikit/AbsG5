import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from "typeorm";
import { MissionType } from "./MissionType";
import { MissionExpectation } from "./MissionExpectation";
import { TransportOrder } from "./TransportOrder";
import { Regiment } from "./Regiment";
import { MissionStatus } from "./MissionStatus";

@Entity()
export class Mission {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;                   // nom de la mission
    
    @Column({ nullable: true })
    reference: string;              // numero de référence de la mission
    
    @Column({ nullable: true })
    applicant: string;              // demandeur (COMLOG, CCTS, ...)
    
    @Column({ default: 'OPINT' })
    destination: string;            // destination OPEX / OPINT (Opération Extérieur ou Métropole)
    
    @ManyToOne(type => MissionType, missionType => missionType.missions, { eager: true })
    type: MissionType;              // type de mission associée
    
    @ManyToOne(type => MissionStatus, missionStatus => missionStatus.missions, { eager: true })
    status: MissionStatus;          // ex: plannifiée, en cours, terminée
    
    @Column()
    goal: string;                   // Objectif de la mission
    
    @Column({ type: 'text', nullable: true })
    orders: string;                 // instructions
    
    @Column({ type: 'timestamptz', nullable: true })
    departureDate: Date;            // date et heure de départ
    
    @Column({ type: 'timestamptz', nullable: true })
    arrivalDate: Date;              // date et heure d'arrivée
    
    @ManyToOne(type => MissionType, missionType => missionType.missions, { eager: true })
    regiment: Regiment;             // unité militaire en charge de la mission (régiment X)
    
    @OneToMany(type => MissionExpectation, missionExpectation => missionExpectation.mission, { cascade: true, eager: true })
    expectations: MissionExpectation[];

    @OneToMany(type => TransportOrder, transportOrder => transportOrder.mission, { cascade: true, eager: true })
    transportOrders: TransportOrder[];
}
