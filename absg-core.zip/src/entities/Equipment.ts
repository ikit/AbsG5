import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class Equipment {
    @PrimaryGeneratedColumn({ comment: 'milfleet_equipment_id' })
    id: number;

    @Column({ comment: 'Nom' })
    name: string;

    @Column({ comment: 'SerialNumber' })
    serialNumber: string;

    @Column({ comment: 'PartNumber' })
    partNumber: string;

    @Column({ comment: 'Catégorie' })
    category: string;

    @Column({ comment: 'NNO' })
    nno: string;

    @Column({ comment: 'Fabriquant' })
    manufacturer: string;

    @Column({ comment: 'Version' })
    version: string;
}
  