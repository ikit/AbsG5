import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Vehicle } from "./Vehicle";
import { MissionExpectation } from "./MissionExpectation";
import { MaintenancePlan } from "./MaintenancePlan";

@Entity()
export class VehicleType {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    name: string;                           // ex: Logistique, Combat, ...

    @Column()
    emat: string;                           // ex: 24 42 18 01

    @Column("json", { nullable: true })
    specs: any;                             // specifications détaillées du véhicule

    @Column({ nullable: true })
    nominalDistanceOpexByMonth: number;     // distance nominale parcourue en opération extérieure, par mois

    @Column({ nullable: true })
    nominalDistanceOpintByMonth: number;    // distance nominale parcourue en opération intérieure, par mois
    
    @OneToMany(type => Vehicle, vehicle => vehicle.type)
    vehicles: Vehicle[];

    @OneToMany(type => MissionExpectation, missionExpectation => missionExpectation.vehicleType)
    missionExpectations: MissionExpectation[];

    @OneToMany(type => MaintenancePlan, maintenancePlan => maintenancePlan.vehicleType)
    maintenancePlans: MaintenancePlan[];
}