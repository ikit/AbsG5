import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class GasStation {
    @PrimaryGeneratedColumn({ comment: 'id' })
    id: number;

    @Column({ comment: 'Type de route', nullable: true })
    roadType: string;

    @Column({ comment: 'Adresse', nullable: true })
    addresse: string;

    @Column({ comment: 'Commune', nullable: true })
    town: string;

    @Column({ comment: 'Code postal', nullable: true })
    postalCode: string;

    @Column({ comment: 'Ouverture', nullable: true })
    hstart: string;

    @Column({ comment: 'Fermeture', nullable: true })
    hend: string;

    @Column({ comment: 'Exceptions', nullable: true })
    exception: string;

    @Column({ comment: 'Services', nullable: true })
    services: string;

    @Column({ comment: 'Carburants', nullable: true })
    fuels: string;

    @Column({ comment: 'Active', nullable: true })
    active: string;

    @Column("geometry", { comment: 'Position geographique', spatialFeatureType: "Point", srid: 4326 })
    localization: any;
}
