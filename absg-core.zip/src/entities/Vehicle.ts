import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, JoinTable, ManyToOne, OneToMany } from "typeorm";
import { VehicleType, Fleet, Equipment } from './';
import { Squad } from "./Squad";
import { VehicleStatus } from "./VehicleStatus";
import { Part } from "./Part";
import { TransportOrder } from "./TransportOrder";
import { MaintenanceOperation } from "./MaintenanceOperation";
import { Issue } from "./Issue";
import { MaintenancePlan } from "./MaintenancePlan";

@Entity()
export class Vehicle {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    name: string;                   // ex: PPLOG001
    
    @Column()
    plate: string;                  // plaque d'immatriculation
    
    @Column()
    vinNumber: string;              // numéro de série
    
    @Column({ nullable: true })
    registrationDate: Date;         // date de première mise en circulation
    
    @ManyToOne(type => Squad, squad => squad.vehicles, { eager: true })
    squad: Squad;
    
    @ManyToOne(type => VehicleType, vehicleType => vehicleType.vehicles, { eager: true })
    type: VehicleType;              // type de vehicule
    
    @ManyToOne(type => VehicleStatus, vehicleStatus => vehicleStatus.vehicles, { eager: true })
    status: VehicleStatus;          // status de vehicule
    
    @ManyToOne(type => Fleet, fleet => fleet.vehicles, { eager: true })
    fleet: Fleet;                   // flotte associée
    
    @ManyToMany(type => Equipment, { cascade: true, eager: true })
    @JoinTable({ name: 'vehicle_equipment' })
    equipments: Equipment[];        // equipements présents sur le vehicule
    
    @ManyToMany(type => Part, { cascade: true })
    @JoinTable({ name: 'vehicle_part' })
    parts: Part[];                  // ASM présents sur le vehicule
    
    @OneToMany(type => TransportOrder, transportOrder => transportOrder.vehicle)
    transportOrdersVehicle: TransportOrder[];
    
    @OneToMany(type => MaintenanceOperation, maintenanceOperation => maintenanceOperation.vehicle)
    maintenanceOperations: MaintenanceOperation[];
    
    @OneToMany(type => Issue, issue => issue.vehicle)
    issues: Issue[];

    maintenancePlans: MaintenancePlan[];
}
