import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Mission } from "./Mission";

@Entity()
export class MissionType {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    name: string;                   // ex: Transport, Entraînement, Reconnaissance, Attaque
    
    @OneToMany(type => Mission, mission => mission.type)
    missions: Mission[];
}