import { Entity, PrimaryGeneratedColumn, OneToOne, JoinColumn, Column, ManyToOne } from "typeorm";
import { Vehicle } from "./Vehicle";
import { Mission } from "./Mission";
import { Driver } from "./Driver";

// fait le lien entre une mission et un vehicule
@Entity()
export class TransportOrder {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column({ nullable: true })
    reference: string;              // numero de référence
    
    @Column({ nullable: true })
    goal: string;                   // objectif
    
    @Column({ type: 'text', nullable: true })
    description: string;            // description
    
    @Column({ type: 'text', nullable: true })
    orders: string;                 // instructions
    
    @Column({ nullable: true })
    contact: string;                // référent

    @ManyToOne(type => Driver, driver => driver.transportOrdersDriver1, { eager: true })
    @JoinColumn()
    driver1: Driver;                  // le premier conducteur

    @ManyToOne(type => Driver, driver => driver.transportOrdersDriver2, { eager: true })
    @JoinColumn()
    driver2: Driver;                  // le second conducteur
    
    @ManyToOne(type => Mission, mission => mission.transportOrders, { onDelete: 'CASCADE' })
    @JoinColumn()
    mission: Mission;               // la mission associée
    
    @ManyToOne(type => Vehicle, vehicle => vehicle.transportOrdersVehicle, { eager: true })
    @JoinColumn()
    vehicle: Vehicle;               // le véhicule associé
}
