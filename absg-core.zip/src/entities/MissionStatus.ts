import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Mission } from "./Mission";

@Entity()
export class MissionStatus {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    name: string;
    
    @Column()
    code: string;
    
    @OneToMany(type => Mission, mission => mission.status)
    missions: Mission[];
}