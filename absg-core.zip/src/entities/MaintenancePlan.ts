import { Entity, PrimaryGeneratedColumn, Column, JoinColumn, ManyToOne, OneToMany } from "typeorm";
import { VehicleType } from "./VehicleType";
import { MaintenanceOperation } from "./MaintenanceOperation";

@Entity()
export class MaintenancePlan {
    @PrimaryGeneratedColumn()
    id: number;
    
    @ManyToOne(type => VehicleType, vehicleType => vehicleType.maintenancePlans, { eager: true })
    @JoinColumn()
    vehicleType: VehicleType;               // le type de véhicule associé

    @Column()
    serviceTask: string;                    // le nom de la tâche à effectuer

    @Column({ nullable: true })
    meterInterval: number;                  // intervalle entre 2 maintenances, exprimé en metres

    @Column({ nullable: true })
    timeInterval: number;                   // intervalle entre 2 maintenances, exprimé en temps

    @Column({ nullable: true })
    timeFrequency: string;                  // unité de temps de timeInterval, par exemple 'months'

    @Column({ nullable: true })
    dueSoonMeterThreshold: number;          // seuil exprimé en km définissant à combien de km restants il faut émettre une alerte
                                            // par exemple : "émettre une alerte lorsque la prochaine opération de maintenance 
                                            // doit être faite dans moins de 2000km"

    @Column({ nullable: true })
    dueSoonTimeThresholdInterval: number;   // seuil exprimé en temps définissant dans combien de temps il faut émettre une alerte
    
    @Column({ nullable: true })
    dueSoonTimeThresholdFrequency: string;  // unité de temps de dueSoonTimeThresholdInterval
    
    @OneToMany(type => MaintenanceOperation, maintenanceOperation => maintenanceOperation.maintenancePlan)
    maintenanceOperations: MaintenanceOperation[];

    operation: MaintenanceOperation;
}
