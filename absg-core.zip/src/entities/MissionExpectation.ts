import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { Mission, VehicleType } from './';

// liste des véhicules attendus pour la mission
@Entity()
export class MissionExpectation {
    @PrimaryGeneratedColumn()
    id: number;
    
    @ManyToOne(type => Mission, mission => mission.expectations, { onDelete: 'CASCADE' })
    mission: Mission;               // la mission associée
    
    @ManyToOne(type => VehicleType, vehiculeType => vehiculeType.missionExpectations, { eager: true })
    vehicleType: VehicleType;       // le type de véhicule attendu
    
    @Column()
    count: number;                  // le nombre de véhiculeType/equipement attendu

    @Column({ nullable: true })
    expectedKm: number;             // nombre de KM à parcourir prévus

    @Column({ type: 'text', nullable: true })
    comments: string;               // commentaires
}