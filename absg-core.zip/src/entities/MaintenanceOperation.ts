import { Entity, PrimaryGeneratedColumn, Column, JoinColumn, ManyToOne, OneToMany } from "typeorm";
import { Vehicle } from "./Vehicle";
import { MaintenancePlan } from "./MaintenancePlan";

@Entity()
export class MaintenanceOperation {
    @PrimaryGeneratedColumn()
    id: number;
    
    @ManyToOne(type => Vehicle, vehicle => vehicle.maintenanceOperations, { eager: true })
    @JoinColumn()
    vehicle: Vehicle;                       // le véhicule associé

    @ManyToOne(type => MaintenancePlan, maintenancePlan => maintenancePlan.maintenanceOperations)
    @JoinColumn()
    maintenancePlan: MaintenancePlan;

    @Column({ nullable: true })
    nextDueMeterValue: number;              // échéance avant la prochaine maintenance, exprimée en nombre de km

    @Column({ nullable: true })
    nextDueAt: Date;                        // échéance avant la prochaine maintenance, exprimée en date

    isDueSoon: boolean;                     // true si le compteur odometre actuel se trouve au dessus du seuil d'alerte
    isOverdue: boolean;                     // true si le compteur odometre actuel dépasse l'échance de la prochaine maintenance
}
