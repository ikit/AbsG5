import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { Vehicle } from "./Vehicle";

@Entity()
export class Issue {
    @PrimaryGeneratedColumn({ comment: 'milfleet_issue_id' })
    id: number;

    @Column({ nullable: true, comment: 'Code MIRDAT' })
    mirdatCode: string;

    @Column({ nullable: true, comment: 'N° MIRDAT' })
    mirdatNum: string;

    @Column({ nullable: true, comment: 'Emetteur' })
    reporter: string;

    @Column({ comment: 'Date de création du problème' })
    createdAt: Date;

    @Column({ nullable: true, comment: `Date d'apparition du problème` })
    eventDate: Date;

    @Column({ default: 'open', comment: `Status du problème` })
    status: string;

    @Column({ nullable: true, comment: 'Nombre de KM lors du problème' })
    odometer: number;

    @Column({ nullable: true, comment: `Nombre d'heure d'utilisation lors du problème` })
    hours: number;

    @Column({ type: 'text', nullable: true, comment: `Description du problème` })
    description: string;

    @Column({ default: 1, comment: `Priorité` })
    priority: number;

    @Column({ nullable: true, comment: `Code d'erreur` })
    errorCode: string;

    @Column({ default: false, comment: `Risque de sécurité ?` })
    isHighlyCritical: boolean;

    @ManyToOne(type => Vehicle, vehicle => vehicle.issues, { eager: true })
    vehicle: Vehicle;

}