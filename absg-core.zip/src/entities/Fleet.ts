import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Vehicle } from "./Vehicle";

@Entity()
export class Fleet {
    @PrimaryGeneratedColumn({ comment: 'milfleet_fleet_id' })
    id: number;
    
    @Column({ comment: 'Nom' })
    name: string;
    
    @OneToMany(type => Vehicle, vehicle => vehicle.fleet)
    vehicles: Vehicle[];
}