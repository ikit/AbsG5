import { Entity, PrimaryGeneratedColumn, Column, OneToMany, ManyToOne } from "typeorm";
import { Regiment } from "./Regiment";
import { Vehicle } from "./Vehicle";

@Entity()
export class Squad {
    @PrimaryGeneratedColumn({ comment: 'milfleet_squad_id' })
    id: number;
    
    @Column({ comment: 'Nom' })
    name: string;
    
    @ManyToOne(type => Regiment, regiment => regiment.squads)
    regiment: Regiment;

    @OneToMany(type => Vehicle, vehicle => vehicle.squad)
    vehicles: Vehicle[];
}