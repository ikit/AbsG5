import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { TransportOrder } from "./TransportOrder";

@Entity()
export class Driver {
    @PrimaryGeneratedColumn({ comment: 'milfleet_driver_id' })
    id: number;
    
    @Column({ comment: 'Prénom' })
    name: string;
    
    @Column({ comment: 'Nom' })
    surname: string;
    
    @Column({ comment: 'Type' })
    type: string;
    
    @Column({ comment: 'Grade' })
    grade: string;
    
    @Column({ comment: 'N°' })
    registrationNumber: string;
    
    @OneToMany(type => TransportOrder, transportOrder => transportOrder.driver1)
    transportOrdersDriver1: TransportOrder[];
    
    @OneToMany(type => TransportOrder, transportOrder => transportOrder.driver2)
    transportOrdersDriver2: TransportOrder[];
}
