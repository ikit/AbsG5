import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { Squad } from "./Squad";

@Entity()
export class Regiment {
    @PrimaryGeneratedColumn({ comment: 'milfleet_regiment_id' })
    id: number;
    
    @Column({ comment: 'Nom' })
    name: string;

    @OneToMany(type => Squad, squad => squad.regiment)
    squads: Squad[];
}