import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";

@Entity()
export class User {
    @PrimaryGeneratedColumn({ comment: 'milfleet_user_id' })
    id: number;

    @Column({ comment: 'Nom et prénom' })
    name: string;

    @Column({ comment: 'Nom d utilisateur', unique: true })
    username: string;

    @Column({ comment: 'Mot de passe chiffré' })
    password: string;

    @Column({ comment: 'Email', unique: true })
    email: string;

    @Column({ comment: 'Token', nullable: true })
    token: string;
    
}
