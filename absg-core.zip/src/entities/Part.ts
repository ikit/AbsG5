import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class Part {
    @PrimaryGeneratedColumn({ comment: 'milfleet_part_id' })
    id: number;
    
    @Column({ comment: 'Nom' })
    name: string;               // ex: Moteur
    
    @Column({ comment: 'Niveau' })
    level: number;              // ex: 11

    @Column({ comment: 'Type' })
    type: string;               // ex: Moteur Equipe

    @Column({ comment: 'Code de nomenclature de gestion' })
    code: string;
}