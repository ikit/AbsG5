"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgpaController = void 0;
var typeorm_1 = require("typeorm");
var routing_controllers_1 = require("routing-controllers");
var entities_1 = require("../entities");
var AgpaService_1 = require("../services/AgpaService");
var agpaCommonHelpers_1 = require("../middleware/agpaCommonHelpers");
var AgpaController = /** @class */ (function () {
    function AgpaController() {
        this.photosRepo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
    }
    /**
     * Récupère les données d'initialisation des AGPA (contexte, metadata, ...)
     */
    AgpaController.prototype.welcome = function () {
        return (0, agpaCommonHelpers_1.getMetaData)();
    };
    /**
     * Récupère les données globale sur l'ensemble des éditions permettant de faire
     * le résumé des archives
     * @param session l'utilisateur qui fait la demande
     */
    AgpaController.prototype.archives = function (session) {
        return AgpaService_1.agpaService.getArchiveSummary(session);
    };
    /**
     * Récupère les données détaillées pour une édition en particulier
     * @param year
     * @param user
     */
    AgpaController.prototype.getEdition = function (year, user) {
        return AgpaService_1.agpaService.getArchiveEdition(year, user);
    };
    /**
     * Récupère les données détaillées pour une catégorie d'une édition en particulier
     * @param year
     * @param catId
     * @param user
     */
    AgpaController.prototype.getCategory = function (year, catId, user) {
        return AgpaService_1.agpaService.getArchiveCategory(year, catId, user);
    };
    /**
     * Permet de télécharger au format CSV les données des AGPA
     * @param year
     */
    AgpaController.prototype.getArchivesFile = function (year) {
        // TODO
        return "Zip AGPA-".concat(year, ".zip created");
    };
    AgpaController.prototype.getCeremony = function (year) {
        return AgpaService_1.agpaService.getCeremonyData(year);
    };
    AgpaController.prototype.notifyMasterSlide = function (year, slide, hash, user) {
        return AgpaService_1.agpaService.notifyMasterSlide(year, slide, hash, user);
    };
    AgpaController.prototype.getPalmares = function () {
        return AgpaService_1.agpaService.getPalmaresData();
    };
    /**
     * Récupère les informations de l'utilisateur pour la phase 1
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.getP1Data = function (user) {
        return AgpaService_1.agpaService.getP1Data(user);
    };
    /**
     * Récupère les informations de l'utilisateur pour la phase 2
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.getP2Data = function (user) {
        return AgpaService_1.agpaService.getP2Data(user);
    };
    /**
     * Récupère les informations de l'utilisateur pour la phase 3
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.getP3Data = function (user) {
        return AgpaService_1.agpaService.getP3Data(user);
    };
    /**
     * Récupère les informations de l'utilisateur pour la phase 3
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.closeEdition = function () {
        return AgpaService_1.agpaService.closeEdition();
    };
    /**
     * Effectue le dépouillement des votes
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.monitoring = function (year, user) {
        if (user.is("admin")) {
            return AgpaService_1.agpaService.monitoring(year, user);
        }
        else {
            return null;
        }
    };
    /**
     * Enregistre ou modifie une photo
     * @param image la photo si défini
     * @param body les informations sur la photo au format json
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.savePhoto = function (image, body, user) {
        return AgpaService_1.agpaService.savePhoto(body, image, user);
    };
    /**
     * Supprime une photo si autorisé
     * @param photoId
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.remove = function (photoId, user) {
        return AgpaService_1.agpaService.deletePhoto(photoId, user);
    };
    /**
     * Met à jour le vote d'un utilisateur pour une photo
     * @param photoId
     * @param vote
     * @param user l'utilisateur qui effectue la demande
     */
    AgpaController.prototype.vote = function (photoId, vote, user) {
        return AgpaService_1.agpaService.vote(photoId, vote, user);
    };
    __decorate([
        (0, routing_controllers_1.Get)(""),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "welcome", null);
    __decorate([
        (0, routing_controllers_1.Get)("/archives"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "archives", null);
    __decorate([
        (0, routing_controllers_1.Get)("/archives/:year([0-9]{4})"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getEdition", null);
    __decorate([
        (0, routing_controllers_1.Get)("/archives/:year([0-9]{4})/:catId([0-9]{1,2})"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __param(1, (0, routing_controllers_1.Param)("catId")),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Number, Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getCategory", null);
    __decorate([
        (0, routing_controllers_1.Get)("/archives/:year([0-9]{4})/files"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getArchivesFile", null);
    __decorate([
        (0, routing_controllers_1.Get)("/ceremony/:year([0-9]{4})"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getCeremony", null);
    __decorate([
        (0, routing_controllers_1.Get)("/ceremony/:year([0-9]{4})/notifyMasterSlide/:slide([0-9]+)/:hash"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __param(1, (0, routing_controllers_1.Param)("slide")),
        __param(2, (0, routing_controllers_1.Param)("hash")),
        __param(3, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Number, String, Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "notifyMasterSlide", null);
    __decorate([
        (0, routing_controllers_1.Get)("/palmares"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getPalmares", null);
    __decorate([
        (0, routing_controllers_1.Get)("/p1"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getP1Data", null);
    __decorate([
        (0, routing_controllers_1.Get)("/p2"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getP2Data", null);
    __decorate([
        (0, routing_controllers_1.Get)("/p3"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "getP3Data", null);
    __decorate([
        (0, routing_controllers_1.Get)("/close-edition"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "closeEdition", null);
    __decorate([
        (0, routing_controllers_1.Get)("/monitoring/:year([0-9]+)"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "monitoring", null);
    __decorate([
        (0, routing_controllers_1.Post)("/photo"),
        __param(0, (0, routing_controllers_1.UploadedFile)("image")),
        __param(1, (0, routing_controllers_1.Body)()),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object, Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "savePhoto", null);
    __decorate([
        (0, routing_controllers_1.Delete)("/photo/:photoId([0-9]+)"),
        __param(0, (0, routing_controllers_1.Param)("photoId")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "remove", null);
    __decorate([
        (0, routing_controllers_1.Get)("/vote/:photoId([0-9]+)/:vote"),
        __param(0, (0, routing_controllers_1.Param)("photoId")),
        __param(1, (0, routing_controllers_1.Param)("vote")),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Number, Object]),
        __metadata("design:returntype", void 0)
    ], AgpaController.prototype, "vote", null);
    AgpaController = __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.JsonController)("/agpa")
    ], AgpaController);
    return AgpaController;
}());
exports.AgpaController = AgpaController;
