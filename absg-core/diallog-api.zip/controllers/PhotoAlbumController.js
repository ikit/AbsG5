"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoAlbumController = void 0;
var typeorm_1 = require("typeorm");
var routing_controllers_1 = require("routing-controllers");
var entities_1 = require("../entities");
var PhotoAlbum_1 = require("../entities/PhotoAlbum");
var AlbumService_1 = require("../services/AlbumService");
var path = require("path");
var fs = require("fs");
var logger_1 = require("../middleware/logger");
var PhotoAlbumController = /** @class */ (function () {
    function PhotoAlbumController() {
        this.repo = (0, typeorm_1.getRepository)(entities_1.Photo);
        this.aRepo = (0, typeorm_1.getRepository)(PhotoAlbum_1.PhotoAlbum);
    }
    /**
     * Récupère la liste des albums
     * @param user l'utilisateur qui demande à voir la liste
     */
    PhotoAlbumController.prototype.listAlbums = function (user) {
        return __awaiter(this, void 0, void 0, function () {
            var albums;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.aRepo
                            .createQueryBuilder("a")
                            .where("a.family IS  NULL OR a.family = '".concat(user.rootFamily, "'"))
                            .orderBy("a.order")
                            .getMany()];
                    case 1:
                        albums = _a.sent();
                        return [2 /*return*/, albums.map(function (a) { return (__assign(__assign({}, a), { coverPhoto: "".concat(process.env.URL_FILES, "photos/").concat("absg_" + a.id.toString().padStart(4, "0"), "/WEB/").concat(a.coverPhoto, ".jpg") })); })];
                }
            });
        });
    };
    /**
     * Récupère les données pour initialiser le formulaire de création
     * d'album automatique
     */
    PhotoAlbumController.prototype.autoAlbum = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, {
                        totalPhoto: 3789,
                        persons: ["Annie Gueudelot", "Gérard Gueudelot"],
                        locations: ["Villons", "Lanslevillard", "Domaine de la Roche"],
                        from: "1976",
                        to: "2021"
                    }];
            });
        });
    };
    /**
     * Récupère parmi les photos triées celles qui répondent
     * aux critères de filtre fournit
     */
    PhotoAlbumController.prototype.getAutoAlbum = function (filters) {
        return __awaiter(this, void 0, void 0, function () {
            var where, pWhere, _i, _a, p, photos;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        where = [];
                        if (filters.from) {
                            where.push("p.date >= ".concat(filters.from));
                        }
                        if (filters.to) {
                            where.push("p.date <= ".concat(filters.to));
                        }
                        if (filters.places) {
                            where.push("place in ('".concat(filters.places.join("','"), "')"));
                        }
                        if (filters.persons) {
                            pWhere = [];
                            for (_i = 0, _a = filters.persons; _i < _a.length; _i++) {
                                p = _a[_i];
                                pWhere.push("persons::text LIKE ('%".concat(p, "%')"));
                            }
                            where.push("(".concat(pWhere.join(" OR "), ")"));
                        }
                        return [4 /*yield*/, this.repo
                                .createQueryBuilder("p")
                                .where(where.join(" AND "))
                                .orderBy("p.date, ")
                                .getMany()];
                    case 1:
                        photos = _b.sent();
                        return [2 /*return*/, photos.map(function (p) { return (__assign(__assign({}, p), { thumb: "".concat(process.env.URL_FILES, "photos/").concat(p.folder, "/THUMB/").concat(p.id, ".jpg"), url: "".concat(process.env.URL_FILES, "photos/").concat(p.folder, "/WEB/").concat(p.id, ".jpg") })); })];
                }
            });
        });
    };
    /**
     * Donne toutes les infos concernant un album
     * @param id l'identifiant de l'album
     * @param user l'utilisateur qui fait la demande
     */
    PhotoAlbumController.prototype.getAlbum = function (id, user) {
        return __awaiter(this, void 0, void 0, function () {
            var album, folder_1, photos;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.aRepo
                            .createQueryBuilder("a")
                            .where("a.id = ".concat(id, " AND (a.family IS  NULL OR a.family = '").concat(user.rootFamily, "')"))
                            .getOne()];
                    case 1:
                        album = _a.sent();
                        if (!album) return [3 /*break*/, 3];
                        folder_1 = "absg_" + album.id.toString().padStart(4, "0");
                        return [4 /*yield*/, this.repo
                                .createQueryBuilder("p")
                                .where("p.folder = '".concat(folder_1, "'"))
                                .leftJoinAndSelect("p.poster", "u")
                                .getMany()];
                    case 2:
                        photos = _a.sent();
                        album.photos = photos
                            .map(function (p) { return (__assign(__assign({}, p), { thumb: "".concat(process.env.URL_FILES, "photos/").concat(folder_1, "/THUMB/").concat(p.id, ".jpg"), url: "".concat(process.env.URL_FILES, "photos/").concat(folder_1, "/WEB/").concat(p.id, ".jpg"), order: album.photos.findIndex(function (e) { return e === p.id; }) })); })
                            .sort(function (a, b) { return a.order - b.order; });
                        _a.label = 3;
                    case 3: return [2 /*return*/, album];
                }
            });
        });
    };
    /**
     *  Met à jour l'album
     * @param id l'identifiant de l'album ) mettre à jour
     * @param album les données de l'album à mettre à jours
     */
    PhotoAlbumController.prototype.saveAlbum = function (id, album, user) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (user && album && (!album.family || album.family === user.rootFamily)) {
                    album.id = id;
                    album.photos = album.photos.map(function (p) { return p.id; });
                    return [2 /*return*/, this.aRepo.save(album)];
                }
                return [2 /*return*/, null];
            });
        });
    };
    /**
     * Donne toutes les infos concernant un album
     * @param id l'identifiant de l'album
     * @param user l'utilisateur qui fait la demande
     */
    PhotoAlbumController.prototype.download = function (id, user, response) {
        return __awaiter(this, void 0, void 0, function () {
            var filePath_1, err_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        filePath_1 = path.join(process.env.PATH_FILES, "/photos/", "".concat("absg_" + id.toString().padStart(4, "0"), "/RAW.zip"));
                        console.log(filePath_1);
                        if (!fs.existsSync(filePath_1)) {
                            // On crée le zip
                            console.log("File not exists");
                        }
                        return [4 /*yield*/, new Promise(function (resolve, reject) {
                                response.sendFile(filePath_1, function (err) {
                                    if (err)
                                        reject(err);
                                    resolve();
                                });
                            })];
                    case 1:
                        _a.sent();
                        // response.sendFile(filePath, "raw.zip");
                        return [2 /*return*/, response];
                    case 2:
                        err_1 = _a.sent();
                        logger_1.logger.error("Impossible de récupérer l'archive de l'album", err_1);
                        throw new Error("Impossible de récupérer l'archive de l'album");
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Enregistre une nouvelle photos dans l'album
     * @param image l'image
     * @param body d'autres informations sur l'image comme l'auteur et le titre
     */
    PhotoAlbumController.prototype.addPhoto = function (image, id, user) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, AlbumService_1.albumService.save(image, id, user)];
            });
        });
    };
    /**
     * Supprime une photo de l'album
     * @param id l'identifiant de l'album
     * @param photoId l'identifiant de la photo
     * @param user l'utilisateur qui fait la demande
     */
    PhotoAlbumController.prototype.deletePhoto = function (id, photoId, user) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, AlbumService_1.albumService.deletePhoto(id, photoId, user)];
            });
        });
    };
    __decorate([
        (0, routing_controllers_1.Get)("/"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [entities_1.User]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "listAlbums", null);
    __decorate([
        (0, routing_controllers_1.Get)("/auto"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "autoAlbum", null);
    __decorate([
        (0, routing_controllers_1.Post)("/auto"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "getAutoAlbum", null);
    __decorate([
        (0, routing_controllers_1.Get)("/:id"),
        __param(0, (0, routing_controllers_1.Param)("id")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, entities_1.User]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "getAlbum", null);
    __decorate([
        (0, routing_controllers_1.Post)("/:id"),
        __param(0, (0, routing_controllers_1.Param)("id")),
        __param(1, (0, routing_controllers_1.Body)()),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, PhotoAlbum_1.PhotoAlbum, entities_1.User]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "saveAlbum", null);
    __decorate([
        (0, routing_controllers_1.Get)("/:id/download"),
        __param(0, (0, routing_controllers_1.Param)("id")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __param(2, (0, routing_controllers_1.Res)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, entities_1.User, Object]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "download", null);
    __decorate([
        (0, routing_controllers_1.Post)("/:id/upload"),
        __param(0, (0, routing_controllers_1.UploadedFile)("file")),
        __param(1, (0, routing_controllers_1.Param)("id")),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Number, entities_1.User]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "addPhoto", null);
    __decorate([
        (0, routing_controllers_1.Delete)("/:id/:photoId"),
        __param(0, (0, routing_controllers_1.Param)("id")),
        __param(1, (0, routing_controllers_1.Param)("photoId")),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, String, entities_1.User]),
        __metadata("design:returntype", Promise)
    ], PhotoAlbumController.prototype, "deletePhoto", null);
    PhotoAlbumController = __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.JsonController)("/albums")
    ], PhotoAlbumController);
    return PhotoAlbumController;
}());
exports.PhotoAlbumController = PhotoAlbumController;
