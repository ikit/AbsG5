"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
var typeorm_1 = require("typeorm");
var routing_controllers_1 = require("routing-controllers");
var services_1 = require("../services");
var date_fns_1 = require("date-fns");
var entities_1 = require("../entities");
var agpaCommonHelpers_1 = require("../middleware/agpaCommonHelpers");
var UserController = /** @class */ (function () {
    function UserController() {
        this.repo = (0, typeorm_1.getRepository)(entities_1.Parameter);
    }
    /**
     * Récupère l'ensemble des informations de la page d'accueil:
     *  - Une citation aléatoire
     *  - Les 50 dernières notifications
     *  - Les paramètres de configuration du site (notament si il y a une annonce à afficher)
     */
    UserController.prototype.welcom = function (user) {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = {};
                        return [4 /*yield*/, services_1.citationService.random()];
                    case 1:
                        _a.citation = _b.sent();
                        return [4 /*yield*/, services_1.userService.getLastNotifications(user)];
                    case 2:
                        _a.notifications = _b.sent();
                        return [4 /*yield*/, this.getSettings()
                            //formerPassag: await userService.getFormerPass
                        ];
                    case 3:
                        result = (_a.settings = _b.sent(),
                            _a);
                        return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * Récupère l'ensemble des éléments nécessaire pour construire la page d'accueil
     *  - La dernière image du moment
     *  - L'historique des passages de la journée
     */
    UserController.prototype.home = function () {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _a = {};
                        return [4 /*yield*/, services_1.immtService.last()];
                    case 1:
                        _a.immt = _b.sent();
                        return [4 /*yield*/, services_1.userService.getPassag((0, date_fns_1.subDays)((0, date_fns_1.addHours)(new Date(), 1), 1))];
                    case 2:
                        _a.passag = _b.sent();
                        return [4 /*yield*/, services_1.eventService.getNextEvents()];
                    case 3:
                        result = (_a.events = _b.sent(),
                            _a);
                        return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * Récupère l'historique des passage sur le site des membres sur toute une année
     */
    UserController.prototype.passagHistory = function () {
        return services_1.userService.getPassagHistory();
    };
    /**
     * Récupère la liste de tout les paramètres du site
     */
    UserController.prototype.getSettings = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data, settings, _i, data_1, e;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.repo.query("SELECT * FROM parameter")];
                    case 1:
                        data = _a.sent();
                        settings = {};
                        for (_i = 0, data_1 = data; _i < data_1.length; _i++) {
                            e = data_1[_i];
                            settings[e.key] = e.value;
                        }
                        return [4 /*yield*/, this.repo.query("SELECT * FROM agpa_category_variation WHERE year = ".concat((0, agpaCommonHelpers_1.getCurrentEdition)()))];
                    case 2:
                        // On récupère les infos sur la catégorie spéciale de l'édition en cours
                        data = _a.sent();
                        if (data.length > 0) {
                            settings["agpaSpecialEdition"] = data[0];
                        }
                        else {
                            settings["agpaSpecialEdition"] = {
                                year: (0, agpaCommonHelpers_1.getCurrentEdition)(),
                                title: "",
                                description: ""
                            };
                        }
                        return [2 /*return*/, settings];
                }
            });
        });
    };
    /**
     * Met à jour les paramètres du site
     * @param settings
     */
    UserController.prototype.saveSettings = function (settings, user) {
        return __awaiter(this, void 0, void 0, function () {
            var sql, key;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(user && user.is("admin"))) return [3 /*break*/, 3];
                        sql = "";
                        for (key in settings) {
                            if (key == "agpaSpecialEdition") {
                                sql += "INSERT INTO agpa_category_variation (id, year, title, description)\n                            VALUES (8,  ".concat(settings.agpaSpecialEdition.year, ", '").concat(settings.agpaSpecialEdition.title, "', '").concat(settings.agpaSpecialEdition.description, "') \n                            ON CONFLICT (id, year) DO UPDATE\n                            SET title='").concat(settings.agpaSpecialEdition.title, "', description='").concat(settings.agpaSpecialEdition.description, "';");
                            }
                            else {
                                sql += "UPDATE parameter SET value='".concat(JSON.stringify(settings[key]), "' WHERE key = '").concat(key, "';");
                            }
                        }
                        return [4 /*yield*/, this.repo.query(sql)];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.getSettings()];
                    case 2: return [2 /*return*/, _a.sent()];
                    case 3: return [2 /*return*/, new Error("Vous n'avez pas les droits suffisant pour modifier les paramètres du site")];
                }
            });
        });
    };
    /**
     * Récupère les notifications d'un utilisateur
     */
    UserController.prototype.nadminNtifications = function (user) {
        return services_1.userService.getLastNotifications(user, true);
    };
    /**
     * Récupère les notifications d'un utilisateur
     */
    UserController.prototype.notifications = function (user) {
        return services_1.userService.getLastNotifications(user);
    };
    /**
     * Marque comme lu une notification pour l'utilisateur donné
     * @param notifId l'identifiant de la notification
     * @param user l'utilisateur concerné
     */
    UserController.prototype.markAllAsRead = function (user) {
        services_1.userService.markAllAsRead(user);
        return true;
    };
    /**
     * Marque comme lu une notification pour l'utilisateur donné
     * @param notifId l'identifiant de la notification
     * @param user l'utilisateur concerné
     */
    UserController.prototype.markAsRead = function (notifId, user) {
        services_1.userService.markAsRead(notifId, user);
        return true;
    };
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Get)("/welcom"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [entities_1.User]),
        __metadata("design:returntype", Promise)
    ], UserController.prototype, "welcom", null);
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Get)("/homepage"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], UserController.prototype, "home", null);
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Get)("/passag"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], UserController.prototype, "passagHistory", null);
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Get)("/settings"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], UserController.prototype, "getSettings", null);
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Post)("/settings"),
        __param(0, (0, routing_controllers_1.Body)()),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, entities_1.User]),
        __metadata("design:returntype", Promise)
    ], UserController.prototype, "saveSettings", null);
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Get)("/admin/notifications"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [entities_1.User]),
        __metadata("design:returntype", void 0)
    ], UserController.prototype, "nadminNtifications", null);
    __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.Get)("/notifications"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [entities_1.User]),
        __metadata("design:returntype", void 0)
    ], UserController.prototype, "notifications", null);
    __decorate([
        (0, routing_controllers_1.Get)("/markAsRead/all"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [entities_1.User]),
        __metadata("design:returntype", void 0)
    ], UserController.prototype, "markAllAsRead", null);
    __decorate([
        (0, routing_controllers_1.Get)("/markAsRead/:notifId([0-9]+)"),
        __param(0, (0, routing_controllers_1.Param)("notifId")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], UserController.prototype, "markAsRead", null);
    UserController = __decorate([
        (0, routing_controllers_1.JsonController)("")
    ], UserController);
    return UserController;
}());
exports.UserController = UserController;
