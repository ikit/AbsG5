"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForumController = void 0;
var routing_controllers_1 = require("routing-controllers");
var entities_1 = require("../entities");
var services_1 = require("../services");
var ForumController = /** @class */ (function () {
    function ForumController() {
    }
    /**
     * Renvoie la liste des forums
     */
    ForumController.prototype.getForums = function () {
        return services_1.forumService.getForums();
    };
    /**
     * Renvoie la liste des sujets d'un forum
     */
    ForumController.prototype.getTopics = function (forumId) {
        return services_1.forumService.getTopics(forumId);
    };
    /**
     * Renvoie la liste des messages d'une discussion
     */
    ForumController.prototype.getPosts = function (topicId) {
        return services_1.forumService.getPosts(topicId);
    };
    /**
     * Récupère les messages TBZ en fonction des paramètres année et mois fournis
     * @param year l'année
     * @param day  le mois de 1 à 12
     */
    ForumController.prototype.getTbz = function (year, month) {
        return services_1.forumService.getTbzPosts(year, month);
    };
    /**
     * Enregistre une pièce jointe sur le serveur
     * @param body les infos sur le message à poster
     * @param user l'utilisateur qui fait la demande
     * /!\ Note: je force l'usage du multipart/form-data avec @UploadedFile car
     *     sinon la limite en taille des body/json empeche de poster des messages avec image encodé
     */
    ForumController.prototype.savePost = function (image, body, user) {
        return services_1.forumService.savePost(body, user);
    };
    /**
     * Supprime un message du forum
     * @param id l'identifiant du message
     * @param user
     */
    ForumController.prototype.deletePost = function (id, user) {
        return services_1.forumService.deletePost(id, user);
    };
    /**
     * Retourne la liste des sujets mis en avant
     */
    ForumController.prototype.pinnedTopics = function () {
        return services_1.forumService.pinnedTopics();
    };
    /**
     * Met en avant un sujet ou le retire
     * @param id l'identifiant du sujet
     */
    ForumController.prototype.switchPin = function (id) {
        return services_1.forumService.switchPin(id);
    };
    /**
     * Enregistre une pièce jointe sur le serveur
     * @param file la pièce jointe
     * @param user l'utilisateur qui fait la demande
     */
    ForumController.prototype.saveFile = function (file, user) {
        return services_1.forumService.saveFile(file, user.id);
    };
    /**
     * Supprime une pièce jointe du serveur
     * @param fileURI
     * @param user
     */
    ForumController.prototype.deleteFile = function (fileURI, user) {
        return services_1.forumService.deleteFile(decodeURI(fileURI), user);
    };
    /**
     * Sauvegarde un message en cours d'édition pour l'utilisateur courrant
     * @param body
     * @param user
     */
    ForumController.prototype.saveDraft = function (body, user) {
        return services_1.forumService.saveDraft(body, user.id);
    };
    /**
     * Récupère le brouillon en cours d'édition de l'utilisateur si il existe
     * @param user
     */
    ForumController.prototype.getDraft = function (user) {
        return services_1.forumService.getDraft(user.id);
    };
    __decorate([
        (0, routing_controllers_1.Get)("/browse"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "getForums", null);
    __decorate([
        (0, routing_controllers_1.Get)("/browse/:forumId"),
        __param(0, (0, routing_controllers_1.Param)("forumId")),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "getTopics", null);
    __decorate([
        (0, routing_controllers_1.Get)("/read/:topicId/"),
        __param(0, (0, routing_controllers_1.Param)("topicId")),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "getPosts", null);
    __decorate([
        (0, routing_controllers_1.Get)("/tbz/:year([0-9]{4})/:month([0-9]{1,2})"),
        __param(0, (0, routing_controllers_1.Param)("year")),
        __param(1, (0, routing_controllers_1.Param)("month")),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Number]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "getTbz", null);
    __decorate([
        (0, routing_controllers_1.Post)("/post"),
        __param(0, (0, routing_controllers_1.UploadedFile)("image")),
        __param(1, (0, routing_controllers_1.Body)()),
        __param(2, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "savePost", null);
    __decorate([
        (0, routing_controllers_1.Delete)("/post/:id"),
        __param(0, (0, routing_controllers_1.Param)("id")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "deletePost", null);
    __decorate([
        (0, routing_controllers_1.Get)("/pinnedTopics"),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "pinnedTopics", null);
    __decorate([
        (0, routing_controllers_1.Get)("/topic/:id/switchPin"),
        __param(0, (0, routing_controllers_1.Param)("id")),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "switchPin", null);
    __decorate([
        (0, routing_controllers_1.Post)("/uploadFile"),
        __param(0, (0, routing_controllers_1.UploadedFile)("file")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "saveFile", null);
    __decorate([
        (0, routing_controllers_1.Delete)("/uploadFile/:fileURI"),
        __param(0, (0, routing_controllers_1.Param)("fileURI")),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "deleteFile", null);
    __decorate([
        (0, routing_controllers_1.Post)("/draft"),
        __param(0, (0, routing_controllers_1.Body)()),
        __param(1, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, entities_1.User]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "saveDraft", null);
    __decorate([
        (0, routing_controllers_1.Get)("/draft"),
        __param(0, (0, routing_controllers_1.CurrentUser)()),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [entities_1.User]),
        __metadata("design:returntype", void 0)
    ], ForumController.prototype, "getDraft", null);
    ForumController = __decorate([
        (0, routing_controllers_1.Authorized)(),
        (0, routing_controllers_1.JsonController)("/forum")
    ], ForumController);
    return ForumController;
}());
exports.ForumController = ForumController;
