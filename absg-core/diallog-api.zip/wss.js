"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var WebSocket = require("ws");
var port = process.env.WS_PORT;
var wss = new WebSocket.Server({ port: port });
// wss.on("connection", () => {
//     logger.debug("WS client connection established");
// });
exports.default = wss;
