"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv").config();
require("reflect-metadata");
var typeorm_1 = require("typeorm");
var routing_controllers_1 = require("routing-controllers");
var logger_1 = require("./middleware/logger");
var middleware_1 = require("./middleware");
var express = require("express");
var fileUpload = require("express-fileupload");
var services_1 = require("./services");
var ormconfig = require("../ormconfig");
var AlbumService_1 = require("./services/AlbumService");
(0, typeorm_1.createConnections)(ormconfig)
    .then(function () {
    logger_1.logger.info("ORM connection created");
    // Une fois la connection créé, on peut initialialiser les services
    services_1.agendaService.initService();
    services_1.agpaService.initService();
    services_1.citationService.initService();
    services_1.eventService.initService();
    services_1.forumService.initService();
    services_1.immtService.initService();
    services_1.voyagService.initService();
    services_1.userService.initService();
    AlbumService_1.albumService.initService();
    services_1.gthequeService.initService();
    logger_1.logger.info("AbsG services initialized");
    // create express app
    var app = (0, routing_controllers_1.createExpressServer)({
        routePrefix: "/api",
        controllers: [__dirname + "/controllers/*.ts", __dirname + "/controllers/*.js"],
        authorizationChecker: middleware_1.jwtAuthorizationChecker,
        currentUserChecker: middleware_1.currentUserChecker
    });
    if (process.env.NODE_ENV === "development") {
        app.use("/files", express.static(process.env.PATH_FILES));
    }
    // enable files upload
    app.use(fileUpload({
        createParentPath: true
    }));
    app.use(express.json({ limit: "50mb" }));
    app.use(express.urlencoded({ extended: true, limit: "50mb" }));
    app.use((0, logger_1.accessLogHandler)()); // access logs
    app.use((0, logger_1.errorLogHandler)()); // error logs
    // start express server
    app.listen(process.env.API_PORT);
    logger_1.logger.info("Server has started on port ".concat(process.env.API_PORT, "."));
})
    .catch(function (error) {
    console.error(error);
    logger_1.logger.error(error);
});
