"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.agendaService = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var logger_1 = require("../middleware/logger");
var fs = require("fs");
var path = require("path");
var commonHelper_1 = require("../middleware/commonHelper");
var date_fns_1 = require("date-fns");
var AgendaService = /** @class */ (function () {
    function AgendaService() {
        this.personsRepo = null;
        this.placesRepo = null;
    }
    AgendaService.prototype.initService = function () {
        this.personsRepo = (0, typeorm_1.getRepository)(entities_1.Person);
        this.placesRepo = (0, typeorm_1.getRepository)(entities_1.Place);
    };
    /**
     * Récupère la liste de toutes les personnes de l'agenda
     */
    AgendaService.prototype.listPersons = function () {
        return __awaiter(this, void 0, void 0, function () {
            var persons;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.personsRepo
                            .createQueryBuilder("p")
                            .orderBy("p.lastname")
                            .addOrderBy("p.firstname")
                            .getMany()];
                    case 1:
                        persons = _a.sent();
                        return [2 /*return*/, persons.map(function (e) {
                                var p = new entities_1.Person().fromJSON(e);
                                return __assign(__assign({}, p), { fullname: p.getFullname(), thumb: p.photo ? "".concat(process.env.URL_FILES, "persons/mini/").concat(p.photo) : null, url: p.photo ? "".concat(process.env.URL_FILES, "persons/").concat(p.photo) : null });
                            })];
                }
            });
        });
    };
    /**
     * Crée ou modifie (si l'id est renseigné) une entrée de répertoire
     * @param personData l'entrée du répertoire
     * @param image l'image pour illustrer la personne dans le répertoire
     * @param user l'utilisateur qui demande l'action
     */
    AgendaService.prototype.savePerson = function (personData, image, user) {
        return __awaiter(this, void 0, void 0, function () {
            var personId, person, thumb, web;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        personId = Number.parseInt(personData.id);
                        person = new entities_1.Person();
                        if (!personId) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.personsRepo.findOne(personId)];
                    case 1:
                        person = _a.sent();
                        _a.label = 2;
                    case 2:
                        personData.id = personId ? personId : null; // pour éviter les problèmes lors du save en DB
                        person.fromJSON(personData);
                        return [4 /*yield*/, this.personsRepo.save(person)];
                    case 3:
                        person = _a.sent();
                        if (!image) return [3 /*break*/, 5];
                        thumb = path.join(process.env.PATH_FILES, "persons/mini/".concat(person.id, ".jpg"));
                        web = path.join(process.env.PATH_FILES, "persons/".concat(person.id, ".jpg"));
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(image.buffer, thumb, web, null)];
                    case 4:
                        _a.sent();
                        person.photo = "".concat(person.id, ".jpg");
                        this.personsRepo.save(person);
                        _a.label = 5;
                    case 5:
                        logger_1.logger.notice(personId
                            ? "La fiche de \"".concat(person.getFullname(), "\" a \u00E9t\u00E9 modifi\u00E9e dans le r\u00E9pertoire par ").concat(user.username)
                            : "Nouvelle fiche \"".concat(person.getFullname(), "\" a \u00E9t\u00E9 ajout\u00E9e au r\u00E9pertoire par ").concat(user.username), {
                            userId: user.id,
                            module: entities_1.LogModule.agenda
                        });
                        return [2 /*return*/, __assign(__assign({}, person), { thumb: person.photo ? "".concat(process.env.URL_FILES, "persons/").concat(person.photo) : null, url: person.photo ? "".concat(process.env.URL_FILES, "persons/").concat(person.photo) : null })];
                }
            });
        });
    };
    /**
     * récupère la liste de tous les lieux enregistrés dans l'agenda
     */
    AgendaService.prototype.listPlaces = function () {
        return __awaiter(this, void 0, void 0, function () {
            var places;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.placesRepo
                            .createQueryBuilder("p")
                            .orderBy("p.name")
                            .getMany()];
                    case 1:
                        places = _a.sent();
                        return [2 /*return*/, places.map(function (p) { return (__assign(__assign({}, p), { thumb: p.photo ? "".concat(process.env.URL_FILES, "places/mini/").concat(p.photo) : null, url: p.photo ? "".concat(process.env.URL_FILES, "places/").concat(p.photo) : null })); })];
                }
            });
        });
    };
    /**
     * Crée ou modifie (si l'id est renseigné) un lieux dans l'agenda
     * @param placeData les données sur le lieux
     * @param image l'image pour illustrer le lieux
     * @param user l'utilisateur qui demande l'action
     */
    AgendaService.prototype.savePlace = function (placeData, image, user) {
        return __awaiter(this, void 0, void 0, function () {
            var placeId, place, thumb, web;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        placeId = Number.parseInt(placeData.id);
                        place = new entities_1.Place();
                        if (!placeId) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.placesRepo.findOne(placeId)];
                    case 1:
                        place = _a.sent();
                        _a.label = 2;
                    case 2:
                        placeData.id = placeId ? placeId : null; // pour éviter les problèmes lors du save en DB
                        place.fromJSON(placeData);
                        return [4 /*yield*/, this.placesRepo.save(place)];
                    case 3:
                        place = _a.sent();
                        if (!image) return [3 /*break*/, 5];
                        thumb = path.join(process.env.PATH_FILES, "places/mini/".concat(place.id, ".jpg"));
                        web = path.join(process.env.PATH_FILES, "places/".concat(place.id, ".jpg"));
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(image.buffer, thumb, web, null)];
                    case 4:
                        _a.sent();
                        place.photo = "".concat(place.id, ".jpg");
                        this.placesRepo.save(place);
                        _a.label = 5;
                    case 5:
                        logger_1.logger.notice(placeId
                            ? "Le lieu \"".concat(place.name, "\" a \u00E9t\u00E9 modifi\u00E9 dans le r\u00E9pertoire par ").concat(user.username)
                            : "Nouveau lieu \"".concat(place.name, "\" a \u00E9t\u00E9 ajout\u00E9 au r\u00E9pertoire par ").concat(user.username), {
                            userId: user.id,
                            module: entities_1.LogModule.agenda
                        });
                        return [2 /*return*/, __assign(__assign({}, place), { thumb: place.photo ? "".concat(process.env.URL_FILES, "places/").concat(place.photo) : null, url: place.photo ? "".concat(process.env.URL_FILES, "places/").concat(place.photo) : null })];
                }
            });
        });
    };
    /**
     * Récupère la liste complète des photos du trombinoscope
     */
    AgendaService.prototype.listTrombi = function () {
        return __awaiter(this, void 0, void 0, function () {
            var personsData, persons, _i, personsData_1, p, filesList, folderPath, files;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.personsRepo
                            .createQueryBuilder("p")
                            .orderBy("p.lastname")
                            .addOrderBy("p.firstname")
                            .getMany()];
                    case 1:
                        personsData = _a.sent();
                        persons = {};
                        for (_i = 0, personsData_1 = personsData; _i < personsData_1.length; _i++) {
                            p = personsData_1[_i];
                            persons[p.id] = new entities_1.Person().fromJSON(p);
                        }
                        filesList = [];
                        folderPath = path.join(process.env.PATH_FILES, "trombi");
                        return [4 /*yield*/, fs.readdirSync(folderPath)];
                    case 2:
                        files = _a.sent();
                        files.forEach(function (file) {
                            if (fs.statSync(path.join(folderPath, file)).isFile() && file.endsWith("jpg")) {
                                var tokens = file.substring(0, file.length - 4).split("_");
                                if (tokens.length === 2 && persons.hasOwnProperty(tokens[0])) {
                                    var pid = tokens[0];
                                    var year = Number.parseInt(tokens[1].substr(0, 4));
                                    var month = Number.parseInt(tokens[1].substr(4, 2));
                                    var day = Number.parseInt(tokens[1].substr(6));
                                    var p = persons[pid];
                                    filesList.push({
                                        pid: pid,
                                        date: new Date(year, month, day),
                                        title: "".concat(p.getFullname(), " - ").concat(year, " - ").concat(p.getAge(year)),
                                        thumb: "".concat(process.env.URL_FILES, "trombi/mini/").concat(file),
                                        url: "".concat(process.env.URL_FILES, "trombi/").concat(file)
                                    });
                                }
                            }
                        });
                        // On retourne la liste "mélangée"
                        return [2 /*return*/, filesList.sort(function () { return 0.5 - Math.random(); })];
                }
            });
        });
    };
    AgendaService.prototype.saveTrombi = function (trombiData, image, user) {
        return __awaiter(this, void 0, void 0, function () {
            var p, d, filename, title, thumb, url;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(image && trombiData && trombiData.person && trombiData.date)) return [3 /*break*/, 2];
                        p = new entities_1.Person().fromJSON(JSON.parse(trombiData.person));
                        d = new Date(trombiData.date);
                        filename = "".concat(p.id, "_").concat((0, date_fns_1.format)(d, "YYYYMMDD"), ".jpg");
                        title = "".concat(p.getFullname(), " - ").concat(d.getFullYear(), " - ").concat(p.getAge(d.getFullYear()));
                        thumb = path.join(process.env.PATH_FILES, "trombi/mini/".concat(filename));
                        url = path.join(process.env.PATH_FILES, "trombi/".concat(filename));
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(image.buffer, thumb, url, null)];
                    case 1:
                        _a.sent();
                        logger_1.logger.notice("Nouvelle trombinette \"".concat(title, "\" a \u00E9t\u00E9 ajout\u00E9e par ").concat(user.username), {
                            userId: user.id,
                            module: entities_1.LogModule.agenda
                        });
                        return [2 /*return*/, {
                                pid: p.id,
                                date: d,
                                title: title,
                                thumb: "".concat(process.env.URL_FILES, "trombi/mini/").concat(filename),
                                url: "".concat(process.env.URL_FILES, "trombi/").concat(filename)
                            }];
                    case 2: return [2 /*return*/, null];
                }
            });
        });
    };
    return AgendaService;
}());
exports.agendaService = new AgendaService();
