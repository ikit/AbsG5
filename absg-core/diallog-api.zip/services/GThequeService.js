"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gthequeService = void 0;
var path = require("path");
var commonHelper_1 = require("../middleware/commonHelper");
var GThequeCollection_1 = require("../entities/GThequeCollection");
var typeorm_1 = require("typeorm");
var GTheque_1 = require("../entities/GTheque");
var urljoin = require("url-join");
var GThequeService = /** @class */ (function () {
    function GThequeService() {
        this.collectionRepo = null;
        this.thequeRepo = null;
        this.defaultFolderThumb = urljoin(process.env.URL_FILES, "cloud", "_", "thumb.folder.png");
        this.defaultFileThumb = urljoin(process.env.URL_FILES, "cloud", "_", "thumb.file.png");
    }
    GThequeService.prototype.initService = function () {
        this.collectionRepo = (0, typeorm_1.getRepository)(GThequeCollection_1.GThequeCollection);
        this.thequeRepo = (0, typeorm_1.getRepository)(GTheque_1.GTheque);
    };
    /**
     * Retourne l'arborescence de fichier disponnible dans le theque en fonction des droits de l'utilisateur
     * @param user l'utilisateur qui demande à voir l'arborescence
     */
    GThequeService.prototype.getGTheque = function (user) {
        return __awaiter(this, void 0, void 0, function () {
            var col, result, cIdx, c, idx;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.thequeRepo
                            .createQueryBuilder("t")
                            .leftJoinAndSelect("t.collection", "c")
                            .where("t.\"userId\" = ".concat(user.id))
                            .orderBy("c.title", "ASC")
                            .getMany()];
                    case 1:
                        col = _a.sent();
                        result = col.map(function (c) { return (__assign(__assign({}, c.collection), { count: c.data.filter(function (e) { return e; }).length, total: c.collection.items.length })); });
                        for (cIdx = 0; cIdx < result.length; cIdx++) {
                            c = result[cIdx];
                            for (idx = 0; idx < c.items.length; idx++) {
                                c.items[idx].ok = col[cIdx].data[idx];
                            }
                        }
                        return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * Récupère la liste de toutes les collections définies en base
     */
    GThequeService.prototype.getCollections = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.collectionRepo
                        .createQueryBuilder("c")
                        .orderBy("c.title", "ASC")
                        .getMany()];
            });
        });
    };
    /**
     * Retourne l'arbirescence de tout les fichiers présent dans le grenier
     */
    GThequeService.prototype.getGrenaryFiles = function () {
        var _this = this;
        var localFiles = (0, commonHelper_1.fetchFolder)(path.join(process.env.PATH_FILES, "cloud"));
        var sortFolder = function (list) {
            return list
                .filter(function (f) { return f !== null; })
                .sort(function (a, b) {
                console.log(a, b);
                // On trie par ordre les dossier avant les fichiers
                if (a.type === "folder" && b.type !== "folder") {
                    return -1;
                }
                if (a.type !== "folder" && b.type === "folder") {
                    return 1;
                }
                if (a.type === "foler" && b.type === "folder") {
                    return a.name.localeCompare(b.name);
                }
                // Pour les fichiers on tri par ordre chronologique puis par titre croissant
                return a.date !== b.date ? a.date.localeCompare(b.date) : a.name.localeCompare(b.name);
            });
        };
        // méthode récursive pour l'analye et la mise en forme de l'arborescence
        var parseFolder = function (item, list, rootPath) {
            if (item.name.startsWith("_")) {
                return null; // dossier/fichier technique a ignorer
            }
            if (item.type === "folder") {
                var localPath_1 = urljoin(rootPath, item.name);
                var thumb_1 = item.content.find(function (f) { return f.name === "_thumb.".concat(item.name); });
                if (thumb_1) {
                    thumb_1 = urljoin(process.env.URL_FILES, "cloud", rootPath, "".concat(thumb_1.name).concat(thumb_1.type));
                }
                else {
                    thumb_1 = _this.defaultFolderThumb;
                }
                var content = item.content.map(function (f) { return parseFolder(f, item.content, localPath_1); }).filter(function (f) { return f !== null; });
                // Si le dossier ne contient rien, on l'ignore
                if (content.length === 0) {
                    return null;
                }
                // On retourne le fichier correctement formaté
                return {
                    name: item.name,
                    type: item.type,
                    content: sortFolder(content),
                    path: "/" + localPath_1,
                    thumb: thumb_1
                };
            }
            // Pour les fichier, on récupère le thumb et on l'url publique
            var thumb = list.find(function (f) { return f.name === "_thumb.".concat(item.name); });
            if (thumb) {
                thumb = urljoin(process.env.URL_FILES, "cloud", rootPath, "".concat(thumb.name).concat(thumb.type));
            }
            else {
                thumb = _this.defaultFileThumb;
            }
            var url = urljoin(process.env.URL_FILES, "cloud", rootPath, item.name + item.type);
            var tokens = item.name.split(" - ");
            item.date = tokens[0];
            item.author = tokens[1];
            item.name = tokens.splice(2).join(" - ");
            return __assign(__assign({}, item), { thumb: thumb, url: url });
        };
        return sortFolder(localFiles.map(function (f) { return parseFolder(f, localFiles, ""); }));
    };
    return GThequeService;
}());
exports.gthequeService = new GThequeService();
