"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.forumService = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var date_fns_1 = require("date-fns");
var locale_1 = require("date-fns/locale");
var path = require("path");
var fs = require("fs");
var commonHelper_1 = require("../middleware/commonHelper");
var routing_controllers_1 = require("routing-controllers");
var WebsocketService_1 = require("./WebsocketService");
var logger_1 = require("../middleware/logger");
var ForumService = /** @class */ (function () {
    function ForumService() {
        this.forumRepo = null;
        this.topicRepo = null;
        this.msgRepo = null;
        this.userRepo = null;
    }
    ForumService.prototype.initService = function () {
        this.forumRepo = (0, typeorm_1.getRepository)(entities_1.Forum);
        this.topicRepo = (0, typeorm_1.getRepository)(entities_1.ForumTopic);
        this.msgRepo = (0, typeorm_1.getRepository)(entities_1.ForumMessage);
        this.userRepo = (0, typeorm_1.getRepository)(entities_1.User);
    };
    /**
     * Renvoie une discussion au hasard
     */
    ForumService.prototype.random = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.topicRepo
                        .createQueryBuilder("c")
                        .leftJoinAndSelect("c.author", "a")
                        .leftJoinAndSelect("c.poster", "p")
                        .orderBy("RANDOM()")
                        .getOne()];
            });
        });
    };
    /**
     * Renvoie la liste des forums
     */
    ForumService.prototype.getForums = function () {
        return __awaiter(this, void 0, void 0, function () {
            var forums;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.forumRepo
                            .createQueryBuilder("f")
                            .leftJoinAndSelect("f.lastMessage", "m")
                            .leftJoinAndSelect("m.poster", "p")
                            .orderBy("f.id")
                            .getMany()];
                    case 1:
                        forums = _a.sent();
                        return [2 /*return*/, forums.map(function (f) { return ({
                                id: f.id,
                                name: f.name,
                                description: f.description,
                                archived: f.archived,
                                last: {
                                    username: f.lastMessage.poster.username,
                                    dateLabel: (0, date_fns_1.format)(new Date(f.lastMessage.datetime), "dddd D MMM YYYY à HH:mm", { locale: locale_1.fr }),
                                    avatar: "/files/avatars/".concat(f.lastMessage.poster.id.toString().padStart(3, "0"), ".png")
                                }
                            }); })];
                }
            });
        });
    };
    /**
     * Renvoie la liste des sujets d'un forum
     */
    ForumService.prototype.getTopics = function (forumId) {
        return __awaiter(this, void 0, void 0, function () {
            var forum, topics;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.forumRepo
                            .createQueryBuilder("f")
                            .where("f.id = ".concat(forumId))
                            .getOne()];
                    case 1:
                        forum = _a.sent();
                        return [4 /*yield*/, this.topicRepo
                                .createQueryBuilder("c")
                                .leftJoin("c.forum", "f")
                                .leftJoinAndSelect("c.firstMessage", "m1")
                                .leftJoinAndSelect("m1.poster", "p1")
                                .leftJoinAndSelect("c.lastMessage", "m2")
                                .leftJoinAndSelect("m2.poster", "p2")
                                .where("c.\"forumId\" = ".concat(forumId))
                                .orderBy("m2.datetime", "DESC")
                                .getMany()];
                    case 2:
                        topics = _a.sent();
                        return [2 /*return*/, {
                                forum: forum,
                                topics: topics.map(function (t) { return ({
                                    id: t.id,
                                    name: t.name,
                                    first: {
                                        username: t.firstMessage.poster.username,
                                        dateLabel: (0, date_fns_1.format)(new Date(t.firstMessage.datetime), "dddd D MMM YYYY à HH:mm", { locale: locale_1.fr })
                                    },
                                    last: {
                                        id: t.lastMessage.id,
                                        username: t.lastMessage.poster.username,
                                        dateLabel: (0, date_fns_1.format)(new Date(t.lastMessage.datetime), "dddd D MMM YYYY à HH:mm", { locale: locale_1.fr }),
                                        avatar: "/files/avatars/".concat(t.lastMessage.poster.id.toString().padStart(3, "0"), ".png")
                                    }
                                }); })
                            }];
                }
            });
        });
    };
    /**
     * Renvoie la liste des messages d'une discussion
     */
    ForumService.prototype.getPosts = function (topicId) {
        return __awaiter(this, void 0, void 0, function () {
            var topic, posts;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.topicRepo
                            .createQueryBuilder("c")
                            .leftJoinAndSelect("c.forum", "f")
                            .leftJoinAndSelect("c.firstMessage", "m1")
                            .leftJoinAndSelect("c.lastMessage", "m2")
                            .where("c.id = ".concat(topicId))
                            .getOne()];
                    case 1:
                        topic = _a.sent();
                        return [4 /*yield*/, this.msgRepo
                                .createQueryBuilder("m")
                                .leftJoin("m.topic", "t")
                                .leftJoinAndSelect("m.poster", "p")
                                .where("t.id = ".concat(topicId))
                                .orderBy("m.datetime", "ASC")
                                .getMany()];
                    case 2:
                        posts = _a.sent();
                        return [2 /*return*/, {
                                topic: topic,
                                posts: posts.map(function (e) { return (__assign(__assign({}, e), { text: _this.parseMessageText(e.text), dateLabel: (0, date_fns_1.format)(new Date(e.datetime), "dddd D MMM YYYY", { locale: locale_1.fr }), timeLabel: (0, date_fns_1.format)(new Date(e.datetime), "HH:mm", { locale: locale_1.fr }), shortLabel: (0, date_fns_1.format)(new Date(e.datetime), "le D MMM YYYY à HH:mm", { locale: locale_1.fr }), poster: {
                                        id: e.poster.id,
                                        rootFamily: e.poster.rootFamily,
                                        username: e.poster.username,
                                        avatar: "/files/avatars/".concat(e.poster.id.toString().padStart(3, "0"), ".png")
                                    } })); })
                            }];
                }
            });
        });
    };
    /**
     * Renvoie les messages TBZ en fonction de l'année et du mois
     * @param year par défaut l'année courrante
     * @param month par défaut le mois courrant (de 0 à 11)
     */
    ForumService.prototype.getTbzPosts = function (year, month) {
        if (year === void 0) { year = null; }
        if (month === void 0) { month = null; }
        return __awaiter(this, void 0, void 0, function () {
            var from, to, data;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        // controle sur les paramètres
                        year = year ? year : new Date().getFullYear();
                        month = month !== null && month >= 0 && month <= 11 ? month : new Date().getMonth();
                        from = new Date(year, month, 1, 1, 0, 0);
                        to = (0, date_fns_1.addMonths)(from, 1);
                        to = new Date(to.getFullYear(), to.getMonth(), 1, 1, 0, 0);
                        return [4 /*yield*/, this.msgRepo
                                .createQueryBuilder("m")
                                .leftJoin("m.forum", "f")
                                .leftJoinAndSelect("m.poster", "p")
                                .where("f.id = 2")
                                .andWhere({ datetime: (0, typeorm_1.Between)(from, to) })
                                .orderBy("m.datetime", "ASC")
                                .getMany()];
                    case 1:
                        data = _a.sent();
                        return [2 /*return*/, {
                                forumId: 2,
                                topicId: -1,
                                posts: data.map(function (e) { return (__assign(__assign({}, e), { text: _this.parseMessageText(e.text), dateLabel: (0, date_fns_1.format)(new Date(e.datetime), "dddd D à HH:mm", { locale: locale_1.fr }), poster: {
                                        id: e.poster.id,
                                        rootFamily: e.poster.rootFamily,
                                        username: e.poster.username,
                                        avatar: "/files/avatars/".concat(e.poster.id.toString().padStart(3, "0"), ".png")
                                    } })); })
                            }];
                }
            });
        });
    };
    /**
     * Enregistre une pièce jointe sur le serveur
     * @param data les infos sur le message à poster
     * @param user l'utilisateur qui fait la demande
     */
    ForumService.prototype.savePost = function (data, user) {
        return __awaiter(this, void 0, void 0, function () {
            var msg, topic, forum, bases64data, currentYear, _i, bases64data_1, img64, imageBuffer, fileName, fileExt, thumbPath, webPath, webUrl, tname;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        msg = null;
                        topic = null;
                        forum = null;
                        if (!data.forumId) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.forumRepo.findOne({ where: { id: data.forumId } })];
                    case 1:
                        forum = _a.sent();
                        return [3 /*break*/, 3];
                    case 2: throw new Error("Le forum doit obligatoirement être renseigné");
                    case 3:
                        if (!data.topicId) return [3 /*break*/, 5];
                        return [4 /*yield*/, this.topicRepo.findOne({ where: { id: data.topicId } })];
                    case 4:
                        topic = _a.sent();
                        return [3 /*break*/, 8];
                    case 5:
                        if (!data.topicTitle) return [3 /*break*/, 7];
                        topic = new entities_1.ForumTopic();
                        topic.forum = forum;
                        topic.pinned = true;
                        topic.name = data.topicTitle;
                        return [4 /*yield*/, this.topicRepo.save(topic)];
                    case 6:
                        _a.sent();
                        return [3 /*break*/, 8];
                    case 7: throw new Error("Veuillez indiquer le sujet ou bien lui donner un titre");
                    case 8:
                        if (!data.postId) return [3 /*break*/, 10];
                        return [4 /*yield*/, this.msgRepo.findOne({ where: { id: data.postId } })];
                    case 9:
                        msg = _a.sent();
                        _a.label = 10;
                    case 10:
                        if (!msg) {
                            msg = new entities_1.ForumMessage();
                            msg.forum = forum;
                            msg.topic = topic;
                        }
                        // On met à jour le message
                        msg.text = data.text;
                        msg.datetime = !data.postId ? new Date() : msg.datetime;
                        msg.poster = user;
                        bases64data = msg.text.match(/src="(data:image\/[^;]+;base64[^"]+)"/g);
                        if (!(Array.isArray(bases64data) && bases64data.length > 0)) return [3 /*break*/, 14];
                        currentYear = new Date().getFullYear();
                        _i = 0, bases64data_1 = bases64data;
                        _a.label = 11;
                    case 11:
                        if (!(_i < bases64data_1.length)) return [3 /*break*/, 14];
                        img64 = bases64data_1[_i];
                        imageBuffer = (0, commonHelper_1.decodeBase64Image)(img64.substr(5, img64.length - 1));
                        fileName = new Date().getTime();
                        fileExt = imageBuffer.type.substr(imageBuffer.type.indexOf("/") + 1);
                        thumbPath = path.join(process.env.PATH_FILES, "attachments/".concat(currentYear, "/").concat(fileName, "_mini.").concat(fileExt));
                        webPath = path.join(process.env.PATH_FILES, "attachments/".concat(currentYear, "/").concat(fileName, ".").concat(fileExt));
                        webUrl = "".concat(process.env.URL_FILES, "/attachments/").concat(currentYear, "/").concat(fileName, ".").concat(fileExt);
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(imageBuffer.buffer, thumbPath, webPath, null)];
                    case 12:
                        _a.sent();
                        msg.text = msg.text.replace(img64, "src=\"".concat(webUrl, "\""));
                        _a.label = 13;
                    case 13:
                        _i++;
                        return [3 /*break*/, 11];
                    case 14: return [4 /*yield*/, this.msgRepo.save(msg)];
                    case 15:
                        _a.sent();
                        // On prévient les utilisateurs seulement quand il s'agit d'un nouveau message
                        if (!data.postId) {
                            tname = topic ? topic.name : "T.B.Z. ";
                            logger_1.logger.notice(data.topicTitle
                                ? "Nouvelle discussion lanc\u00E9e par ".concat(user.username, ": ").concat(tname)
                                : "Nouveau message ajout\u00E9 par ".concat(user.username, " dans ").concat(tname), {
                                userId: user.id,
                                module: entities_1.LogModule.forum,
                                data: { msgId: msg.id, topicId: msg.topic ? msg.topic.id : null, forumId: forum.id }
                            });
                        }
                        else {
                            logger_1.logger.info("".concat(user.username, " modifie le message ").concat(msg.id), {
                                userId: user.id,
                                module: entities_1.LogModule.forum,
                                data: { msgId: msg.id, topicId: msg.topic ? msg.topic.id : null, forumId: forum.id }
                            });
                        }
                        if (!msg.topic) return [3 /*break*/, 17];
                        msg.topic.firstMessage = msg.topic.firstMessage ? msg.topic.firstMessage : { id: msg.id };
                        msg.topic.lastMessage = { id: msg.id };
                        return [4 /*yield*/, this.topicRepo.save(msg.topic)];
                    case 16:
                        _a.sent();
                        _a.label = 17;
                    case 17:
                        if (!msg.forum) return [3 /*break*/, 19];
                        msg.forum.lastMessage = { id: msg.id };
                        return [4 /*yield*/, this.forumRepo.save(msg.forum)];
                    case 18:
                        _a.sent();
                        _a.label = 19;
                    case 19: return [2 /*return*/, __assign(__assign({}, msg), { text: this.parseMessageText(msg.text), dateLabel: (0, date_fns_1.format)(new Date(msg.datetime), "dddd D à HH:mm", { locale: locale_1.fr }), poster: {
                                id: msg.poster.id,
                                rootFamily: msg.poster.rootFamily,
                                username: msg.poster.username,
                                avatar: "/files/avatars/".concat(msg.poster.id.toString().padStart(3, "0"), ".png")
                            } })];
                }
            });
        });
    };
    /**
     * Supprime un message du forum
     * @param id l'identifiant du message
     * @param user
     */
    ForumService.prototype.deletePost = function (id, user) {
        return __awaiter(this, void 0, void 0, function () {
            var msg, forumId, topicId, fMsgs, tMsgs, topic;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        msg = null;
                        forumId = null;
                        topicId = null;
                        if (!id) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.msgRepo.findOne({
                                where: { id: id },
                                relations: ["poster", "forum.lastMessage", "forum", "topic", "topic.firstMessage", "topic.lastMessage"]
                            })];
                    case 1:
                        // Si l'id est renseigné, on récupère l'instance en base pour la mettre à jour
                        msg = _a.sent();
                        forumId = msg.forum.id;
                        topicId = msg.topic ? msg.topic.id : null;
                        _a.label = 2;
                    case 2:
                        if (!msg) {
                            throw new routing_controllers_1.BadRequestError("Le message avec l'identifiant n\u00B0".concat(id, " n'existe pas."));
                        }
                        if (!(user.is("admin") || user.id === msg.poster.id)) return [3 /*break*/, 13];
                        // Log visible seulement par les admins
                        logger_1.logger.info("".concat(user.username, " supprime le message ").concat(msg.id), {
                            userId: user.id,
                            module: entities_1.LogModule.forum,
                            data: { msgId: msg.id, topicId: topicId, forumId: forumId }
                        });
                        if (!(msg.forum.lastMessage.id === msg.id)) return [3 /*break*/, 5];
                        return [4 /*yield*/, this.msgRepo
                                .createQueryBuilder("q")
                                .where("q.\"forumId\" = ".concat(forumId))
                                .orderBy("q.datetime", "DESC")
                                .limit(2)
                                .getMany()];
                    case 3:
                        fMsgs = _a.sent();
                        msg.forum.lastMessage = { id: fMsgs.filter(function (m) { return m.id != msg.id; })[0].id };
                        return [4 /*yield*/, this.forumRepo.save(msg.forum)];
                    case 4:
                        _a.sent();
                        _a.label = 5;
                    case 5:
                        if (!topicId) return [3 /*break*/, 11];
                        return [4 /*yield*/, this.msgRepo
                                .createQueryBuilder("q")
                                .where("q.\"topicId\" = ".concat(topicId, " AND q.id <> ").concat(msg.id))
                                .orderBy("q.datetime", "ASC")
                                .getMany()];
                    case 6:
                        tMsgs = _a.sent();
                        if (!(tMsgs.length > 0)) return [3 /*break*/, 8];
                        // On met à jours les infos du sujet
                        msg.topic.firstMessage = { id: tMsgs[0].id };
                        msg.topic.lastMessage = { id: tMsgs[tMsgs.length - 1].id };
                        return [4 /*yield*/, this.topicRepo.save(msg.topic)];
                    case 7:
                        _a.sent();
                        return [3 /*break*/, 11];
                    case 8:
                        topic = msg.topic;
                        msg.topic = null;
                        return [4 /*yield*/, this.msgRepo.save(msg)];
                    case 9:
                        _a.sent();
                        return [4 /*yield*/, this.topicRepo.delete(topic)];
                    case 10:
                        _a.sent();
                        _a.label = 11;
                    case 11: 
                    // On supprime le message
                    return [4 /*yield*/, this.msgRepo.delete(msg)];
                    case 12:
                        // On supprime le message
                        _a.sent();
                        return [2 /*return*/, { forumId: forumId, topicId: topicId }];
                    case 13: throw new routing_controllers_1.BadRequestError("Vous n'avez pas les droits n\u00E9cessaire pour supprimer ce message.");
                }
            });
        });
    };
    /**
     * Retourne la liste des sujets mis en avant
     */
    ForumService.prototype.pinnedTopics = function () {
        return this.topicRepo
            .createQueryBuilder("t")
            .where("t.pinned IS TRUE")
            .getMany();
    };
    /**
     * Met en avant un sujet ou le retire
     * @param topicId l'identifiant du sujet
     */
    ForumService.prototype.switchPin = function (topicId) {
        return __awaiter(this, void 0, void 0, function () {
            var topic, _a, _b;
            var _c;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0: return [4 /*yield*/, this.topicRepo
                            .createQueryBuilder("t")
                            .where("t.id = ".concat(topicId))
                            .getOne()];
                    case 1:
                        topic = _d.sent();
                        if (!topic) return [3 /*break*/, 4];
                        topic.pinned = !topic.pinned;
                        return [4 /*yield*/, this.topicRepo.save(topic)];
                    case 2:
                        _d.sent();
                        _b = (_a = WebsocketService_1.websocketService).broadcast;
                        _c = {
                            message: WebsocketService_1.WSMessageType.pinnedTopicsChanged
                        };
                        return [4 /*yield*/, this.pinnedTopics()];
                    case 3:
                        _b.apply(_a, [(_c.payload = _d.sent(),
                                _c)]);
                        return [2 /*return*/, topic];
                    case 4: throw new routing_controllers_1.BadRequestError("Le sujet n\u00B0".concat(topicId, " n'existe pas"));
                }
            });
        });
    };
    /**
     * Enregistre une pièce jointe sur le serveur
     * @param file la pièce jointe
     * @param userId l'utilisateur qui fait la demande
     */
    ForumService.prototype.saveFile = function (file, userId) {
        return __awaiter(this, void 0, void 0, function () {
            var currentYear, fileName, fileExt, filePath, fileUrl, thumb;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        currentYear = new Date().getFullYear();
                        fileName = "".concat(userId, "_").concat(new Date().getTime());
                        fileExt = file.originalname.substr(file.originalname.lastIndexOf("."));
                        filePath = path.join(process.env.PATH_FILES, "attachments/".concat(currentYear, "/").concat(fileName).concat(fileExt));
                        fileUrl = "".concat(process.env.URL_FILES, "/attachments/").concat(currentYear, "/").concat(fileName).concat(fileExt);
                        if (!(file.mimetype === "image/jpeg")) return [3 /*break*/, 2];
                        thumb = path.join(process.env.PATH_FILES, "attachments/".concat(currentYear, "/").concat(fileName, "_mini").concat(fileExt));
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(file.buffer, thumb, filePath, null)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, {
                                url: fileUrl,
                                href: "".concat(process.env.URL_FILES, "/attachments/").concat(currentYear, "/").concat(fileName, "_mini").concat(fileExt)
                            }];
                    case 2:
                        fs.writeFileSync(filePath, file);
                        return [2 /*return*/, { url: fileUrl, href: null }];
                }
            });
        });
    };
    /**
     * Supprime une pièce jointe du serveur
     * @param fileURI
     * @param user
     */
    ForumService.prototype.deleteFile = function (fileURI, user) {
        // On analyse l'url pour retrouver le fichier sur le serveur
        var filePath = fileURI.replace(process.env.URL_FILES, process.env.PATH_FILES);
        if (fs.existsSync(filePath)) {
            if (user.is("admin") || filePath.indexOf("/".concat(user.id, "_")) > -1) {
                return fs.unlinkSync(filePath);
            }
            else {
                throw new routing_controllers_1.BadRequestError("Vous n'avez pas les droits n\u00E9cessaire pour supprimer ce fichier.");
            }
        }
        throw new routing_controllers_1.BadRequestError("Le fichier ".concat(fileURI, " n'existe pas."));
    };
    /**
     * Sauvegarde un message en cours d'édition pour l'utilisateur courrant
     * @param draft
     * @param user
     */
    ForumService.prototype.saveDraft = function (draft, id) {
        return __awaiter(this, void 0, void 0, function () {
            var user;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userRepo.findOne({ where: { id: id } })];
                    case 1:
                        user = _a.sent();
                        if (user) {
                            user.draft = draft;
                            this.userRepo.save(user);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Récupère le brouillon en cours d'édition de l'utilisateur si il existe
     * @param id l'identifiant de l'utilisateur
     */
    ForumService.prototype.getDraft = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var user;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.userRepo.findOne({ where: { id: id } })];
                    case 1:
                        user = _a.sent();
                        if (user) {
                            return [2 /*return*/, user.draft];
                        }
                        return [2 /*return*/, null];
                }
            });
        });
    };
    /**
     * TO REMOVE AND FIX PROBLEMS DIRECTLY IN DATABASE
     * @param text
     */
    ForumService.prototype.parseMessageText = function (text) {
        text = text.replace(/\{SMILIES_PATH\}/g, "".concat(process.env.URL_FILES, "/smilies"));
        text = text.replace(/\\r\\n/g, "<br/>");
        text = text.replace(/\\n/g, "<br/>");
        return text;
    };
    return ForumService;
}());
exports.forumService = new ForumService();
