"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventService = void 0;
var typeorm_1 = require("typeorm");
var date_fns_1 = require("date-fns");
var path = require("path");
var entities_1 = require("../entities");
var commonHelper_1 = require("../middleware/commonHelper");
var routing_controllers_1 = require("routing-controllers");
var logger_1 = require("../middleware/logger");
var EventService = /** @class */ (function () {
    function EventService() {
        this.repo = null;
    }
    EventService.prototype.initService = function () {
        this.repo = (0, typeorm_1.getRepository)(entities_1.EventG);
    };
    /**
     * Calcule la date du lundi de paque pour une année donnée dans le calendrier Gregorian
     * basé sur l'algorithme Oudin (http://www.tondering.dk/claus/cal/easter.php)
     * @returns {array} [int month, int day]
     */
    EventService.prototype.getEaster = function (year) {
        var f = Math.floor, 
        // Golden Number - 1
        G = year % 19, C = f(year / 100), 
        // Related to Epact
        H = (C - f(C / 4) - f((8 * C + 13) / 25) + 19 * G + 15) % 30, 
        // Number of days from 21 March to the Paschal full moon
        I = H - f(H / 28) * (1 - f(29 / (H + 1)) * f((21 - G) / 11)), 
        // Weekday for the Paschal full moon
        J = (year + f(year / 4) + I + 2 - C + f(C / 4)) % 7, 
        // Number of days from 21 March to the Sunday on or before the Paschal full moon
        L = I - J, month = 3 + f((L + 40) / 44), day = L + 28 - 31 * f(month / 4);
        return [month - 1, day + 1];
    };
    /**
     * Calcul les fêtes et événements légaux au cours d'une année en France, et retourne ceux du mois désiré
     * @param year
     * @param month
     */
    EventService.prototype.getLegalEvents = function (year, month) {
        var easter = this.getEaster(year);
        var easterdate = new Date(Date.UTC(year, easter[0], easter[1]));
        var list = [
            { startDate: new Date(Date.UTC(year, 0, 1)), name: "\uD83C\uDF89 Jour de l'an", type: "special" },
            { startDate: easterdate, name: "\uD83E\uDD5A Lundi de P\u00E2ques", type: "special" },
            { startDate: new Date(Date.UTC(year, 4, 1)), name: "\uD83D\uDCA4 F\u00EAte du Travail", type: "special" },
            { startDate: new Date(Date.UTC(year, 4, 8)), name: "\u270C\uFE0F Victoire de 1945", type: "special" },
            { startDate: (0, date_fns_1.addDays)(easterdate, 39), name: "\u271D\uFE0F L\u2019Ascension", type: "special" },
            { startDate: (0, date_fns_1.addDays)(easterdate, 49), name: "\u271D\uFE0F Lundi de Pentec\u00F4te", type: "special" },
            { startDate: new Date(Date.UTC(year, 6, 14)), name: "\uD83C\uDF96\uFE0F F\u00EAte nationale", type: "special" },
            { startDate: new Date(Date.UTC(year, 7, 15)), name: "\u271D\uFE0F L\u2019Assomption", type: "special" },
            { startDate: new Date(Date.UTC(year, 10, 1)), name: "\u271D\uFE0F La Toussaint", type: "special" },
            { startDate: new Date(Date.UTC(year, 10, 11)), name: "\uD83D\uDD4A\uFE0F L\u2019Armistice", type: "special" },
            { startDate: new Date(Date.UTC(year, 11, 24)), name: "\uD83C\uDF84 Veille de No\u00EBl", type: "special" },
            { startDate: new Date(Date.UTC(year, 11, 25)), name: "\uD83C\uDF85 No\u00EBl", type: "special" }
        ];
        return list.filter(function (e) { return e.startDate.getMonth() === month; }).map(function (e) { return (__assign(__assign({}, e), { editable: false })); });
    };
    /**
     * Récupère la liste des événements sur une période donnée
     * @param startDate début de la période à prendre en compte
     * @param endDate fin de la période à prendre en compte
     * @returns la liste des événements
     */
    EventService.prototype.getEvents = function (startDate, endDate) {
        return __awaiter(this, void 0, void 0, function () {
            var result, year, q, _a, _b, _c, months, m, qr, y, _i, months_1, m;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        result = [];
                        year = startDate.getFullYear();
                        q = "SELECT e.*, u.username \n            FROM public.event_g e\n            INNER JOIN \"user\" u ON e.\"authorId\" = u.id\n            WHERE (e.\"endDate\" IS NULL AND e.\"startDate\" >= '".concat(startDate.toISOString(), "' AND e.\"startDate\" <= '").concat(endDate.toISOString(), "')\n            OR (e.\"endDate\" IS NOT NULL AND e.\"startDate\" <= '").concat(endDate.toISOString(), "' AND e.\"endDate\" >= '").concat(startDate.toISOString(), "')\n            ");
                        _b = (_a = result.push).apply;
                        _c = [result];
                        return [4 /*yield*/, this.repo.query(q)];
                    case 1:
                        _b.apply(_a, _c.concat([(_d.sent()).map(function (e) { return (__assign(__assign({}, e), { editable: true })); })]));
                        result = result.map(function (e) {
                            e.startDate = new Date(e.startDate);
                            return e;
                        });
                        months = [];
                        for (m = startDate.getMonth(); m <= endDate.getMonth(); m++) {
                            months.push(m + 1);
                        }
                        q = "SELECT * \n            FROM person\n            WHERE \n                (\"dateOfBirth\" is NOT NULL AND substring(\"dateOfBirth\" from 6 for 2)::int IN (".concat(months.join(","), "))\n            AND (\"dateOfDeath\" IS NULL OR substring(\"dateOfDeath\" from 1 for 4)::int >= ").concat(year, ")");
                        return [4 /*yield*/, this.repo.query(q)];
                    case 2:
                        qr = _d.sent();
                        if (Array.isArray(qr) && qr.length > 0) {
                            result.push.apply(result, qr.map(function (json) {
                                var p = new entities_1.Person().fromJSON(json);
                                var e = p.sex == entities_1.Sex.female ? "p'tite mère" : p.sex == entities_1.Sex.male ? "p'tit père" : "";
                                return {
                                    startDate: new Date(Date.UTC(year, +p.dateOfBirth.substr(5, 2) - 1, +p.dateOfBirth.substr(8, 2))),
                                    name: "\uD83C\uDF82 ".concat(p.getQuickName()),
                                    details: "".concat(p.getQuickName(), " f\u00EAte ses ").concat(p.getAge(), "!<br/>Bravo ").concat(e, "!!"),
                                    type: "birthday",
                                    editable: false
                                };
                            }));
                        }
                        y = year;
                        for (_i = 0, months_1 = months; _i < months_1.length; _i++) {
                            m = months_1[_i];
                            result.push.apply(result, this.getLegalEvents(y, m));
                            if (m === 11) {
                                y += 1;
                            }
                        }
                        return [2 /*return*/, result.sort(function (a, b) { return a.startDate.getTime() - b.startDate.getTime(); })];
                }
            });
        });
    };
    /**
     * Renvoie les événements du mois demandé
     */
    EventService.prototype.getForMonth = function (year, month) {
        var startDate = new Date(year, month);
        var endDate = (0, date_fns_1.addMonths)(startDate, 1);
        return this.getEvents(startDate, endDate);
    };
    /**
     * Récupère la liste des 20 prochains événements à venir sur les 6 prochains mois
     * (par défaut par rapport à la date du jour)
     * @param from la date à prendre en compte
     */
    EventService.prototype.getNextEvents = function (from) {
        if (from === void 0) { from = null; }
        return __awaiter(this, void 0, void 0, function () {
            var startDate, endDate, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        startDate = from ? from : new Date();
                        endDate = (0, date_fns_1.addMonths)(startDate, 2);
                        return [4 /*yield*/, this.getEvents(startDate, endDate)];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, result.splice(0, 20)];
                }
            });
        });
    };
    /**
     * Ajoute ou met à jour (si l'id est fourni) un événement existant
     * avec les nouvelles données.
     * @param data les infos sur l'événement
     * @param user l'utilisateur qui fait la demande
     */
    EventService.prototype.save = function (data, user) {
        return __awaiter(this, void 0, void 0, function () {
            var evt, bases64data, currentYear, _i, bases64data_1, img64, imageBuffer, fileName, fileExt, thumbPath, webPath, webUrl;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        evt = null;
                        if (!data.id) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.repo.findOne({ where: { id: data.id } })];
                    case 1:
                        // Si l'id est renseigné, on récupère l'instance en base pour la mettre à jour
                        evt = _a.sent();
                        _a.label = 2;
                    case 2:
                        if (!evt) {
                            evt = new entities_1.EventG();
                        }
                        // On met à jour le message
                        evt.name = data.name;
                        evt.details = data.details;
                        evt.type = data.type;
                        evt.startDate = new Date(data.startDate);
                        if (data.endDate && data.endDate !== "null") {
                            evt.endDate = new Date(data.endDate);
                        }
                        else {
                            evt.endDate = null;
                        }
                        evt.author = user;
                        bases64data = evt.details.match(/src="(data:image\/[^;]+;base64[^"]+)"/g);
                        if (!(Array.isArray(bases64data) && bases64data.length > 0)) return [3 /*break*/, 6];
                        currentYear = new Date().getFullYear();
                        _i = 0, bases64data_1 = bases64data;
                        _a.label = 3;
                    case 3:
                        if (!(_i < bases64data_1.length)) return [3 /*break*/, 6];
                        img64 = bases64data_1[_i];
                        imageBuffer = (0, commonHelper_1.decodeBase64Image)(img64.substr(5, img64.length - 1));
                        fileName = new Date().getTime();
                        fileExt = imageBuffer.type.substr(imageBuffer.type.indexOf("/") + 1);
                        thumbPath = path.join(process.env.PATH_FILES, "attachments/".concat(currentYear, "/").concat(fileName, "_mini.").concat(fileExt));
                        webPath = path.join(process.env.PATH_FILES, "attachments/".concat(currentYear, "/").concat(fileName, ".").concat(fileExt));
                        webUrl = "".concat(process.env.URL_FILES, "/attachments/").concat(currentYear, "/").concat(fileName, ".").concat(fileExt);
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(imageBuffer.buffer, thumbPath, webPath, null)];
                    case 4:
                        _a.sent();
                        evt.details = evt.details.replace(img64, "src=\"".concat(webUrl, "\""));
                        _a.label = 5;
                    case 5:
                        _i++;
                        return [3 /*break*/, 3];
                    case 6:
                        logger_1.logger.notice(evt.id === -1
                            ? "Nouvel \u00E9v\u00E9nement ajout\u00E9 au calendrier par ".concat(user.username, " le ").concat(evt.startDate
                                .toISOString()
                                .substr(0, 10))
                            : "\u00C9v\u00E9nement \"".concat(evt.name, "\" du ").concat(evt.startDate.toISOString().substr(0, 10), " a \u00E9t\u00E9 modifi\u00E9 par ").concat(user.username), {
                            userId: user.id,
                            module: entities_1.LogModule.event
                        });
                        return [4 /*yield*/, this.repo.save(evt)];
                    case 7:
                        _a.sent();
                        return [2 /*return*/, evt];
                }
            });
        });
    };
    /**
     * Supprime un événement
     * Une événement ne peut être supprimé que par un admin,
     * ou bien par le poster
     * @param id l'identifiant de l'événement à supprimer
     * @param user l'utilisateur qui fait la demande
     */
    EventService.prototype.delete = function (id, user) {
        return __awaiter(this, void 0, void 0, function () {
            var evt;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        evt = null;
                        if (!id) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.repo.findOne({ where: { id: id } })];
                    case 1:
                        // Si l'id est renseigné, on récupère l'instance en base pour la mettre à jour
                        evt = _a.sent();
                        _a.label = 2;
                    case 2:
                        if (!evt) {
                            throw new routing_controllers_1.BadRequestError("L'\u00E9v\u00E9nement avec l'identifiant n\u00B0".concat(id, " n'existe pas."));
                        }
                        if (user.roles.is("admin") || user.id === evt.author.id) {
                            logger_1.logger.notice("\u00C9v\u00E9nement \"".concat(evt.name, "\" du ").concat(evt.startDate.toISOString().substr(0, 10), " a \u00E9t\u00E9 supprim\u00E9 par ").concat(user.username), {
                                userId: user.id,
                                module: entities_1.LogModule.event
                            });
                            return [2 /*return*/, this.repo.remove(evt)];
                        }
                        throw new routing_controllers_1.BadRequestError("Vous n'avez pas les droits n\u00E9cessaire pour supprimer cet \u00E9v\u00E9nement.");
                }
            });
        });
    };
    return EventService;
}());
exports.eventService = new EventService();
