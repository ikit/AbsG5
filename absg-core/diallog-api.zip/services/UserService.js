"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userService = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var date_fns_1 = require("date-fns");
var commonHelper_1 = require("../middleware/commonHelper");
var logger_1 = require("../middleware/logger");
var middleware_1 = require("../middleware");
var routing_controllers_1 = require("routing-controllers");
var UserService = /** @class */ (function () {
    function UserService() {
        this.usersRepo = null;
        this.personsRepo = null;
    }
    UserService.prototype.initService = function () {
        this.usersRepo = (0, typeorm_1.getRepository)(entities_1.User);
        this.personsRepo = (0, typeorm_1.getRepository)(entities_1.Person);
    };
    /**
     * Renvoie la liste des utilisateurs en fonction des informations de filtrage et de pagination
     */
    UserService.prototype.getUsers = function () {
        return __awaiter(this, void 0, void 0, function () {
            var users;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.usersRepo
                            .createQueryBuilder("u")
                            .leftJoinAndSelect("u.person", "person")
                            .orderBy("u.id")
                            .getMany()];
                    case 1:
                        users = _a.sent();
                        return [2 /*return*/, { users: users }];
                }
            });
        });
    };
    /**
     * Crée un nouvel utilisateur à partir des informations données
     * @param userData les données du nouveau compte utilisateur
     */
    UserService.prototype.createUser = function (userData) {
        return __awaiter(this, void 0, void 0, function () {
            var hasMissingField, usernameClean, usernameExists, person, _a, err_1;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        hasMissingField = !userData || ["id", "username", "password", "roles"].some(function (field) { return !userData.hasOwnProperty(field); });
                        if (hasMissingField) {
                            throw new routing_controllers_1.BadRequestError("Impossible de cr\u00E9er ou d'\u00E9diter le compte utilisateur. Certaines informations obligatoires sont manquantes");
                        }
                        usernameClean = (0, commonHelper_1.cleanString)(userData.username);
                        return [4 /*yield*/, this.usersRepo.findOne({
                                where: { usernameClean: (0, typeorm_1.Equal)(usernameClean) },
                                relations: ["person"]
                            })];
                    case 1:
                        usernameExists = _b.sent();
                        if (usernameExists) {
                            throw new routing_controllers_1.BadRequestError("Le pseudo est d\u00E9j\u00E0 pris");
                        }
                        userData.usernameClean = usernameClean;
                        _b.label = 2;
                    case 2:
                        _b.trys.push([2, 6, , 7]);
                        person = new entities_1.Person().fromJSON(userData.person);
                        return [4 /*yield*/, this.personsRepo.save(person)];
                    case 3:
                        person = _b.sent();
                        userData.person = person;
                        // On chiffre le mot de passe
                        _a = userData;
                        return [4 /*yield*/, (0, middleware_1.hashPassword)(userData.password)];
                    case 4:
                        // On chiffre le mot de passe
                        _a.passwordHash = _b.sent();
                        // On stock le nouvel utilisateur en base
                        userData.id = null;
                        return [4 /*yield*/, this.usersRepo.save(userData)];
                    case 5:
                        _b.sent();
                        logger_1.logger.notice("Nouvel utilisateur cr\u00E9\u00E9: ".concat(userData.username));
                        return [2 /*return*/, userData];
                    case 6:
                        err_1 = _b.sent();
                        logger_1.logger.error("Erreur lors de la cr\u00E9ation du compte utilisateur: ".concat(err_1.message), err_1);
                        throw new routing_controllers_1.BadRequestError("Erreur lors de la cr\u00E9ation du compte utilisateur: ".concat(err_1.message));
                    case 7: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Modifie un utilisateur à partir des informations données
     * @param userData les données du nouveau compte utilisateur
     */
    UserService.prototype.saveUser = function (userData) {
        return __awaiter(this, void 0, void 0, function () {
            var user, currentPwdHash, _a, err_2;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.usersRepo.findOne({ where: { id: (0, typeorm_1.Equal)(userData.id) }, relations: ["person"] })];
                    case 1:
                        user = _b.sent();
                        currentPwdHash = user.passwordHash;
                        // On met à jours les infos de l'utilisateur
                        user.fromJSON(userData);
                        if (!userData.password) return [3 /*break*/, 3];
                        // on met à jour avec le nouveau mot de passe
                        _a = user;
                        return [4 /*yield*/, (0, middleware_1.hashPassword)(userData.password)];
                    case 2:
                        // on met à jour avec le nouveau mot de passe
                        _a.passwordHash = _b.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        // On garde l'ancien mot de passe
                        user.passwordHash = currentPwdHash;
                        _b.label = 4;
                    case 4:
                        _b.trys.push([4, 6, , 7]);
                        // On sauvegarde en base
                        return [4 /*yield*/, this.personsRepo.save(user.person)];
                    case 5:
                        // On sauvegarde en base
                        _b.sent();
                        return [2 /*return*/, this.usersRepo.save(user)];
                    case 6:
                        err_2 = _b.sent();
                        throw new routing_controllers_1.BadRequestError("Erreur lors de l'\u00E9dition du compte utilisateur: ".concat(err_2.message));
                    case 7: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Met à jour le mot de l'utilisateur
     * @param user l'utilisateur qui fait la demande
     * @param pwd le nouveau mot de passe
     */
    UserService.prototype.changePassword = function (user, pwd) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        // On sauvegarde le nouveau mot de passe
                        _a = user;
                        return [4 /*yield*/, (0, middleware_1.hashPassword)(pwd)];
                    case 1:
                        // On sauvegarde le nouveau mot de passe
                        _a.passwordHash = _c.sent();
                        // On régénère la session de l'utilisateur
                        _b = user;
                        return [4 /*yield*/, (0, middleware_1.createToken)(user)];
                    case 2:
                        // On régénère la session de l'utilisateur
                        _b.token = _c.sent();
                        return [4 /*yield*/, this.usersRepo.save(user)];
                    case 3:
                        _c.sent();
                        return [2 /*return*/, user];
                }
            });
        });
    };
    /**
     * Crée un lien pour réinitialiser son mot de passe
     */
    UserService.prototype.resetPassword = function (email) {
        return __awaiter(this, void 0, void 0, function () {
            var users, _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.usersRepo
                            .createQueryBuilder("u")
                            .leftJoinAndSelect("u.person", "p")
                            .where("p.email = '".concat(email, "'"))
                            .getMany()];
                    case 1:
                        users = _b.sent();
                        if (!(users.length > 1)) return [3 /*break*/, 2];
                        throw new Error("Plusieurs comptes possèdent cet email. Veuillez voir avec un administrateur du site pour réinitialiser votre mot de passe");
                    case 2:
                        if (!(users.length === 1)) return [3 /*break*/, 5];
                        // On crée une session de 10 minutes avec acccès restreind pour laisser le temps à l'utilisateur de changer son mdp
                        _a = users[0];
                        return [4 /*yield*/, (0, middleware_1.createToken)(users[0], true)];
                    case 3:
                        // On crée une session de 10 minutes avec acccès restreind pour laisser le temps à l'utilisateur de changer son mdp
                        _a.token = _b.sent();
                        return [4 /*yield*/, this.usersRepo.save(users[0])];
                    case 4:
                        _b.sent();
                        // On envoie un email à l'utilisateur avec le lien
                        (0, commonHelper_1.sendEmail)("Absolument G - demande de réinitialisation d'email", "Bonjour ".concat(users[0].username, ",\n\nUne demande de r\u00E9initialisation de votre mot de passe viens d'\u00EAtre faite sur le site absolumentg.fr.\nLe liens ci-dessous est valide 10 minutes et vous permettra de modifier votre mot de passe.\n\n").concat(process.env.URL_CLIENT, "resetpwd?session=").concat(encodeURI(users[0].token), ".\n\nL'\u00E9quipe syst\u00E8me"), users[0].person.email);
                        return [2 /*return*/, users[0].id];
                    case 5: 
                    // On ignore la demande
                    return [2 /*return*/, null];
                }
            });
        });
    };
    /**
     * Retourne les dernières notifications à afficher pour l'utilisateur
     */
    UserService.prototype.getLastNotifications = function (user, sysLog) {
        if (sysLog === void 0) { sysLog = false; }
        return __awaiter(this, void 0, void 0, function () {
            var where, limit, sql, notifs, notReads;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        where = "WHERE severity = 'notice'";
                        limit = 50;
                        if (sysLog && user.is("admin")) {
                            where = "";
                            limit = 500;
                        }
                        sql = "SELECT l.*, u.username\n            FROM log_system l\n            LEFT JOIN \"user\" u ON u.id = l.\"userId\" \n            ".concat(where, "\n            ORDER BY l.datetime DESC\n            LIMIT ").concat(limit);
                        return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.LogPassag).query(sql)];
                    case 1:
                        notifs = _a.sent();
                        notReads = user.activity.unreadNotifications;
                        notifs.forEach(function (e) { return (e.read = notReads.indexOf(e.id) === -1); });
                        return [2 /*return*/, notifs];
                }
            });
        });
    };
    /**
     * Marque comme lu une notification pour l'utilisateur donné
     * @param notifId l'identifiant de la notification
     * @param user l'utilisateur concerné
     */
    UserService.prototype.markAsRead = function (notifId, user) {
        user.activity.unreadNotifications = user.activity.unreadNotifications.filter(function (id) { return id != notifId; });
        this.usersRepo.save(user);
    };
    /**
     * Marque comme lu toutes les notifications pour l'utilisateur donné
     * @param user l'utilisateur concerné
     */
    UserService.prototype.markAllAsRead = function (user) {
        user.activity.unreadNotifications = [];
        this.usersRepo.save(user);
    };
    /**
     * Retourne les logs de passage des membres sur le site entre 2 date
     * @param from
     * @param to
     */
    UserService.prototype.getPassag = function (from, to) {
        if (to === void 0) { to = new Date(); }
        var sql = "SELECT l.*, u.username\n            FROM log_passag l\n            INNER JOIN \"user\" u ON u.id = l.\"userId\" \n            WHERE l.\"datetime\" BETWEEN '".concat((0, date_fns_1.format)(from, "YYYY-MM-DD HH:mm"), ":00' \n            AND '").concat((0, date_fns_1.format)(to, "YYYY-MM-DD HH:mm"), ":00'\n            ORDER BY l.datetime ASC");
        return (0, typeorm_1.getRepository)(entities_1.LogPassag).query(sql);
    };
    /**
     * Récupère le nombre de visiteurs uniques du site sur la période indiquée
     * @param from
     * @param to
     */
    UserService.prototype.getPassagHistory = function (from, to) {
        if (from === void 0) { from = null; }
        if (to === void 0) { to = null; }
        to = to ? to : new Date();
        from = from && from < to ? from : new Date(to.getFullYear() - 1, to.getMonth(), 1);
        var deltaDays = (0, date_fns_1.differenceInDays)(to, from);
        var sql = "SELECT d.date, count(DISTINCT l.\"userId\")\n            FROM (SELECT to_char(date_trunc('day', ('".concat((0, date_fns_1.format)(to, "YYYY-MM-DD"), "'::date - offs)), 'YYYY-MM-DD') AS date\n                FROM generate_series(0, ").concat(deltaDays, ", 1) AS offs\n                ) d\n            LEFT OUTER JOIN log_passag l ON d.date = to_char(date_trunc('day', l.datetime), 'YYYY-MM-DD')\n            GROUP BY d.date;");
        return (0, typeorm_1.getRepository)(entities_1.LogPassag).query(sql);
    };
    /**
     * Met à jour la position GPS d'un utilisateur
     * @param userId
     * @param gpsLocation
     */
    UserService.prototype.updateGPS = function (userId, gpsLocation) {
        return __awaiter(this, void 0, void 0, function () {
            var user;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.usersRepo
                            .createQueryBuilder("u")
                            .leftJoinAndSelect("u.person", "person")
                            .where("u.id = " + userId)
                            .getOne()];
                    case 1:
                        user = _a.sent();
                        user.person.lastLocation = gpsLocation;
                        return [4 /*yield*/, this.personsRepo.save(user.person)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, user];
                }
            });
        });
    };
    return UserService;
}());
exports.userService = new UserService();
