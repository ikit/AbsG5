"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.websocketService = exports.WebsocketService = exports.WSMessageType = void 0;
var wss_1 = require("../wss");
var WSMessageType;
(function (WSMessageType) {
    WSMessageType["notification"] = "notification";
    WSMessageType["pinnedTopicsChanged"] = "pinnedTopicsChanged";
    WSMessageType["onlineUsers"] = "onlineUsers";
    WSMessageType["agpaSynchSlide"] = "agpaSynchSlide";
})(WSMessageType = exports.WSMessageType || (exports.WSMessageType = {}));
var WebsocketService = /** @class */ (function () {
    function WebsocketService() {
    }
    WebsocketService.prototype.getClients = function () {
        return wss_1.default ? wss_1.default.clients : [];
    };
    WebsocketService.prototype.send = function (client, message) {
        var data = JSON.stringify(message);
        client.send(data);
    };
    WebsocketService.prototype.broadcast = function (message) {
        var _this = this;
        this.getClients().forEach(function (client) {
            _this.send(client, message);
        });
    };
    return WebsocketService;
}());
exports.WebsocketService = WebsocketService;
exports.websocketService = new WebsocketService();
