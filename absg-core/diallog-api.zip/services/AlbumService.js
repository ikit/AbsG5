"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumService = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var path = require("path");
var fs = require("fs");
var logger_1 = require("../middleware/logger");
var commonHelper_1 = require("../middleware/commonHelper");
var PhotoAlbum_1 = require("../entities/PhotoAlbum");
var AlbumService = /** @class */ (function () {
    function AlbumService() {
        this.pRepo = null;
        this.aRepo = null;
    }
    AlbumService.prototype.initService = function () {
        this.pRepo = (0, typeorm_1.getRepository)(entities_1.Photo);
        this.aRepo = (0, typeorm_1.getRepository)(PhotoAlbum_1.PhotoAlbum);
    };
    /**
     * Sauvegarde une image dans un album
     * @param image l'image
     * @param albumId l'identifiant de l'album
     * @param user l'utilisateur qui poste l'image
     */
    AlbumService.prototype.save = function (image, albumId, user) {
        return __awaiter(this, void 0, void 0, function () {
            var album, id, folder, photo, thumb, web, raw;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.aRepo
                            .createQueryBuilder("a")
                            .where("a.id = ".concat(albumId, " AND (a.family IS  NULL OR a.family = '").concat(user.rootFamily, "')"))
                            .getOne()];
                    case 1:
                        album = _a.sent();
                        id = "".concat(user.id.toString().padStart(4, "0"), "_").concat(new Date().getTime());
                        folder = "absg_" + album.id.toString().padStart(4, "0");
                        photo = new entities_1.Photo();
                        photo.id = id;
                        photo.poster = user;
                        photo.folder = folder;
                        thumb = path.join(process.env.PATH_FILES, "photos/".concat(folder, "/THUMB/").concat(id, ".jpg"));
                        web = path.join(process.env.PATH_FILES, "photos/".concat(folder, "/WEB/").concat(id, ".jpg"));
                        raw = path.join(process.env.PATH_FILES, "photos/".concat(folder, "/RAW/").concat(id, ".jpg"));
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(image.buffer, thumb, web, raw)];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, this.pRepo.save(photo)];
                    case 3:
                        _a.sent();
                        // On met à jour l'album
                        album.photos.push(id);
                        return [4 /*yield*/, this.aRepo.save(album)];
                    case 4:
                        _a.sent();
                        logger_1.logger.notice("Nouvelle photo ajout\u00E9e par ".concat(user.username, " \u00E0 l'album ").concat(album.title), {
                            userId: user.id,
                            photoId: id,
                            albumId: folder,
                            module: entities_1.LogModule.photos
                        });
                        return [2 /*return*/, photo];
                }
            });
        });
    };
    /**
     * Supprime une image d'un album
     * @param albumId l'identifiant de l'album
     * @param photoId l'identifiant de la photo
     * @param user l'utilisateur qui poste l'image
     */
    AlbumService.prototype.deletePhoto = function (albumId, photoId, user) {
        return __awaiter(this, void 0, void 0, function () {
            var album, folder, photo, thumb, web, raw, pIdx;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.aRepo
                            .createQueryBuilder("a")
                            .where("a.id = ".concat(albumId, " AND (a.family IS  NULL OR a.family = '").concat(user.rootFamily, "')"))
                            .getOne()];
                    case 1:
                        album = _a.sent();
                        folder = "absg_" + album.id.toString().padStart(4, "0");
                        return [4 /*yield*/, this.pRepo
                                .createQueryBuilder("p")
                                .where("p.id = '".concat(photoId, "' AND p.folder = '").concat(folder, "'"))
                                .getOne()];
                    case 2:
                        photo = _a.sent();
                        if (!(photo && user.is("admin"))) return [3 /*break*/, 4];
                        thumb = path.join(process.env.PATH_FILES, "photos/".concat(folder, "/THUMB/").concat(photoId, ".jpg"));
                        web = path.join(process.env.PATH_FILES, "photos/".concat(folder, "/WEB/").concat(photoId, ".jpg"));
                        raw = path.join(process.env.PATH_FILES, "photos/".concat(folder, "/RAW/").concat(photoId, ".jpg"));
                        // On essaye de supprimer les images (on ignore les erreurs potentiel si fichiers inexistant)
                        try {
                            fs.unlinkSync(thumb);
                        }
                        catch (err) {
                            logger_1.logger.warning("Suppression photo ".concat(photoId, "/thumb impossible: ").concat(JSON.stringify(err)), err);
                        }
                        try {
                            fs.unlinkSync(web);
                        }
                        catch (err) {
                            logger_1.logger.warning("Suppression photo ".concat(photoId, "/web impossible: ").concat(JSON.stringify(err)), err);
                        }
                        try {
                            fs.unlinkSync(raw);
                        }
                        catch (err) {
                            logger_1.logger.warning("Suppression photo ".concat(photoId, "/raw impossible: ").concat(JSON.stringify(err)), err);
                        }
                        return [4 /*yield*/, this.pRepo.delete(photo)];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4:
                        pIdx = album.photos.findIndex(function (pId) { return pId === photoId; });
                        if (!(pIdx > -1)) return [3 /*break*/, 6];
                        album.photos.splice(pIdx, 1);
                        return [4 /*yield*/, this.aRepo.save(album)];
                    case 5:
                        _a.sent();
                        _a.label = 6;
                    case 6:
                        logger_1.logger.notice("Photo supprim\u00E9e par ".concat(user.username, " dans l'album ").concat(album.title), {
                            userId: user.id,
                            photoId: photoId,
                            albumId: folder,
                            module: entities_1.LogModule.photos
                        });
                        return [2 /*return*/, photo];
                }
            });
        });
    };
    return AlbumService;
}());
exports.albumService = new AlbumService();
