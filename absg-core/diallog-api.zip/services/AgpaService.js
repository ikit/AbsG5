"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.agpaService = void 0;
var entities_1 = require("../entities");
var agpaCommonHelpers_1 = require("../middleware/agpaCommonHelpers");
var agpaArchiveHelper_1 = require("../middleware/agpaArchiveHelper");
var agpaAlgorithmsHelper_1 = require("../middleware/agpaAlgorithmsHelper");
var agpaPalmaresHelper_1 = require("../middleware/agpaPalmaresHelper");
var agpaCeremonyHelper_1 = require("../middleware/agpaCeremonyHelper");
var logger_1 = require("../middleware/logger");
var typeorm_1 = require("typeorm");
var commonHelper_1 = require("../middleware/commonHelper");
var path = require("path");
var fs = require("fs");
var WebsocketService_1 = require("./WebsocketService");
var AgpaService = /** @class */ (function () {
    function AgpaService() {
        this.photoRepo = null;
        this.catRepo = null;
    }
    /**
     * Initialisation du service
     */
    AgpaService.prototype.initService = function () {
        // Rien à faire
        this.photoRepo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
        this.catRepo = (0, typeorm_1.getRepository)(entities_1.AgpaCategory);
    };
    /**
     * Retourne les informations sur les anciennes éditions
     * @param user l'utilisateur qui demande les informations
     */
    AgpaService.prototype.getArchiveSummary = function (user) {
        return (0, agpaArchiveHelper_1.archiveSummary)(user);
    };
    /**
     * Retourne les informations sur une ancienne édition
     * @param year l'année de l'édition
     * @param user l'utilisateur qui demande les informations
     */
    AgpaService.prototype.getArchiveEdition = function (year, user) {
        if (year >= 2006 && year <= (0, agpaCommonHelpers_1.getMaxArchiveEdition)()) {
            return (0, agpaArchiveHelper_1.archiveEdition)(year, user);
        }
        return null;
    };
    /**
     * Retourne les informations sur une catégorie d'une édition
     * @param year l'année de l'édition
     * @param catId l'id de la catégorie
     * @param user l'utilisateur qui demande les informations
     */
    AgpaService.prototype.getArchiveCategory = function (year, catId, user) {
        if (year >= 2006 && year <= (0, agpaCommonHelpers_1.getMaxArchiveEdition)()) {
            return (0, agpaArchiveHelper_1.archiveCategory)(year, catId, user);
        }
        return null;
    };
    /**
     * Récupère toutes les statistiques "palmarès" de l'ensemble des éditions
     */
    AgpaService.prototype.getPalmaresData = function () {
        return (0, agpaPalmaresHelper_1.palmaresData)(null, null);
    };
    /**
     * Récupère les données pour une cérémonie donnée
     * @param year l'année de la cérémonie
     */
    AgpaService.prototype.getCeremonyData = function (year) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(year >= 2006 && year <= (0, agpaCommonHelpers_1.getCurrentEdition)())) return [3 /*break*/, 3];
                        if (!(year === (0, agpaCommonHelpers_1.getCurrentEdition)())) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.closeEdition()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/, (0, agpaCeremonyHelper_1.ceremonyData)(year)];
                    case 3:
                        logger_1.logger.warning("C\u00E9r\u00E9monie ".concat(year, " non disponible"));
                        return [2 /*return*/, null];
                }
            });
        });
    };
    /**
     * Route appelé par le maitre de cérémonie pour notifier les autres utilisateurs
     * de changer de page automatiquement
     * @param year année de la cérémonie
     * @param slide index de la page à afficher
     * @param hash la signature du slide
     * @param user l'utilisateur qui fait cet appel
     */
    AgpaService.prototype.notifyMasterSlide = function (year, slide, hash, user) {
        WebsocketService_1.websocketService.broadcast({
            message: WebsocketService_1.WSMessageType.agpaSynchSlide,
            payload: { year: year, slide: slide, hash: hash, user: user }
        });
        return null;
    };
    /**
     * Récupère les données concernant la phase 1 des AGPAS
     * @param user l'utilisateur qui en fait la demande
     */
    AgpaService.prototype.getP1Data = function (user) {
        return __awaiter(this, void 0, void 0, function () {
            var year, sql, photos;
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        year = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        sql = "SELECT p.*\n            FROM agpa_photo p\n            INNER JOIN agpa_category c ON p.\"categoryId\" = c.id\n            WHERE p.year=".concat(year, " AND p.\"userId\"=").concat(user.id, "\n            ORDER BY c.\"order\" ASC, p.id ASC");
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 1:
                        photos = (_b.sent()).map(function (e) { return (__assign(__assign({}, e), { thumb: "".concat(process.env.URL_FILES, "agpa/").concat(e.year, "/mini/vignette_").concat(e.filename), url: "".concat(process.env.URL_FILES, "agpa/").concat(e.year, "/mini/").concat(e.filename) })); });
                        // Get stats
                        sql = "SELECT \"categoryId\", count (*) as \"totalPhotos\", count(distinct(\"userId\")) as \"totalUsers\"\n            FROM agpa_photo\n            WHERE year=".concat(year, " AND \"categoryId\" > 0\n            GROUP BY \"categoryId\"");
                        _a = {
                            photos: photos
                        };
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 2: return [2 /*return*/, (_a.stats = _b.sent(),
                            _a)];
                }
            });
        });
    };
    /**
     * Récupère les données concernant la phase 2 des AGPAS
     * @param user l'utilisateur qui en fait la demande
     */
    AgpaService.prototype.getP2Data = function (user) {
        return __awaiter(this, void 0, void 0, function () {
            var year, sql, photos, result, _i, photos_1, p, _a, _b, c;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        year = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        sql = "SELECT p.*\n            FROM agpa_photo p\n            INNER JOIN agpa_category c ON p.\"categoryId\" = c.id\n            WHERE p.year=".concat(year, "\n            ORDER BY c.\"order\" ASC, p.id ASC");
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 1:
                        photos = (_c.sent()).map(function (e) { return (__assign(__assign({}, e), { thumb: "".concat(process.env.URL_FILES, "agpa/").concat(e.year, "/mini/vignette_").concat(e.filename), url: "".concat(process.env.URL_FILES, "agpa/").concat(e.year, "/mini/").concat(e.filename) })); });
                        result = {
                            categories: [],
                            warningPhotos: []
                        };
                        for (_i = 0, photos_1 = photos; _i < photos_1.length; _i++) {
                            p = photos_1[_i];
                            // On ajoute la photo à la liste de la catégorie concernée
                            if (!result.categories[p.categoryId]) {
                                result.categories[p.categoryId] = {
                                    categoryId: p.categoryId,
                                    photos: [],
                                    userPhotoIds: [],
                                    totalPhotos: 0,
                                    totalUsers: 0
                                };
                            }
                            result.categories[p.categoryId].photos.push(p);
                            if (p.userId === user.id) {
                                result.categories[p.categoryId].userPhotoIds.push(p.id);
                            }
                            // Si la photo à un warning, on l'ajoute à la liste
                            if (p.error) {
                                result.warningPhotos.push(p);
                            }
                        }
                        // Pour chaque catégories
                        for (_a = 0, _b = result.categories; _a < _b.length; _a++) {
                            c = _b[_a];
                            if (c) {
                                (0, commonHelper_1.shuffleArray)(c.photos);
                                c.totalPhotos = c.photos.length;
                                c.totalUsers = new Set(c.photos.map(function (p) { return p.userId; })).size;
                            }
                        }
                        return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * Récupère les données concernant la phase 3 des AGPAS
     * @param user l'utilisateur qui en fait la demande
     */
    AgpaService.prototype.getP3Data = function (user) {
        return __awaiter(this, void 0, void 0, function () {
            var year, sql, votes, photos, result, _i, photos_2, p, _a, _b, c, idx, _c, _d, p;
            return __generator(this, function (_e) {
                switch (_e.label) {
                    case 0:
                        year = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        sql = "SELECT v.*\n            FROM agpa_vote v\n            WHERE v.year=".concat(year, " AND v.\"userId\"=").concat(user.id);
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 1:
                        votes = _e.sent();
                        // On récupère les photos
                        sql = "SELECT p.id, p.error, p.filename, p.number, p.title, p.\"userId\", p.\"categoryId\", p.year\n            FROM agpa_photo p\n            INNER JOIN agpa_category c ON p.\"categoryId\" = c.id\n            WHERE p.year=".concat(year, "\n            ORDER BY c.\"order\" ASC, p.id ASC");
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 2:
                        photos = (_e.sent()).map(function (e) { return (__assign(__assign({}, e), { thumb: "".concat(process.env.URL_FILES, "agpa/").concat(e.year, "/mini/vignette_").concat(e.filename), url: "".concat(process.env.URL_FILES, "agpa/").concat(e.year, "/mini/").concat(e.filename) })); });
                        result = {
                            categories: [],
                            votes: {
                                votes: votes,
                                totalTitleVotes: votes.filter(function (v) { return v.categoryId === -3; }).length
                            }
                        };
                        for (_i = 0, photos_2 = photos; _i < photos_2.length; _i++) {
                            p = photos_2[_i];
                            // On ajoute la photo à la liste de la catégorie concernée
                            if (!result.categories[p.categoryId]) {
                                result.categories[p.categoryId] = {
                                    categoryId: p.categoryId,
                                    photos: [],
                                    totalPhotos: 0,
                                    totalUsers: 0,
                                    maxVotes: 0
                                };
                            }
                            result.categories[p.categoryId].photos.push(p);
                        }
                        _a = 0, _b = result.categories;
                        _e.label = 3;
                    case 3:
                        if (!(_a < _b.length)) return [3 /*break*/, 8];
                        c = _b[_a];
                        if (!c) return [3 /*break*/, 7];
                        if (!c.photos[0].number) return [3 /*break*/, 4];
                        // Si les photos ont un numéro, on les tris en fonction de ce numéro*
                        c.photos.sort(function (a, b) { return a.number - b.number; });
                        return [3 /*break*/, 6];
                    case 4:
                        // Sinon, on mélange les photos et on leur attribu un numéro
                        (0, commonHelper_1.shuffleArray)(c.photos);
                        for (idx = 0; idx < c.photos.length; idx++) {
                            c.photos[idx].number = idx + 1;
                        }
                        return [4 /*yield*/, this.photoRepo.save(c.photos)];
                    case 5:
                        _e.sent();
                        _e.label = 6;
                    case 6:
                        // Pour chaque photos: on supprime l'info user, et on indique s'il s'agit d'une photo de l'utilsiateur
                        for (_c = 0, _d = c.photos; _c < _d.length; _c++) {
                            p = _d[_c];
                            p.enableVotes = p.userId != user.id && !p.error;
                            delete p.userId;
                        }
                        c.totalPhotos = c.photos.length;
                        c.totalUsers = new Set(c.photos.map(function (p) { return p.userId; })).size;
                        c.maxVotes = Math.round(c.photos.length / 2);
                        _e.label = 7;
                    case 7:
                        _a++;
                        return [3 /*break*/, 3];
                    case 8: return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * Effectue la série d'action nécessaire (étape par étape) pour calculer les points
     * de chaques de photos et leur attribuer les récompenses en départageant les exaequos
     * Cete méthode permet aussi bien le calcul des résultats d'une édition que sa supervision
     * en controlant que tout se passe bien.
     * @param user l'utilisateur qui en fait la demande
     */
    AgpaService.prototype.monitoring = function (year, user) {
        return __awaiter(this, void 0, void 0, function () {
            var context, _i, _a, pId, p;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        context = null;
                        return [4 /*yield*/, (0, agpaCommonHelpers_1.getMetaData)(year, true)];
                    case 1:
                        // On récupère le contexte
                        context = _b.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4CheckVotes)(context)];
                    case 2:
                        // Récupérer les votes et les vérifier
                        context = _b.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4ComputeNotes)(context)];
                    case 3:
                        // Comptabiliser les votes correctes et calculer les notes pour chaque photo
                        context = _b.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4AgpaAttribution)(context)];
                    case 4:
                        // Attributions AGPA et création d'un "premier" palmares
                        context = _b.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4DiamondAttribution)(context)];
                    case 5:
                        // Attribution des AGPA de diamant
                        context = _b.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4HonorAttribution)(context)];
                    case 6:
                        // Attribution des AGPA d'honneur
                        context = _b.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.monitoringStats)(context)];
                    case 7:
                        // Stats
                        context = _b.sent();
                        // On ajoute aux photos les vignettes et url
                        for (_i = 0, _a = Object.keys(context.photos); _i < _a.length; _i++) {
                            pId = _a[_i];
                            p = context.photos[pId];
                            context.photos[pId].thumb = "".concat(process.env.URL_FILES, "agpa/").concat(p.year, "/mini/vignette_").concat(p.filename);
                            context.photos[pId].url = "".concat(process.env.URL_FILES, "agpa/").concat(p.year, "/mini/").concat(p.filename);
                        }
                        return [2 /*return*/, context];
                }
            });
        });
    };
    /**
     * Clos l'édition en cours si nécessaire
     */
    AgpaService.prototype.closeEdition = function () {
        return __awaiter(this, void 0, void 0, function () {
            var currentYear, context, awards, _loop_1, pid, _loop_2, uid, sql, _i, awards_1, a, _loop_3, pid;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        currentYear = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        return [4 /*yield*/, (0, agpaCommonHelpers_1.getMetaData)(currentYear, true)];
                    case 1:
                        context = _a.sent();
                        return [4 /*yield*/, this.catRepo.query("SELECT * FROM agpa_award WHERE year = ".concat(context.year))];
                    case 2:
                        awards = _a.sent();
                        if (!(context.phase === 4 && awards.length === 0)) return [3 /*break*/, 9];
                        return [4 /*yield*/, (0, agpaCommonHelpers_1.getMetaData)(context.year, true)];
                    case 3:
                        // On calcul les awards de l'édition en cours
                        context = _a.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4CheckVotes)(context)];
                    case 4:
                        context = _a.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4ComputeNotes)(context)];
                    case 5:
                        context = _a.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4AgpaAttribution)(context)];
                    case 6:
                        context = _a.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4DiamondAttribution)(context)];
                    case 7:
                        context = _a.sent();
                        return [4 /*yield*/, (0, agpaAlgorithmsHelper_1.p4HonorAttribution)(context)];
                    case 8:
                        context = _a.sent();
                        _loop_1 = function (pid) {
                            var p = context.photos[pid];
                            var a = Array.isArray(p.awards) ? p.awards : [];
                            a = a.map(function (e) { return (__assign(__assign({}, e), { photoId: +pid, userId: p.userId })); });
                            awards = awards.concat(a);
                        };
                        // On récpère des agpas des catégories normales et meilleurs titre
                        for (pid in context.photos) {
                            _loop_1(pid);
                        }
                        _loop_2 = function (uid) {
                            var u = context.users[uid];
                            var a = Array.isArray(u.awards) ? u.awards : [];
                            a = a.filter(function (e) { return e.categoryId === -1 || e.award === entities_1.AgpaAwardType.honor; });
                            a = a.map(function (e) { return (__assign(__assign({}, e), { userId: u.id })); });
                            awards = awards.concat(a);
                        };
                        // On récupère des meilleurs photographes
                        for (uid in context.users) {
                            _loop_2(uid);
                        }
                        awards.sort(function (a, b) {
                            return a.categoryId - b.categoryId;
                        });
                        sql = [];
                        for (_i = 0, awards_1 = awards; _i < awards_1.length; _i++) {
                            a = awards_1[_i];
                            if (a.categoryId === -1) {
                                sql.push("(".concat(currentYear, ", ").concat(a.categoryId, ", ").concat(a.userId, ", NULL, '").concat(a.award, "')"));
                            }
                            else {
                                sql.push("(".concat(currentYear, ", ").concat(a.categoryId, ", ").concat(a.userId, ", ").concat(a.photoId, ", '").concat(a.award, "')"));
                            }
                        }
                        this.catRepo.query("INSERT INTO agpa_award (year, \"categoryId\", \"userId\", \"photoId\", award) VALUES ".concat(sql.join(","), ";"));
                        // On met à jours les résultats pour les photos de l'édition
                        sql = [];
                        _loop_3 = function (pid) {
                            var p = context.photos[pid];
                            sql.push("UPDATE agpa_photo SET \n                    ranking=".concat(context.photosOrder.findIndex(function (e) { return e === p.id; }) + 0, ", \n                    votes=").concat(p.votes, ", \n                    \"votesTitle\"=").concat(p.votesTitle, ", \n                    score=").concat(p.score, ",\n                    gscore=").concat(p.gscore, "\n                    WHERE id=").concat(p.id));
                        };
                        for (pid in context.photos) {
                            _loop_3(pid);
                        }
                        this.catRepo.query(sql.join(";"));
                        _a.label = 9;
                    case 9: return [2 /*return*/, awards];
                }
            });
        });
    };
    /**
     * Met à jour les inforlation d'une photo
     * @param photoData l'entrée du répertoire
     * @param image l'image pour illustrer la personne dans le répertoire
     * @param user l'utilisateur qui fait l'action
     */
    AgpaService.prototype.savePhoto = function (photoData, image, user) {
        return __awaiter(this, void 0, void 0, function () {
            var photoId, photo, _a, thumb, web, raw;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        photoId = Number.parseInt(photoData.id);
                        photo = new entities_1.AgpaPhoto();
                        if (!photoId) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.photoRepo.findOne({ where: { id: (0, typeorm_1.Equal)(photoId) }, relations: ["user", "category"] })];
                    case 1:
                        photo = _b.sent();
                        return [3 /*break*/, 3];
                    case 2:
                        // Ces inbfos ne peuvent pas être modifié une fois que la photo a été "créée"
                        photo.year = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        photo.filename = "".concat(new Date().getTime(), ".jpg");
                        _b.label = 3;
                    case 3:
                        photoData.id = photoId ? photoId : null; // pour éviter les problèmes lors du save en DB
                        photo.user = !photo.user ? user : photo.user;
                        photo.title = photoData.title ? photoData.title : photo.title;
                        photo.categoryId = photoData.catId ? photoData.catId : photo.category.id;
                        photo.error = photoData.error ? JSON.parse(photoData.error) : photo.error;
                        _a = photo;
                        return [4 /*yield*/, this.catRepo.findOne(photo.categoryId)];
                    case 4:
                        _a.category = _b.sent();
                        return [4 /*yield*/, this.photoRepo.save(photo)];
                    case 5:
                        photo = _b.sent();
                        if (!image) return [3 /*break*/, 7];
                        thumb = path.join(process.env.PATH_FILES, "agpa/".concat(photo.year, "/mini/vignette_").concat(photo.filename));
                        web = path.join(process.env.PATH_FILES, "agpa/".concat(photo.year, "/mini/").concat(photo.filename));
                        raw = path.join(process.env.PATH_FILES, "agpa/".concat(photo.year, "/").concat(photo.filename));
                        return [4 /*yield*/, (0, commonHelper_1.saveImage)(image.buffer, thumb, web, raw)];
                    case 6:
                        _b.sent();
                        _b.label = 7;
                    case 7:
                        // Ce log n'est visible que par les admins
                        logger_1.logger.info(photoId
                            ? "".concat(user.username, " a modifi\u00E9 la photo (id: ").concat(photo.id, ") des AGPA")
                            : "Nouvelle photo (id: ".concat(photo.id, ") a \u00E9t\u00E9 enregistr\u00E9e pour les AGPA par ").concat(user.username), {
                            userId: user.id,
                            module: entities_1.LogModule.agpa
                        });
                        return [2 /*return*/, {
                                title: photo.title,
                                id: photo.id,
                                categoryId: photo.categoryId,
                                authorId: photo.user.id,
                                thumb: "".concat(process.env.URL_FILES, "agpa/").concat(photo.year, "/mini/vignette_").concat(photo.filename),
                                url: "".concat(process.env.URL_FILES, "agpa/").concat(photo.year, "/mini/").concat(photo.filename),
                                error: photo.error
                            }];
                }
            });
        });
    };
    /**
     * Supprime la photo du concours
     * @param id l'id de la photo à supprimer
     * @param user l'utilisateur qui en fait la demande
     */
    AgpaService.prototype.deletePhoto = function (id, user) {
        return __awaiter(this, void 0, void 0, function () {
            var photo, thumb, web, raw;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.photoRepo.findOne({
                            where: { id: (0, typeorm_1.Equal)(id) },
                            relations: ["user"]
                        })];
                    case 1:
                        photo = _a.sent();
                        if (!(photo && (user.is("admin") || photo.user.id === user.id))) return [3 /*break*/, 3];
                        thumb = path.join(process.env.PATH_FILES, "agpa/".concat(photo.year, "/mini/vignette_").concat(photo.filename));
                        web = path.join(process.env.PATH_FILES, "agpa/".concat(photo.year, "/mini/").concat(photo.filename));
                        raw = path.join(process.env.PATH_FILES, "agpa/".concat(photo.year, "/").concat(photo.filename));
                        // On essaye de supprimer les images (on ignore les erreurs potentiel si fichiers inexistant)
                        try {
                            fs.unlinkSync(thumb);
                        }
                        catch (err) {
                            logger_1.logger.warning("Suppression photo ".concat(id, "/thumb impossible: ").concat(JSON.stringify(err)), err);
                        }
                        try {
                            fs.unlinkSync(web);
                        }
                        catch (err) {
                            logger_1.logger.warning("Suppression photo ".concat(id, "/web impossible: ").concat(JSON.stringify(err)), err);
                        }
                        try {
                            fs.unlinkSync(raw);
                        }
                        catch (err) {
                            logger_1.logger.warning("Suppression photo ".concat(id, "/raw impossible: ").concat(JSON.stringify(err)), err);
                        }
                        return [4 /*yield*/, this.photoRepo.remove(photo)];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3: return [2 /*return*/, photo];
                }
            });
        });
    };
    /**
     * Met à jour le vote d'un utilisateur pour une photo
     * @param photoId l'identifiant de la photo à modifier (doit être de l'édition en cours)
     * @param vote le vote de l'utilisateur (1, 2 ou -3)
     * @param user l'utilisateur qui fait la demande
     */
    AgpaService.prototype.vote = function (photoId, vote, user) {
        return __awaiter(this, void 0, void 0, function () {
            var year, photo, sql, votes, v, v, result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        year = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        return [4 /*yield*/, this.photoRepo.findOne({ where: { id: (0, typeorm_1.Equal)(photoId) }, relations: ["user", "category"] })];
                    case 1:
                        photo = _a.sent();
                        if (!photo) {
                            throw Error("La photo n\u00B0".concat(photoId, " n'existe pas"));
                        }
                        if (photo.year != year) {
                            throw Error("Vous ne pouvez voter que pour les photos de l'\u00E9dition ".concat(year));
                        }
                        if (photo.userId === user.id) {
                            throw Error("Vous ne pouvez pas voter pour vos propres photos");
                        }
                        sql = "SELECT v.*\n            FROM agpa_vote v\n            WHERE v.year=".concat(year, " AND v.\"userId\"=").concat(user.id);
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 2:
                        votes = _a.sent();
                        // On met à jour le vote pour le meilleur titre
                        if (vote === -3) {
                            v = votes.find(function (v) { return v.photoId === photoId && v.categoryId === -3 && v.userId === user.id; });
                            if (v) {
                                // Si vote meilleur titre existe déjà, alors on le supprime
                                sql = "DELETE FROM agpa_vote WHERE id=".concat(v.id, ";");
                            }
                            else {
                                // Si pas de vote déjà en base, on le crée
                                sql = "INSERT INTO agpa_vote (year, score, \"categoryId\", \"userId\", \"photoId\") VALUES (".concat(year, ", 0, -3, ").concat(user.id, ", ").concat(photoId, ");");
                            }
                        }
                        // On met à jour le vote pour la photo
                        else {
                            v = votes.find(function (v) { return v.photoId === photoId && v.categoryId !== -3 && v.userId === user.id; });
                            if (v) {
                                // Si vote existe déjà, alors
                                if (v.score === vote) {
                                    // On le supprime le vote si même valeur => annulation d'un vote existant
                                    sql = "DELETE FROM agpa_vote WHERE id=".concat(v.id, ";");
                                }
                                else {
                                    // sinon on met à jours sa valeur
                                    sql = "UPDATE agpa_vote SET score=".concat(v.score === 1 ? 2 : 1, " WHERE id=").concat(v.id, ";");
                                }
                            }
                            else {
                                // Si pas de vote déjà en base, on le crée
                                sql = "INSERT INTO agpa_vote (year, score, \"categoryId\", \"userId\", \"photoId\") VALUES (".concat(year, ", ").concat(vote, ", ").concat(photo.category.id, ", ").concat(user.id, ", ").concat(photoId, ");");
                            }
                        }
                        // On sauvegarde
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 3:
                        // On sauvegarde
                        _a.sent();
                        // On récupère l'ensemble des votes de l'utilisateur
                        sql = "SELECT v.*\n            FROM agpa_vote v\n            WHERE v.year=".concat(year, " AND v.\"userId\"=").concat(user.id);
                        return [4 /*yield*/, this.catRepo.query(sql)];
                    case 4:
                        result = _a.sent();
                        return [2 /*return*/, {
                                votes: result,
                                totalTitleVotes: result.filter(function (v) { return v.categoryId === -3; }).length
                            }];
                }
            });
        });
    };
    return AgpaService;
}());
exports.agpaService = new AgpaService();
