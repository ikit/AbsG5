"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.citationService = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var util_1 = require("util");
var logger_1 = require("../middleware/logger");
var routing_controllers_1 = require("routing-controllers");
var CitationService = /** @class */ (function () {
    function CitationService() {
        this.citationsRepo = null;
        this.personsRepo = null;
    }
    CitationService.prototype.initService = function () {
        this.citationsRepo = (0, typeorm_1.getRepository)(entities_1.Citation);
        this.personsRepo = (0, typeorm_1.getRepository)(entities_1.Person);
    };
    /**
     * Renvoie une citation au hasard
     */
    CitationService.prototype.random = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.citationsRepo
                        .createQueryBuilder("c")
                        .leftJoinAndSelect("c.author", "a")
                        .leftJoinAndSelect("c.poster", "p")
                        .orderBy("RANDOM()")
                        .getOne()];
            });
        });
    };
    /**
     * Renvoie les citations en fonction des informations de filtrage et de pagination
     */
    CitationService.prototype.getCitations = function (authorId) {
        if (authorId === void 0) { authorId = null; }
        return __awaiter(this, void 0, void 0, function () {
            var citations;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        // controle sur les paramètres
                        authorId = (0, util_1.isNumber)(authorId) && authorId > 0 ? authorId : null;
                        return [4 /*yield*/, this.citationsRepo
                                .createQueryBuilder("c")
                                .leftJoinAndSelect("c.author", "a")
                                .where(authorId ? "a.id = ".concat(authorId) : 1)
                                .orderBy("c.id", "DESC")
                                .getMany()];
                    case 1:
                        citations = _a.sent();
                        return [2 /*return*/, citations.map(function (e) {
                                var c = new entities_1.Citation().fromJSON(e);
                                var photos = c.author ? c.author.getPhotos(c.year) : [null, null];
                                return {
                                    id: c.id,
                                    citation: c.citation,
                                    year: c.year,
                                    author: {
                                        id: c.author.id,
                                        fullname: c.author.getFullname(),
                                        thumb: photos[0],
                                        large: photos[1]
                                    }
                                };
                            })];
                }
            });
        });
    };
    /**
     * Renvoie toutes les citation en fonction de l'autheur
     */
    CitationService.prototype.fromAuthor = function (authorId) {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.citationsRepo
                            .query("SELECT c.*, u.username AS \"posterName\", p.firstname AS \"authorFirstname\", p.surname AS \"authorSurname\" \n            FROM citation c \n            LEFT JOIN \"user\" u ON c.\"posterId\"=u.id\n            LEFT JOIN person p ON c.\"authorId\"=p.id\n            WHERE c.\"authorId\"=".concat(authorId, "\n            ORDER BY c.id DESC "))];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * Ajoute ou met à jour une citation existante (si l'id est fourni)
     * avec les nouvelles données.
     * @param data les informations de la citations à ajouter ou mettre à jour
     */
    CitationService.prototype.save = function (user, citation) {
        return __awaiter(this, void 0, void 0, function () {
            var author, minYear, newCitation;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!citation) {
                            throw new routing_controllers_1.BadRequestError("Merci de renseigner la citation");
                        }
                        // On vérifie que l'auteur est renseigné
                        if (!(0, util_1.isNumber)(citation.author) || citation.author < 1) {
                            throw new routing_controllers_1.BadRequestError("Merci de renseigner l'auteur");
                        }
                        return [4 /*yield*/, this.personsRepo.findOne(citation.author)];
                    case 1:
                        author = _a.sent();
                        if (!author) {
                            throw new routing_controllers_1.BadRequestError("L'auteur de la citation doit être de la famille (enregistré dans l'annuaire)");
                        }
                        // On vérifie que l'auteur est renseignée
                        if (!(0, util_1.isString)(citation.citation)) {
                            throw new routing_controllers_1.BadRequestError("Merci de renseigner correctement la citation");
                        }
                        minYear = author.dateOfBirth ? +author.dateOfBirth.substr(0, 4) : 1700;
                        citation.year = Number.parseInt(citation.year);
                        if (!citation.year || citation.year < minYear || citation.year > new Date().getFullYear()) {
                            throw new routing_controllers_1.BadRequestError("L'année est optionnel mais doit forcement être une année valide");
                        }
                        // On enregistre la citation
                        citation.author = author;
                        citation.poster = user;
                        newCitation = citation.id || null;
                        return [4 /*yield*/, this.citationsRepo.save(citation)];
                    case 2:
                        _a.sent();
                        logger_1.logger.notice(newCitation ? "Citation corrig\u00E9e par ".concat(user.username) : "Nouvelle citation ajout\u00E9e par ".concat(user.username), { userId: user.id, module: entities_1.LogModule.citations });
                        // On indique que tout s'est bien passé en retournant la citation
                        return [2 /*return*/, citation];
                }
            });
        });
    };
    /**
     * Supprime une citation
     * Une citation ne peut être supprimé que par un admin,
     * ou bien par le poster si il s'agit de la dernière citation ajouté
     */
    CitationService.prototype.remove = function (user, id) {
        return __awaiter(this, void 0, void 0, function () {
            var citation;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.citationsRepo.findOne(id)];
                    case 1:
                        citation = _a.sent();
                        if (!citation) {
                            throw new routing_controllers_1.BadRequestError("La citation n\u00B0".concat(id, " n'existe pas."));
                        }
                        logger_1.logger.notice("Citation n\u00B0".concat(id, " supprim\u00E9e par ").concat(user.username), {
                            userId: user.id,
                            module: entities_1.LogModule.citations
                        });
                        return [2 /*return*/, this.citationsRepo.remove(citation)];
                }
            });
        });
    };
    return CitationService;
}());
exports.citationService = new CitationService();
