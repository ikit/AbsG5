"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Person = exports.Sex = void 0;
var typeorm_1 = require("typeorm");
var date_fns_1 = require("date-fns");
var Sex;
(function (Sex) {
    Sex[Sex["female"] = 0] = "female";
    Sex[Sex["male"] = 1] = "male";
    Sex[Sex["undefined"] = 2] = "undefined";
})(Sex = exports.Sex || (exports.Sex = {}));
var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.fromJSON = function (json) {
        Object.assign(this, json);
        // Post-traitement pour corriger le bug de conversion txt/json des valeurs null
        for (var _i = 0, _a = Object.entries(this); _i < _a.length; _i++) {
            var _b = _a[_i], key = _b[0], value = _b[1];
            if (value === "null" || value === "undefined") {
                this[key] = null;
            }
        }
        return this;
    };
    Person.prototype.getQuickName = function () {
        if (this.surname) {
            return this.surname.trim();
        }
        return this.firstname ? this.firstname : "Personne ID ".concat(this.id);
    };
    Person.prototype.getFullname = function () {
        if (this.surname) {
            return this.surname;
        }
        var fullname = "".concat(this.firstname, " ").concat(this.lastname).trim();
        return fullname ? fullname : "Personne ID ".concat(this.id);
    };
    Person.prototype.getAge = function (year) {
        if (year === void 0) { year = null; }
        var age = "";
        var birth = null;
        if (this.dateOfBirth) {
            birth = new Date(this.dateOfBirth);
            var lastDay = year ? new Date(year, 11, 31) : new Date();
            if (this.dateOfDeath && new Date(this.dateOfDeath).getTime() < lastDay.getTime()) {
                lastDay = new Date(this.dateOfDeath);
            }
            var y = lastDay.getFullYear() - birth.getFullYear();
            if (y > 1) {
                age = "".concat(y, " ans");
            }
            else {
                var m = (0, date_fns_1.differenceInMonths)(lastDay, birth);
                age = "".concat(m, " mois");
            }
        }
        return age;
    };
    // Trouve parmi la liste des photos du trombinoscope le concernant, la photo la plus proche
    // de l'année demandé (respecte la chronologie, donc la photo ne peut pas être plus récente)
    // Si aucune trombi trouvé, prend la photo de l'annuaire
    Person.prototype.getPhotos = function (year) {
        if (year === void 0) { year = null; }
        var filename = null;
        var folder = null;
        if (!year) {
            year = new Date().getFullYear();
        }
        if (Array.isArray(this.trombi)) {
            folder = "trombi/";
            var filenameYear = 0;
            for (var _i = 0, _a = this.trombi; _i < _a.length; _i++) {
                var t = _a[_i];
                var ty = Number.parseInt(t.substring(0, 4));
                if (ty > year) {
                    break;
                }
                if (ty >= filenameYear) {
                    filenameYear = ty;
                    filename = "".concat(this.id, "_").concat(t, ".jpg");
                }
            }
        }
        if (!filename) {
            filename = this.photo;
            folder = "persons/";
        }
        return [
            "".concat(process.env.URL_FILES).concat(folder, "mini/").concat(filename ? filename : "no-photo.png"),
            "".concat(process.env.URL_FILES).concat(folder).concat(filename ? filename : "no-photo.png")
        ];
    };
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)({ comment: "id" }),
        __metadata("design:type", Number)
    ], Person.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Prénom" }),
        __metadata("design:type", String)
    ], Person.prototype, "firstname", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Seconds prénoms" }),
        __metadata("design:type", String)
    ], Person.prototype, "firstname2", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Nom de famille" }),
        __metadata("design:type", String)
    ], Person.prototype, "lastname", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Surnom" }),
        __metadata("design:type", String)
    ], Person.prototype, "surname", void 0);
    __decorate([
        (0, typeorm_1.Column)("enum", { enum: ["female", "male", "undefined"], comment: "Sexe", default: "undefined" }),
        __metadata("design:type", Number)
    ], Person.prototype, "sex", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Date de naissance au format YYYY.MM.DD" }),
        __metadata("design:type", String)
    ], Person.prototype, "dateOfBirth", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Date du décé au format YYYY.MM.DD" }),
        __metadata("design:type", String)
    ], Person.prototype, "dateOfDeath", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Dernière adresse connue de la personne" }),
        __metadata("design:type", String)
    ], Person.prototype, "address", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Le dernier emplois exercé par cette personne" }),
        __metadata("design:type", String)
    ], Person.prototype, "job", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Numéro de téléphone personnel" }),
        __metadata("design:type", String)
    ], Person.prototype, "phone", void 0);
    __decorate([
        (0, typeorm_1.Column)({ nullable: true, comment: "Email" }),
        __metadata("design:type", String)
    ], Person.prototype, "email", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Photo de la personne", nullable: true }),
        __metadata("design:type", String)
    ], Person.prototype, "photo", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { nullable: true, comment: "Dernière coordonnée GPS connu pour la personne (VoyaG)" }),
        __metadata("design:type", Object)
    ], Person.prototype, "lastLocation", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { nullable: true, comment: "Liste des photos du trombinoscope concernant la personne" }),
        __metadata("design:type", Object)
    ], Person.prototype, "trombi", void 0);
    Person = __decorate([
        (0, typeorm_1.Entity)()
    ], Person);
    return Person;
}());
exports.Person = Person;
