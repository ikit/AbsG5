"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventG = void 0;
var typeorm_1 = require("typeorm");
var Person_1 = require("./Person");
var Place_1 = require("./Place");
var User_1 = require("./User");
var EventG = /** @class */ (function () {
    function EventG() {
        this.editable = true;
    }
    EventG.prototype.fromJSON = function (json) {
        Object.assign(this, json);
        return this;
    };
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)({ comment: "id" }),
        __metadata("design:type", Number)
    ], EventG.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Date de début de l'événement", nullable: false }),
        __metadata("design:type", Date)
    ], EventG.prototype, "startDate", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Date de fin de l'événement", nullable: true }),
        __metadata("design:type", Date)
    ], EventG.prototype, "endDate", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Titre de l'événement" }),
        __metadata("design:type", String)
    ], EventG.prototype, "name", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Description de l'événement", type: "text", nullable: true }),
        __metadata("design:type", String)
    ], EventG.prototype, "details", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Coordonnée GPS de l'événement", nullable: true }),
        __metadata("design:type", String)
    ], EventG.prototype, "location", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return User_1.User; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", User_1.User)
    ], EventG.prototype, "author", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Le type d'événement: gueudelot, guibert, guyomard, all, birthday, special", nullable: true }),
        __metadata("design:type", String)
    ], EventG.prototype, "type", void 0);
    __decorate([
        (0, typeorm_1.OneToMany)(function () { return Person_1.Person; }, function (person) { return person.id; }),
        __metadata("design:type", Array)
    ], EventG.prototype, "persons", void 0);
    __decorate([
        (0, typeorm_1.OneToMany)(function () { return Place_1.Place; }, function (place) { return place.id; }),
        __metadata("design:type", Array)
    ], EventG.prototype, "places", void 0);
    EventG = __decorate([
        (0, typeorm_1.Entity)()
    ], EventG);
    return EventG;
}());
exports.EventG = EventG;
