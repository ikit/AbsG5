"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgpaAward = exports.AgpaAwardType = void 0;
var typeorm_1 = require("typeorm");
var AgpaCategory_1 = require("./AgpaCategory");
var AgpaPhoto_1 = require("./AgpaPhoto");
var User_1 = require("./User");
var AgpaAwardType;
(function (AgpaAwardType) {
    AgpaAwardType["honor"] = "honor";
    AgpaAwardType["nominated"] = "nominated";
    AgpaAwardType["bronze"] = "bronze";
    AgpaAwardType["sylver"] = "sylver";
    AgpaAwardType["gold"] = "gold";
    AgpaAwardType["diamond"] = "diamond";
})(AgpaAwardType = exports.AgpaAwardType || (exports.AgpaAwardType = {}));
var AgpaAward = /** @class */ (function () {
    function AgpaAward() {
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)(),
        __metadata("design:type", Number)
    ], AgpaAward.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Année d'attribution de l'agpa", width: 4 }),
        __metadata("design:type", Number)
    ], AgpaAward.prototype, "year", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return AgpaCategory_1.AgpaCategory; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", AgpaCategory_1.AgpaCategory)
    ], AgpaAward.prototype, "category", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return User_1.User; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", User_1.User)
    ], AgpaAward.prototype, "user", void 0);
    __decorate([
        (0, typeorm_1.Column)("enum", {
            enum: ["honor", "nominated", "bronze", "sylver", "gold", "diamond"],
            comment: "'L'agpa d\u00E9cern\u00E9"
        }),
        __metadata("design:type", String)
    ], AgpaAward.prototype, "award", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return AgpaPhoto_1.AgpaPhoto; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", AgpaPhoto_1.AgpaPhoto)
    ], AgpaAward.prototype, "photo", void 0);
    AgpaAward = __decorate([
        (0, typeorm_1.Entity)(),
        (0, typeorm_1.Index)(["year", "category", "user", "award"], { unique: true })
    ], AgpaAward);
    return AgpaAward;
}());
exports.AgpaAward = AgpaAward;
