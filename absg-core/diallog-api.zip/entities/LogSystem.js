"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogSystem = exports.LogModule = exports.LogSeverity = void 0;
var typeorm_1 = require("typeorm");
var LogSeverity;
(function (LogSeverity) {
    LogSeverity["emerg"] = "emerg";
    LogSeverity["alert"] = "alert";
    LogSeverity["crit"] = "crit";
    LogSeverity["error"] = "error";
    LogSeverity["warning"] = "warning";
    LogSeverity["notice"] = "notice";
    LogSeverity["info"] = "info";
    LogSeverity["debug"] = "debug"; // debug mode only
})(LogSeverity = exports.LogSeverity || (exports.LogSeverity = {}));
var LogModule;
(function (LogModule) {
    LogModule["absg"] = "absg";
    LogModule["citations"] = "citations";
    LogModule["photos"] = "photos";
    LogModule["agenda"] = "agenda";
    LogModule["event"] = "event";
    LogModule["agpa"] = "agpa";
    LogModule["forum"] = "forum";
    LogModule["gtheque"] = "gtheque";
})(LogModule = exports.LogModule || (exports.LogModule = {}));
var LogSystem = /** @class */ (function () {
    function LogSystem() {
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)({ comment: "id" }),
        __metadata("design:type", Number)
    ], LogSystem.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Qui est à l'origine du log", nullable: true }),
        __metadata("design:type", Number)
    ], LogSystem.prototype, "userId", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Date d'émission du log" }),
        __metadata("design:type", Date)
    ], LogSystem.prototype, "datetime", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Sévérité du log respectant la RFC Syslog", default: "info" }),
        __metadata("design:type", String)
    ], LogSystem.prototype, "severity", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Identifiant du module à l'origine du log", default: "absg" }),
        __metadata("design:type", String)
    ], LogSystem.prototype, "module", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Message du log" }),
        __metadata("design:type", String)
    ], LogSystem.prototype, "message", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { comment: "Méta-donnée attachée au log", nullable: true }),
        __metadata("design:type", Object)
    ], LogSystem.prototype, "data", void 0);
    LogSystem = __decorate([
        (0, typeorm_1.Entity)()
    ], LogSystem);
    return LogSystem;
}());
exports.LogSystem = LogSystem;
