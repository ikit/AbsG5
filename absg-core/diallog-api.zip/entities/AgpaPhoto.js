"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgpaPhoto = void 0;
var typeorm_1 = require("typeorm");
var AgpaCategory_1 = require("./AgpaCategory");
var User_1 = require("./User");
// liste des véhicules attendus pour la mission
var AgpaPhoto = /** @class */ (function () {
    function AgpaPhoto() {
        // Transient properties
        this.awards = null; // catId => award
    }
    AgpaPhoto.prototype.fromJSON = function (json) {
        this.id = json.id ? json.id : null;
        this.year = json.year ? json.year : null;
        this.filename = json.filename ? json.filename : null;
        this.title = json.title ? json.title : null;
        this.ranking = json.ranking ? json.ranking : null;
        this.number = json.number ? json.number : null;
        this.votes = json.votes ? json.votes : null;
        this.votesTitle = json.votesTitle ? json.votesTitle : null;
        this.score = json.score ? json.score : null;
        this.gscore = json.gscore ? json.gscore : null;
        this.error = json.error ? json.error : null;
        if (json.user) {
            var user = new User_1.User();
            user.fromJSON(json.user);
            this.user = user;
        }
        else if (json.username) {
            var user = new User_1.User();
            user.id = json.userId;
            user.username = json.username;
            this.user = user;
        }
        if (json.category) {
            var category = new AgpaCategory_1.AgpaCategory();
            category.fromJSON(json.category);
            this.category = category;
            this.categoryId = category.id;
        }
        else if (json.categoryId) {
            this.categoryId = json.categoryId;
        }
        this.awards = new Map();
        if (json.award && json.awardCategory) {
            this.awards.set(json.awardCategory, json.award);
        }
    };
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)(),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return User_1.User; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", User_1.User)
    ], AgpaPhoto.prototype, "user", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return AgpaCategory_1.AgpaCategory; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", AgpaCategory_1.AgpaCategory)
    ], AgpaPhoto.prototype, "category", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Année de la photo" }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "year", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Nom du fichier", length: 20 }),
        __metadata("design:type", String)
    ], AgpaPhoto.prototype, "filename", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Titre de la photo" }),
        __metadata("design:type", String)
    ], AgpaPhoto.prototype, "title", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Classement de la photo", nullable: true }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "ranking", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Numéro de la photo", nullable: true }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "number", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Nombre de votes reçu par la photo", nullable: true }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "votes", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Nombre de votes reçu par le titre la photo", nullable: true }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "votesTitle", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Score obtenu par la photo", nullable: true }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "score", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Score homogonéisé obtenu par la photo", nullable: true }),
        __metadata("design:type", Number)
    ], AgpaPhoto.prototype, "gscore", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { comment: "Erreur disqualifiant la photo", nullable: true }),
        __metadata("design:type", Object)
    ], AgpaPhoto.prototype, "error", void 0);
    AgpaPhoto = __decorate([
        (0, typeorm_1.Entity)()
    ], AgpaPhoto);
    return AgpaPhoto;
}());
exports.AgpaPhoto = AgpaPhoto;
