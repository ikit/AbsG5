"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Photo = void 0;
var typeorm_1 = require("typeorm");
var User_1 = require("./User");
var Photo = /** @class */ (function () {
    function Photo() {
    }
    __decorate([
        (0, typeorm_1.PrimaryColumn)({ comment: "Le nom de l'image" }),
        __metadata("design:type", String)
    ], Photo.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.PrimaryColumn)({ comment: "Le dossier de l'image" }),
        __metadata("design:type", String)
    ], Photo.prototype, "folder", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Commentaire de l'image", nullable: true }),
        __metadata("design:type", String)
    ], Photo.prototype, "comment", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Date de la prise de vue au format YYYY-MM-DD HH-MM-SS", nullable: true }),
        __metadata("design:type", String)
    ], Photo.prototype, "date", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { comment: "Les personnes principales sur la photo", nullable: true }),
        __metadata("design:type", Object)
    ], Photo.prototype, "persons", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "L'endroit où a été prise la photo", nullable: true }),
        __metadata("design:type", String)
    ], Photo.prototype, "place", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { comment: "La position GPS de la prise de vue", nullable: true }),
        __metadata("design:type", Object)
    ], Photo.prototype, "gps", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Indique si la photo a été marqué comme étant en double", default: false }),
        __metadata("design:type", Boolean)
    ], Photo.prototype, "doublon", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            comment: "Indique si la photo concerne une famille et est donc 'reserve' aux membres de celle-ci",
            nullable: true
        }),
        __metadata("design:type", String)
    ], Photo.prototype, "family", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return User_1.User; }),
        (0, typeorm_1.JoinColumn)(),
        __metadata("design:type", User_1.User)
    ], Photo.prototype, "poster", void 0);
    Photo = __decorate([
        (0, typeorm_1.Entity)()
    ], Photo);
    return Photo;
}());
exports.Photo = Photo;
