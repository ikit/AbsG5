"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForumMessage = void 0;
var typeorm_1 = require("typeorm");
var ForumTopic_1 = require("./ForumTopic");
var Forum_1 = require("./Forum");
var User_1 = require("./User");
var ForumMessage = /** @class */ (function () {
    function ForumMessage(data) {
        if (data === void 0) { data = null; }
        if (data) {
            Object.assign(this, data);
        }
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)({ comment: "id" }),
        __metadata("design:type", Number)
    ], ForumMessage.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return Forum_1.Forum; }),
        __metadata("design:type", Forum_1.Forum)
    ], ForumMessage.prototype, "forum", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return ForumTopic_1.ForumTopic; }),
        __metadata("design:type", ForumTopic_1.ForumTopic)
    ], ForumMessage.prototype, "topic", void 0);
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return User_1.User; }),
        __metadata("design:type", User_1.User)
    ], ForumMessage.prototype, "poster", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Date du message" }),
        __metadata("design:type", Date)
    ], ForumMessage.prototype, "datetime", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Contenu du message", type: "text" }),
        __metadata("design:type", String)
    ], ForumMessage.prototype, "text", void 0);
    ForumMessage = __decorate([
        (0, typeorm_1.Entity)(),
        __metadata("design:paramtypes", [Object])
    ], ForumMessage);
    return ForumMessage;
}());
exports.ForumMessage = ForumMessage;
