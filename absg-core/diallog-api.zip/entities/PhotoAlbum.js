"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhotoAlbum = void 0;
var typeorm_1 = require("typeorm");
var PhotoAlbum = /** @class */ (function () {
    function PhotoAlbum() {
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)({ comment: "L'identifiant unique de l'album" }),
        __metadata("design:type", Number)
    ], PhotoAlbum.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Le titre de l'album" }),
        __metadata("design:type", String)
    ], PhotoAlbum.prototype, "title", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Commentaire de l'album", nullable: true }),
        __metadata("design:type", String)
    ], PhotoAlbum.prototype, "comment", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Date de la prise de vue au format YYYY-MM-DD HH-MM-SS", nullable: true }),
        __metadata("design:type", String)
    ], PhotoAlbum.prototype, "date", void 0);
    __decorate([
        (0, typeorm_1.Column)("json", { comment: "La liste des photos de l'album", nullable: true }),
        __metadata("design:type", Object)
    ], PhotoAlbum.prototype, "photos", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Le nom de la photo à utiliser comme couverture", nullable: true }),
        __metadata("design:type", String)
    ], PhotoAlbum.prototype, "coverPhoto", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "L'ordre d'affichage des albums les uns par rapport aux autres", default: 1 }),
        __metadata("design:type", Number)
    ], PhotoAlbum.prototype, "order", void 0);
    __decorate([
        (0, typeorm_1.Column)({
            comment: "Indique si l'album concerne une famille et est donc 'reserve' aux membres de celle-ci",
            nullable: true
        }),
        __metadata("design:type", String)
    ], PhotoAlbum.prototype, "family", void 0);
    PhotoAlbum = __decorate([
        (0, typeorm_1.Entity)()
    ], PhotoAlbum);
    return PhotoAlbum;
}());
exports.PhotoAlbum = PhotoAlbum;
