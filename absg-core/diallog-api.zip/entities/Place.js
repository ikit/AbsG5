"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Place = void 0;
var typeorm_1 = require("typeorm");
var Place = /** @class */ (function () {
    function Place() {
    }
    Place.prototype.fromJSON = function (data) {
        Object.assign(this, data);
        // Post-traitement pour corriger le bug de conversion txt/json des valeurs null
        for (var _i = 0, _a = Object.entries(this); _i < _a.length; _i++) {
            var _b = _a[_i], key = _b[0], value = _b[1];
            if (value === "null" || value === "undefined") {
                this[key] = null;
            }
        }
        return this;
    };
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)(),
        __metadata("design:type", Number)
    ], Place.prototype, "id", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Nom d usage du lieux" }),
        __metadata("design:type", String)
    ], Place.prototype, "name", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Adresse complète du lieux", nullable: true }),
        __metadata("design:type", String)
    ], Place.prototype, "address", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "URL vers la visite virtuelle", nullable: true }),
        __metadata("design:type", String)
    ], Place.prototype, "virtualVisitUrl", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Téléphone fixe", nullable: true }),
        __metadata("design:type", String)
    ], Place.prototype, "phone", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Coordonnée GPS", nullable: true }),
        __metadata("design:type", String)
    ], Place.prototype, "gps", void 0);
    __decorate([
        (0, typeorm_1.Column)({ comment: "Photo illustrant le lieux", nullable: true }),
        __metadata("design:type", String)
    ], Place.prototype, "photo", void 0);
    Place = __decorate([
        (0, typeorm_1.Entity)()
    ], Place);
    return Place;
}());
exports.Place = Place;
