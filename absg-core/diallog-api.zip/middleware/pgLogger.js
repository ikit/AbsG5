"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PgLogger = void 0;
var Transport = require("winston-transport");
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var WebsocketService_1 = require("../services/WebsocketService");
var PgLogger = /** @class */ (function (_super) {
    __extends(PgLogger, _super);
    function PgLogger(opts) {
        return _super.call(this, opts) || this;
    }
    PgLogger.prototype.log = function (info, callback) {
        var _this = this;
        setImmediate(function () {
            _this.emit("logged", info);
        });
        if (info.level != "debug" && info.metadata.module) {
            // On enregistre l'entrée en base de donnée
            var logRepo = (0, typeorm_1.getRepository)(entities_1.LogSystem);
            var log = new entities_1.LogSystem();
            log.message = info.message;
            log.datetime = info.timestamp;
            log.severity = info.level;
            if (Object.keys(info.metadata).length !== 0) {
                log.module = info.metadata.module;
                log.userId = info.metadata.userId ? info.metadata.userId : null;
                log.data = info.metadata.data;
            }
            logRepo.save(log);
            if (info.level === entities_1.LogSeverity.notice) {
                WebsocketService_1.websocketService.broadcast({
                    message: WebsocketService_1.WSMessageType.notification,
                    payload: log
                });
            }
        }
        callback();
    };
    return PgLogger;
}(Transport));
exports.PgLogger = PgLogger;
