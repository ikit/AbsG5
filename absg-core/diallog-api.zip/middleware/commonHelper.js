"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchFolder = exports.readableFileSize = exports.shuffleArray = exports.sendEmail = exports.saveImage = exports.decodeBase64Image = exports.cleanString = exports.sleep = void 0;
var Jimp = require("jimp");
var fs = require("fs");
var path = require("path");
var nodemailer = require("nodemailer");
var logger_1 = require("./logger");
/**
 * Async sleep method
 */
function sleep(ms) {
    return new Promise(function (resolve) { return setTimeout(resolve, ms); });
}
exports.sleep = sleep;
/**
 * Supprime tout les caractères spéciaux d'une chaîne de caractère
 * (ne fonctionne qu'avec l'alphabet "latin")
 * @param str la chaine de caractère à "nettoyer"
 */
function cleanString(str) {
    return str
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") // supprime les accents et caractères spéciaux
        .toLowerCase() // met tout en minuscule
        .trim(); // supprime les espaces superflux en début et fin de chaine
}
exports.cleanString = cleanString;
/**
 * Décode une chaine de caractère contenant les informations d'une image encodé en base64
 * @param dataString
 */
function decodeBase64Image(dataString) {
    var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (matches.length !== 3) {
        throw new Error("Invalid input string");
    }
    return {
        type: matches[1],
        buffer: new Buffer(matches[2], "base64")
    };
}
exports.decodeBase64Image = decodeBase64Image;
/**
 * Enregistre une image sur le serveur
 * @param file les données de l'image récupérées depuis une requête POST
 * @param thumbPath Si renseigné: va y enregistrer la vignette 200x200px
 * @param webPath Si renseigné: va y enregistrer l'image optimisé pour affichage plein écran (1080p) 2000x2000px
 * @param originalPath Si renseigné: va y enregistrer l'image original sans modification
 */
function saveImage(file, thumbPath, webPath, originalPath) {
    return __awaiter(this, void 0, void 0, function () {
        var img;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, Jimp.read(file)];
                case 1:
                    img = _a.sent();
                    // create WEB version
                    if (webPath) {
                        img.scaleToFit(2000, 2000); // 4K
                        img.quality(85);
                        img.write(webPath);
                    }
                    // create THUMB
                    if (thumbPath) {
                        img.scaleToFit(200, 200);
                        img.quality(85);
                        img.write(thumbPath);
                    }
                    // On déplace dans le répertoire ORIGINAL
                    if (originalPath) {
                        fs.writeFileSync(originalPath, file);
                    }
                    return [2 /*return*/];
            }
        });
    });
}
exports.saveImage = saveImage;
/**
 * Envoie un email
 * @param subject l'objet du mail
 * @param text le corps du mail
 * @param to la liste des destinatire (email séparés par des )
 * @param from l'adresse utilisé pour envoyer le mail
 */
function sendEmail(subject, text, to, from) {
    if (from === void 0) { from = "system@absolumentg.fr"; }
    var transport = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT,
        secure: true,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });
    var email = {
        from: from,
        to: to,
        subject: subject,
        text: text
    };
    transport.sendMail(email, function (err, info) {
        if (err) {
            logger_1.logger.error("Erreur lors de l'envoie d'email", err);
        }
        else {
            logger_1.logger.info("Email envoyé", info);
        }
    });
}
exports.sendEmail = sendEmail;
/**
 * Mélange un tableau de valeur
 * @param arr le tableau à mélanger
 */
function shuffleArray(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * i);
        var temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    return arr;
}
exports.shuffleArray = shuffleArray;
/**
 * Retourne la taille en octet dans un format lisible pour un humain
 * @param fileSizeInBytes taille exprimée en octets
 * @returns taille exprimé de façon lible (par exemple "187.4 Mo")
 */
function readableFileSize(fileSizeInBytes) {
    var i = -1;
    var byteUnits = [" Ko", " Mo", " Go", " To", " Po", " Eo", " Zo", " Yo"];
    do {
        fileSizeInBytes = fileSizeInBytes / 1024;
        i++;
    } while (fileSizeInBytes > 1024);
    return Math.max(fileSizeInBytes, 0.1).toFixed(1) + byteUnits[i];
}
exports.readableFileSize = readableFileSize;
/**
 * Dresse l'arborescence du contenu à l'endroit indiqué
 * @param localPath le dossier local où lister le contenu
 */
function fetchFolder(localPath) {
    var res = [];
    var files = fs.readdirSync(localPath);
    for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
        var f = files_1[_i];
        var filepath = path.resolve(localPath, f);
        var infos = fs.statSync(filepath);
        if (infos.isDirectory()) {
            res.push({
                name: f,
                type: "folder",
                content: fetchFolder(filepath)
            });
        }
        else {
            res.push({
                name: path.basename(f, path.extname(filepath)),
                type: path.extname(filepath),
                size: readableFileSize(fs.statSync(filepath).size)
            });
        }
    }
    return res;
}
exports.fetchFolder = fetchFolder;
