"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.archiveCategory = exports.archiveEdition = exports.archiveSummary = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var agpaCommonHelpers_1 = require("./agpaCommonHelpers");
/**
 * Retourne les informations sur les anciennes éditions
 * @param user l'utilisateur qui demande les informations
 */
function archiveSummary(user) {
    return __awaiter(this, void 0, void 0, function () {
        var maxYear, repo, archivesSummary, photos, sql, result, _i, result_1, row, p, authors, _a, result_2, row, palmares, _b, result_3, row, _c, result_4, row;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    maxYear = (0, agpaCommonHelpers_1.getMaxArchiveEdition)();
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    archivesSummary = [];
                    photos = new Map();
                    sql = "SELECT p.*, a.award, a.\"categoryId\" as \"awardCategory\", a.\"userId\" from agpa_photo p\n        INNER JOIN agpa_award a ON p.id = a.\"photoId\"\n        WHERE a.\"categoryId\" = -2 AND p.year <= ".concat(maxYear, "\n        ORDER BY p.year DESC, p.gscore DESC");
                    return [4 /*yield*/, repo.query(sql)];
                case 1:
                    result = _d.sent();
                    for (_i = 0, result_1 = result; _i < result_1.length; _i++) {
                        row = result_1[_i];
                        p = new entities_1.AgpaPhoto();
                        p.fromJSON(row);
                        if (photos.has(p.year)) {
                            photos.get(p.year).push(p);
                        }
                        else {
                            photos.set(p.year, [p]);
                        }
                    }
                    authors = new Map();
                    sql = "SELECT a.year, a.\"userId\" as id, u.username as firstname, a.award \n        FROM agpa_award a \n        INNER JOIN \"user\" u ON u.id = a.\"userId\" \n        WHERE \"categoryId\"=-1 AND year <= ".concat(maxYear, "\n        ORDER BY \"year\" DESC, a.\"award\" DESC ");
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    result = _d.sent();
                    for (_a = 0, result_2 = result; _a < result_2.length; _a++) {
                        row = result_2[_a];
                        if (authors.has(row.year)) {
                            authors.get(row.year).push(row);
                        }
                        else {
                            authors.set(row.year, [row]);
                        }
                    }
                    palmares = new Map();
                    sql = "SELECT a.year, a.award, count(*) as total\n        FROM agpa_award a\n        WHERE a.\"userId\" = ".concat(user.id, " AND year <= ").concat(maxYear, "\n        GROUP BY year, award\n        ORDER BY a.year DESC, a.award ASC");
                    return [4 /*yield*/, repo.query(sql)];
                case 3:
                    result = _d.sent();
                    for (_b = 0, result_3 = result; _b < result_3.length; _b++) {
                        row = result_3[_b];
                        if (!palmares.has(row.year)) {
                            palmares.set(row.year, { diamond: 0, gold: 0, sylver: 0, bronze: 0, nominated: 0, honor: 0 });
                        }
                        palmares.get(row.year)[row.award] = row.total;
                    }
                    // On récupère le total de photos par années
                    sql = "SELECT year, count(*) AS photos FROM agpa_photo WHERE year <= ".concat(maxYear, " GROUP BY year ORDER BY year DESC");
                    return [4 /*yield*/, repo.query(sql)];
                case 4:
                    result = _d.sent();
                    for (_c = 0, result_4 = result; _c < result_4.length; _c++) {
                        row = result_4[_c];
                        archivesSummary.push({
                            year: row.year,
                            totalPhotos: +row.photos,
                            photos: photos.has(row.year) ? photos.get(row.year) : [],
                            authors: authors.has(row.year) ? authors.get(row.year) : [],
                            palmares: palmares.has(row.year) ? palmares.get(row.year) : null
                        });
                    }
                    return [2 /*return*/, archivesSummary];
            }
        });
    });
}
exports.archiveSummary = archiveSummary;
/**
 * Retourne les informations sur une ancienne édition
 * @param year l'année de l'édition
 * @param user l'utilisateur qui demande les informations
 */
function archiveEdition(year, user) {
    return __awaiter(this, void 0, void 0, function () {
        var repo, edition, sql, result, _i, result_5, row, p, authors, _a, result_6, row, _b, result_7, row;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    return [4 /*yield*/, (0, agpaCommonHelpers_1.getMetaData)(year)];
                case 1:
                    edition = _c.sent();
                    sql = "SELECT p.*, a.award, a.\"categoryId\" as \"awardCategory\", u.username \n        FROM agpa_photo p\n        INNER JOIN \"user\" u ON u.id = p.\"userId\" \n        LEFT JOIN agpa_award a ON p.id = a.\"photoId\"\n        WHERE p.year=".concat(year, " AND p.\"categoryId\" > 0 AND a.award != 'honor' AND (a.award IS NOT NULL OR p.\"userId\" = ").concat(user.id, ")\n        ORDER BY p.gscore DESC");
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    result = _c.sent();
                    for (_i = 0, result_5 = result; _i < result_5.length; _i++) {
                        row = result_5[_i];
                        p = new entities_1.AgpaPhoto();
                        p.fromJSON(row);
                        // On initialise la catégorie si besoin
                        if (!edition.categories[p.categoryId].hasOwnProperty("photos")) {
                            edition.categories[p.categoryId].photos = [];
                            edition.categories[p.categoryId].userPhotos = [];
                        }
                        if (p.categoryId == row.awardCategory && row) {
                            edition.categories[p.categoryId].photos.push(p);
                        }
                        if (p.user.id == user.id) {
                            edition.categories[p.categoryId].userPhotos.push(p);
                        }
                    }
                    authors = [];
                    sql = "SELECT a.\"userId\" as id, u.username as firstname, a.award \n        FROM agpa_award a \n        INNER JOIN \"user\" u ON u.id = a.\"userId\" \n        WHERE \"categoryId\"=-1 AND year=".concat(year, "\n        ORDER BY \"year\" DESC, a.\"award\" DESC ");
                    return [4 /*yield*/, repo.query(sql)];
                case 3:
                    result = _c.sent();
                    for (_a = 0, result_6 = result; _a < result_6.length; _a++) {
                        row = result_6[_a];
                        authors.push(row);
                    }
                    edition.authors = authors;
                    // On récupère les statistiques sur la participation
                    sql = "SELECT \"categoryId\", count (*) as \"totalPhotos\", count(distinct(\"userId\")) as \"totalUsers\"\n        FROM agpa_photo\n        WHERE year=".concat(year, " AND \"categoryId\" > 0\n        GROUP BY \"categoryId\"");
                    return [4 /*yield*/, repo.query(sql)];
                case 4:
                    result = _c.sent();
                    for (_b = 0, result_7 = result; _b < result_7.length; _b++) {
                        row = result_7[_b];
                        edition.categories[row.categoryId].totalPhotos = row.totalPhotos;
                        edition.categories[row.categoryId].totalUsers = row.totalUsers;
                    }
                    return [2 /*return*/, edition];
            }
        });
    });
}
exports.archiveEdition = archiveEdition;
/**
 * Retourne les informations sur une catégorie d'une édition
 * @param year l'année de l'édition
 * @param catId l'id de la catégorie
 * @param user l'utilisateur qui demande les informations
 */
function archiveCategory(year, catId, user) {
    return __awaiter(this, void 0, void 0, function () {
        var repo, category, users, photos, sql, result, _i, result_8, row, p;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // Si l'utilisateur n'est pas admin, il n'a pas le droit de récupérer les archives de l'édition en cours
                    if (user.isNot("admin")) {
                        year = (0, agpaCommonHelpers_1.checkValidYear)(year);
                    }
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    return [4 /*yield*/, (0, agpaCommonHelpers_1.getMetaData)(year)];
                case 1:
                    category = _a.sent();
                    category.totalPhotos = 0;
                    category.totalUsers = 0;
                    category.photos = [];
                    users = [];
                    photos = new Map();
                    sql = "SELECT p.*, a.award, a.\"categoryId\" as \"awardCategory\", u.username \n        FROM agpa_photo p\n        LEFT JOIN agpa_award a ON p.id = a.\"photoId\"\n        INNER JOIN \"user\" u ON u.id = p.\"userId\" \n        WHERE p.year=".concat(year, " AND p.\"categoryId\"=").concat(catId, "\n        ORDER BY p.gscore DESC");
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    result = _a.sent();
                    for (_i = 0, result_8 = result; _i < result_8.length; _i++) {
                        row = result_8[_i];
                        p = new entities_1.AgpaPhoto();
                        p.fromJSON(row);
                        if (photos.has(p.id)) {
                            photos.get(p.id).awards.set(row.awardCategory, row.award);
                        }
                        else {
                            photos.set(p.id, p);
                        }
                        if (!(p.user.id in users)) {
                            category.totalUsers += 1;
                            users.push(p.user.id);
                        }
                    }
                    category.photos = Array.from(photos.values());
                    category.totalPhotos = category.photos.length;
                    return [2 /*return*/, category];
            }
        });
    });
}
exports.archiveCategory = archiveCategory;
