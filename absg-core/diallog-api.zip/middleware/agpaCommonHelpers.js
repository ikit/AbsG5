"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMaxArchiveEdition = exports.getCurrentPhase = exports.getMetaData = exports.initAGPAContext = exports.getPhasesBoundaries = exports.checkValidYear = exports.getCurrentEdition = exports.agpaCtx = void 0;
var date_fns_1 = require("date-fns");
var entities_1 = require("../entities");
var AgpaContext_1 = require("./model/AgpaContext");
var typeorm_1 = require("typeorm");
var AgpaPhase_1 = require("./model/AgpaPhase");
exports.agpaCtx = new AgpaContext_1.AgpaContext();
/**
 * Calcule l'année de l'édition en fonction de la date courante
 * @return l'année de l'édition en cours
 */
function getCurrentEdition() {
    // Une édition commence toujours au 1er octobre pour se terminer fin décembre
    // Mais en fonction du calendrier, peut déborder sur janvier de l'année suivante
    // Donc si on est avant 1er février, il s'agit de l'édition précédente, sinon il s'agit de l'année courante
    var date = new Date();
    var editionYear = date.getFullYear();
    // Si en janvier
    if (date.getMonth() == 0) {
        editionYear--;
    }
    return editionYear;
}
exports.getCurrentEdition = getCurrentEdition;
/**
 * Vérifie que l'année est une année valide pour les AGPA.
 * @param year l'année à tester, retourne l'année de l'édition en cours sinon
 */
function checkValidYear(year, defaultYear) {
    if (defaultYear === void 0) { defaultYear = null; }
    var currentYear = getCurrentEdition();
    if (!Number.isInteger(year) || year < 2006 || year >= currentYear) {
        year = defaultYear ? checkValidYear(defaultYear) : currentYear;
    }
    return year;
}
exports.checkValidYear = checkValidYear;
/**
 * Calcule les phases pour l'édition courante
 * @return la liste des phases
 */
function getPhasesBoundaries() {
    return __awaiter(this, void 0, void 0, function () {
        var repo, phases, startDate, phasesDayDurations, agpaCeremonyStartTime, sql, raw, idx, p;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.Parameter);
                    phases = [];
                    startDate = new Date(getCurrentEdition(), 9, 1, 0, 0, 0);
                    phasesDayDurations = [76, 2, 4, 3, null];
                    agpaCeremonyStartTime = 72000;
                    sql = "SELECT * FROM parameter WHERE key LIKE 'agpa%';";
                    return [4 /*yield*/, repo.query(sql)];
                case 1:
                    raw = _a.sent();
                    if (Array.isArray(raw) && raw.length === 5) {
                        phasesDayDurations[0] = +raw.find(function (e) { return e.key === "agpaPhase1Duration"; }).value;
                        phasesDayDurations[1] = +raw.find(function (e) { return e.key === "agpaPhase2Duration"; }).value;
                        phasesDayDurations[2] = +raw.find(function (e) { return e.key === "agpaPhase3Duration"; }).value;
                        phasesDayDurations[3] = +raw.find(function (e) { return e.key === "agpaPhase4Duration"; }).value;
                        agpaCeremonyStartTime = +raw.find(function (e) { return e.key === "agpaCeremonyStartTime"; }).value;
                    }
                    // Calcul des échéances
                    for (idx = 0; idx < phasesDayDurations.length; idx++) {
                        p = new AgpaPhase_1.AgpaPhase();
                        p.id = idx + 1;
                        p.startDate = new Date(startDate);
                        if (idx <= 2) {
                            startDate = (0, date_fns_1.addDays)(startDate, phasesDayDurations[idx]);
                            p.endDate = new Date(startDate);
                        }
                        else if (idx === 3) {
                            startDate = (0, date_fns_1.addDays)(startDate, phasesDayDurations[idx]);
                            startDate = (0, date_fns_1.addSeconds)(startDate, agpaCeremonyStartTime);
                            p.endDate = new Date(startDate);
                        }
                        else {
                            p.endDate = new Date(startDate.getFullYear() + 1, 8, 31);
                        }
                        phases.push(p);
                    }
                    return [2 /*return*/, phases];
            }
        });
    });
}
exports.getPhasesBoundaries = getPhasesBoundaries;
/**
 * initPhotosData
 * Crée le "contexte" pour une édition des agpa, c'est à dire l'ensemble des données concernant l'édition
 *
 * @param date, la date à prendre en compte pour l'édition
 * @return le "contexte"
 */
function initAGPAContext(date) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, exports.agpaCtx.checkForReset(date.getFullYear())];
        });
    });
}
exports.initAGPAContext = initAGPAContext;
/**
 * getMetaData
 * Récupère toutes les informations concernant une édition
 *
 * @return
 */
function getMetaData(year, force) {
    if (year === void 0) { year = null; }
    if (force === void 0) { force = false; }
    return __awaiter(this, void 0, void 0, function () {
        var repo, currentYear, data, date, _i, _a, p, sql, result, _b, result_1, row, _c, result_2, row;
        var _d;
        return __generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    currentYear = getCurrentEdition();
                    year = force ? year : checkValidYear(year);
                    _d = {
                        year: year,
                        maxYear: currentYear - 1,
                        minYear: 2006
                    };
                    return [4 /*yield*/, getPhasesBoundaries()];
                case 1:
                    data = (_d.boudaries = _e.sent(),
                        _d.categoriesOrders = [],
                        _d.categories = {},
                        _d.phase = null // La phase en cours
                    ,
                        _d);
                    date = new Date();
                    for (_i = 0, _a = data.boudaries; _i < _a.length; _i++) {
                        p = _a[_i];
                        if (date > p.startDate) {
                            data.phase = p.id;
                        }
                    }
                    sql = "SELECT c.* , v.title as \"vTitle\", v.description as \"vDescription\"\n        FROM agpa_category c\n        LEFT JOIN agpa_category_variation v ON v.id = c.id AND v.year = ".concat(year, "\n        WHERE (c.to IS NULL OR c.to >= ").concat(year, ") AND c.from <= ").concat(year, "\n        ORDER BY c.\"order\"");
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    result = _e.sent();
                    for (_b = 0, result_1 = result; _b < result_1.length; _b++) {
                        row = result_1[_b];
                        if (row.id > 0) {
                            data.categoriesOrders.push(row.id);
                        }
                        data.categories[row.id] = {
                            id: row.id,
                            title: row.id === 8 ? row.vTitle : row.title,
                            description: row.id === 8 ? row.vDescription : row.description,
                            color: row.color,
                            totalUsers: 0,
                            totalPhotos: 0
                        };
                    }
                    sql = "SELECT \"categoryId\", count (*) as \"totalPhotos\", count(distinct(\"userId\")) as \"totalUsers\"\n        FROM agpa_photo\n        WHERE year=".concat(year, " AND \"categoryId\" > 0\n        GROUP BY \"categoryId\"");
                    return [4 /*yield*/, repo.query(sql)];
                case 3:
                    result = _e.sent();
                    for (_c = 0, result_2 = result; _c < result_2.length; _c++) {
                        row = result_2[_c];
                        data.categories[row.categoryId].totalUsers = row.totalUsers;
                        data.categories[row.categoryId].totalPhotos = row.totalPhotos;
                    }
                    return [2 /*return*/, data];
            }
        });
    });
}
exports.getMetaData = getMetaData;
/**
 * Calcule la phase de l'édition en cours
 * @return la phase de l'édition en cours
 */
function getCurrentPhase() {
    exports.agpaCtx.checkForReset();
    return exports.agpaCtx.phase;
}
exports.getCurrentPhase = getCurrentPhase;
/**
 * Calcule l'année de la dernière édition publiable dans les archives
 * Tiens compte de la phase de l'édition courante.
 * @return l'année de la dernière édition
 */
function getMaxArchiveEdition() {
    return getCurrentPhase() < 5 ? getCurrentEdition() - 1 : getCurrentEdition();
}
exports.getMaxArchiveEdition = getMaxArchiveEdition;
