"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.currentUserChecker = exports.jwtAuthorizationChecker = exports.getUserFromHeader = exports.checkUserPassag = exports.MUTEX_PASSAG = exports.setLastActivity = exports.checkRoles = exports.checkToken = exports.createToken = exports.checkPassword = exports.hashPassword = void 0;
var bcrypt = require("bcrypt");
var jwt = require("jsonwebtoken");
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var date_fns_1 = require("date-fns");
var async_mutex_1 = require("async-mutex");
var WebsocketService_1 = require("../services/WebsocketService");
var agpaCommonHelpers_1 = require("./agpaCommonHelpers");
var ACTIONS_LABELS = [
    { route: "/agenda/person", label: "Agenda - Répertoire" },
    { route: "/agenda/place", label: "Agenda - Lieux" },
    { route: "/agenda/trombi", label: "Agenda - Trombinoscope" },
    { route: "/agpa/archives", label: "A.G.P.A. - Archives" },
    { route: "/agpa/ceremony", label: "A.G.P.A. - Cérémonie" },
    { route: "/agpa/palmares", label: "A.G.P.A. - Palmarès" },
    { route: "/agpa/p", label: "A.G.P.A. - Edition " + (0, agpaCommonHelpers_1.getCurrentEdition)() },
    { route: "/agpa/photo", label: "A.G.P.A. - Edition " + (0, agpaCommonHelpers_1.getCurrentEdition)() },
    { route: "/agpa/vote", label: "A.G.P.A. - Edition " + (0, agpaCommonHelpers_1.getCurrentEdition)() },
    { route: "/agpa", label: "A.G.P.A." },
    { route: "/citations", label: "Citations" },
    { route: "/event", label: "Calendrier" },
    { route: "/forum/tbz", label: "Forum - T.B.Z." },
    { route: "/forum", label: "Forum" },
    { route: "/immt", label: "Photos - Image du moment" },
    { route: "/homepage", label: "Accueil Absolument G" },
    { route: "/settings", label: "Paramètres" },
    { route: "/photos", label: "Photos" },
    { route: "/voyag", label: "Voya G" }
];
/**
 * Chiffre un mot de passe
 *
 * @param password le mot de passe en clair
 */
function hashPassword(password) {
    return bcrypt.hash(password, 10);
}
exports.hashPassword = hashPassword;
/**
 * Retourne true si le mot de passe est correct
 *
 * @param cleanPassword le mot de passe en clair
 * @param encryptedPassword le mot de passe chiffré
 */
function checkPassword(cleanPassword, encryptedPassword) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, bcrypt.compare(cleanPassword, encryptedPassword)];
                case 1: return [2 /*return*/, _a.sent()];
            }
        });
    });
}
exports.checkPassword = checkPassword;
/**
 * Génère un token
 *
 * @param user les données de l'utilisateur
 * @param newPwdSession indique si oui ou non il faut créer une "vrai" session ou bien une session de secour de 10 min pour changer son pwd
 */
function createToken(user, newPwdSession) {
    if (newPwdSession === void 0) { newPwdSession = false; }
    if (!user) {
        return null;
    }
    var sessionDuration = newPwdSession ? 600000 : +process.env.AUTH_SESSION_DURATION_MS;
    var payload = {
        id: user.id,
        username: user.username,
        rescue: newPwdSession,
        expiresAt: new Date().getTime() + sessionDuration
    };
    return jwt.sign(payload, process.env.AUTH_SESSION_SALT, {
        expiresIn: sessionDuration / 1000
    });
}
exports.createToken = createToken;
/**
 * Vérifie le contenu du token JWT
 *
 * @param token
 */
function checkToken(token) {
    return jwt.verify(token, process.env.AUTH_SESSION_SALT);
}
exports.checkToken = checkToken;
/**
 * Vérifie que l'utilisateur dispose bien des rôles necessaires
 *
 * @param userRoles
 * @param authorizedRoles
 */
function checkRoles(userRoles, authorizedRoles) {
    return !authorizedRoles.length || !authorizedRoles.some(function (role) { return !userRoles.includes(role); });
}
exports.checkRoles = checkRoles;
/**
 * Met à jours les données de l'utilisateur et retourne l'utilisateur modifié
 * @param url la nouvelle activité à mettre à jour
 * @param urser l'utilisateur à modifier
 */
function setLastActivity(user, url) {
    return __awaiter(this, void 0, void 0, function () {
        var label, notifs, onlineUsers;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    label = ACTIONS_LABELS.find(function (e) { return url.indexOf(e.route) > -1; });
                    label = label ? label.label : null;
                    if (!!user.activity) return [3 /*break*/, 1];
                    user.activity = {
                        lastActionLabel: label ? label : "Accueil Absolument G",
                        lastAction: url,
                        lastAnnounce: 0,
                        unreadNotifications: [] // liste des id des notifications non lues de l'utilisateur
                    };
                    return [3 /*break*/, 3];
                case 1:
                    user.activity.lastActio = url;
                    user.activity.lastActionLabel = label ? label : "Accueil Absolument G";
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.LogSystem).query("\n            SELECT id FROM log_system \n            WHERE severity = 'notice' AND \"userId\" <> $1 AND datetime > $2 \n            ORDER BY id DESC\n            LIMIT 50", [user.id, user.lastTime])];
                case 2:
                    notifs = _a.sent();
                    // On ajoute ces notifs à la liste de celles qu'il n'a pas encore vu
                    user.activity.unreadNotifications = user.activity.unreadNotifications.concat(notifs.map(function (e) { return e.id; }));
                    // On ne garde au maximum que les 50 dernières
                    user.activity.unreadNotifications.sort(function (a, b) { return b - a; });
                    user.activity.unreadNotifications.slice(0, 50);
                    _a.label = 3;
                case 3:
                    user.lastTime = new Date();
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.User).save(user)];
                case 4:
                    _a.sent();
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.LogPassag).query("\n        SELECT id, username, \"rootFamily\", \"lastTime\", activity \n        FROM \"user\" \n        WHERE \"lastTime\" IS NOT NULL AND  \"lastTime\" > now() - INTERVAL '10 min'\n        ORDER BY \"lastTime\" ASC")];
                case 5:
                    onlineUsers = _a.sent();
                    WebsocketService_1.websocketService.broadcast({
                        message: WebsocketService_1.WSMessageType.onlineUsers,
                        payload: onlineUsers.map(function (u) { return (__assign(__assign({}, u), { activity: u.activity ? u.activity.lastActionLabel : "-", unreadNotifications: u.activity.unreadNotifications })); })
                    });
                    return [2 /*return*/, user];
            }
        });
    });
}
exports.setLastActivity = setLastActivity;
/**
 * Met à jour les log de passage concernant l'utilisateur
 * @param user l'utilisateur concerné
 * @param url l'url requêté par l'utilisateur
 */
exports.MUTEX_PASSAG = new async_mutex_1.Mutex();
function checkUserPassag(user, url) {
    return __awaiter(this, void 0, void 0, function () {
        var release, sql, lastLog, log, lastDate, now;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, exports.MUTEX_PASSAG.acquire()];
                case 1:
                    release = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, , 9, 10]);
                    if (!user) return [3 /*break*/, 8];
                    sql = "SELECT l.*, u.username\n                FROM log_passag l\n                INNER JOIN \"user\" u ON u.id = l.\"userId\" \n                WHERE l.\"userId\" = ".concat(user.id, "\n                ORDER BY l.datetime DESC\n                LIMIT 1");
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.LogPassag).query(sql)];
                case 3:
                    lastLog = _a.sent();
                    lastLog = lastLog.length > 0 ? lastLog[0] : null;
                    log = new entities_1.LogPassag();
                    log.datetime = new Date();
                    log.userId = user.id;
                    if (!!lastLog) return [3 /*break*/, 5];
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.LogPassag).save(log)];
                case 4:
                    _a.sent();
                    return [3 /*break*/, 7];
                case 5:
                    lastDate = new Date(lastLog.datetime);
                    now = new Date();
                    if (!((0, date_fns_1.differenceInSeconds)(now, lastDate) > 3600 || now.getHours() != lastDate.getHours())) return [3 /*break*/, 7];
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.LogPassag).save(log)];
                case 6:
                    _a.sent();
                    _a.label = 7;
                case 7:
                    // On met à jour l'info dans de l'utilisateur
                    setLastActivity(user, url);
                    _a.label = 8;
                case 8: return [3 /*break*/, 10];
                case 9:
                    release();
                    return [7 /*endfinally*/];
                case 10: return [2 /*return*/, user];
            }
        });
    });
}
exports.checkUserPassag = checkUserPassag;
function getUserFromHeader(request) {
    return __awaiter(this, void 0, void 0, function () {
        var authorization, token, user;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    authorization = request.headers["authorization"];
                    if (!authorization) {
                        return [2 /*return*/, null];
                    }
                    token = authorization.substring(7);
                    return [4 /*yield*/, (0, typeorm_1.getRepository)(entities_1.User).findOne({
                            where: { token: (0, typeorm_1.Equal)(token) }
                        })];
                case 1:
                    user = _a.sent();
                    return [4 /*yield*/, checkUserPassag(user, request.url)];
                case 2:
                    // On met à jours les stats de passage de l'utilisateur
                    user = _a.sent();
                    return [2 /*return*/, user];
            }
        });
    });
}
exports.getUserFromHeader = getUserFromHeader;
/**
 * Stratégie JWT : on vérifie le token JWT présent dans les headers et est valide
 *
 * @param action action demandée au sein d'un controller
 * @param roles liste des rôles minimum
 * @returns boolean true is the user is authorized
 */
function jwtAuthorizationChecker(action, roles) {
    return __awaiter(this, void 0, void 0, function () {
        var user, isAuthorized;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getUserFromHeader(action.request)];
                case 1:
                    user = _a.sent();
                    try {
                        // on vérifie que le token est valide
                        user = checkToken(user.token);
                        isAuthorized = !!user && user.id && checkRoles([], roles);
                        return [2 /*return*/, isAuthorized];
                    }
                    catch (e) {
                        return [2 /*return*/, false];
                    }
                    return [2 /*return*/];
            }
        });
    });
}
exports.jwtAuthorizationChecker = jwtAuthorizationChecker;
function currentUserChecker(action) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, getUserFromHeader(action.request)];
                case 1: 
                // on retourn le user si il est défini dans le header
                return [2 /*return*/, _a.sent()];
            }
        });
    });
}
exports.currentUserChecker = currentUserChecker;
