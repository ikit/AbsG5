"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.monitoringStats = exports.p4HonorAttribution = exports.p4DiamondAttribution = exports.p4AgpaAttribution = exports.p4ComputeNotes = exports.p4CheckVotes = void 0;
var entities_1 = require("../entities");
var agpaPalmaresHelper_1 = require("./agpaPalmaresHelper");
var typeorm_1 = require("typeorm");
/**
 * Attribution des AGPA (or, argent et bronze) pour une liste de photos donnée
 * La liste des photos doit déjà être triée et ordonnée
 * Cette première passe ne traite pas les AGPA de diamant
 * @param pIds liste des photos
 * @param catId la catégorie concernée
 * @param ctx le context de donnée à mettre à jours
 */
function deliverAwardsPhotos(pIds, catId, ctx) {
    // On vérifie si tout est correctement initialisé
    for (var idx = 0; idx < 4; idx++) {
        if (!ctx.photos[pIds[idx]].awards) {
            ctx.photos[pIds[idx]].awards = [];
        }
    }
    // On attribut simplement les agpa or, diamant et bronze aux 1ere, deuxième et troisième photos
    if (ctx.photos[pIds[0]].userId === ctx.photos[pIds[1]].userId &&
        ctx.photos[pIds[0]].score === ctx.photos[pIds[1]].score) {
        // Test du double agpa d'or
        ctx.photos[pIds[0]].awards.push({ award: entities_1.AgpaAwardType.gold, categoryId: catId });
        ctx.photos[pIds[1]].awards.push({ award: entities_1.AgpaAwardType.gold, categoryId: catId });
        ctx.photos[pIds[2]].awards.push({ award: entities_1.AgpaAwardType.sylver, categoryId: catId });
        ctx.photos[pIds[3]].awards.push({ award: entities_1.AgpaAwardType.bronze, categoryId: catId });
    }
    else {
        ctx.photos[pIds[0]].awards.push({ award: entities_1.AgpaAwardType.gold, categoryId: catId });
        ctx.photos[pIds[1]].awards.push({ award: entities_1.AgpaAwardType.sylver, categoryId: catId });
        ctx.photos[pIds[2]].awards.push({ award: entities_1.AgpaAwardType.bronze, categoryId: catId });
        ctx.photos[pIds[3]].awards.push({ award: entities_1.AgpaAwardType.nominated, categoryId: catId });
    }
    // On met à jour le palmarès (de l'édition) des auteurs
    for (var idx = 0; idx < 4; idx++) {
        var p = ctx.photos[pIds[idx]];
        ctx.users[p.userId].palmares += (0, agpaPalmaresHelper_1.palmaresPoints)(p.awards.find(function (a) { return a.categoryId === catId; }).award);
    }
}
/**
 * Attribution des AGPA (or, argent et bronze) pour une liste de photographes
 * La liste des photographes doit déjà être triée et ordonnée
 * Cette première passe ne traite pas les AGPA de diamant
 * @param pIds liste des photographes
 * @param ctx le context de donnée à mettre à jours
 */
function deliverAwardsPhotographes(pIds, ctx) {
    // On attribut simplement les agpa or, diamant et bronze aux 1er, deuxième et troisième photographes
    ctx.users[pIds[0]].award = entities_1.AgpaAwardType.gold;
    ctx.users[pIds[1]].award = entities_1.AgpaAwardType.sylver;
    ctx.users[pIds[2]].award = entities_1.AgpaAwardType.bronze;
    // On met à jour le palmarès (de l'édition) des auteurs
    for (var idx = 0; idx < 3; idx++) {
        ctx.users[pIds[idx]].palmares += (0, agpaPalmaresHelper_1.palmaresPoints)(ctx.users[pIds[idx]].award);
    }
}
/**
 * vérifie l'intégrité des votes : cohérance aux niveaux des différents identifiants, des années,
 * des catégories, des photos, des auteurs, etc
 * @param ctx le contexte des agpa
 *
 * @return le contexte des agpa avec les données sur les votes pour chaques catégories
 */
function p4CheckVotes(ctx) {
    return __awaiter(this, void 0, void 0, function () {
        var repo, sql, raw, votes, _i, raw_1, v, catId, maxVotePhoto, minVotePhoto, userId, stats, _a, _b, vote;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaVote);
                    sql = "SELECT v.*, p.\"categoryId\" as \"pCategoryId\", p.\"userId\" as \"pUserId\", p.year as \"pYear\", p.title, u.username, a.\"dateOfBirth\" \n        FROM agpa_vote v, agpa_photo p, \"user\" u, person a \n        WHERE v.year=".concat(ctx.year, "\n        AND p.id = v.\"photoId\" \n        AND p.error IS NULL \n        AND v.\"userId\" = u.id \n        AND u.\"personId\" = a.id \n        ORDER BY p.\"categoryId\" ASC, v.\"userId\" ASC, score ASC");
                    return [4 /*yield*/, repo.query(sql)];
                case 1:
                    raw = _c.sent();
                    votes = {};
                    for (_i = 0, raw_1 = raw; _i < raw_1.length; _i++) {
                        v = raw_1[_i];
                        if (!votes[v.categoryId]) {
                            votes[v.categoryId] = {};
                        }
                        if (!votes[v.categoryId][v.userId]) {
                            votes[v.categoryId][v.userId] = [];
                        }
                        votes[v.categoryId][v.userId].push(v);
                    }
                    // Vérification des votes
                    for (catId in votes) {
                        // On ignore les catégories spéciales meilleur auteur et meilleur photo pour l'instant
                        if (!(+catId > 0 || +catId === -3)) {
                            continue;
                        }
                        maxVotePhoto = Math.round(ctx.categories[catId].totalPhotos / 2.0);
                        minVotePhoto = Math.round(maxVotePhoto / 2.0);
                        ctx.categories[catId].maxVotePhoto = maxVotePhoto;
                        ctx.categories[catId].minVotePhoto = minVotePhoto;
                        ctx.categories[catId].votes = [];
                        // Analyse des votes des utilisateurs pour la catégorie en cours
                        for (userId in votes[catId]) {
                            stats = {
                                userId: -1,
                                username: "",
                                age: 0,
                                votesScore: 0,
                                valid: false,
                                errors: {
                                    // La liste des problèmes rencontrés
                                    authorError: false,
                                    categoryError: false,
                                    yearError: false,
                                    votesNumberError: false,
                                    scoreError: false,
                                    childError: false // erreur: trop jeune pour prendre en compte ses votes
                                },
                                votes: [] // la liste des votes de l'utilisateur pour la catégorie
                            };
                            // Pour chacun des votes de l'utilisateur :
                            for (_a = 0, _b = votes[catId][userId]; _a < _b.length; _a++) {
                                vote = _b[_a];
                                stats.votesScore += vote.score;
                                stats.votes.push(vote);
                                stats.userId = vote.userId;
                                stats.username = vote.username;
                                stats.age = ctx.year - vote.dateOfBirth.substr(0, 4);
                                vote.error = false;
                                // Vérification note du vote compris entre 1 et 2 (on accepte les vote zéro utilisé pour le meilleur titre)
                                if (vote.score < 0 || vote.score > 2) {
                                    vote.error = true;
                                    stats.errors.scoreError = true;
                                }
                                // Vérification auteur de la photo (interdit de voter pour ses propres photos)
                                if (vote.pUserId === vote.userId) {
                                    vote.error = true;
                                    stats.errors.authorError = true;
                                }
                                // Vérification catégorie de la photo (categorie du vote doit correspondre à la catégorie de la photo concernée par le vote)
                                if (vote.categoryId != vote.pCategoryId && vote.categoryId != -3) {
                                    vote.error = true;
                                    stats.errors.categoryError = true;
                                }
                                // Vérification année de la photo
                                if (vote.year != vote.pYear) {
                                    vote.error = true;
                                    stats.errors.yearError = true;
                                }
                                // Vérification de l'âge du juré (doit avoir 12 ans pour être pris en compte)
                                if (stats.age < 12) {
                                    stats.errors.childError = true;
                                }
                            }
                            // Est-ce que le juré à donné suffisamment de vote pour être pris en compte
                            if (+catId > 0) {
                                stats.errors.votesNumberError = stats.votesScore < minVotePhoto || stats.votesScore > maxVotePhoto;
                            }
                            else {
                                stats.errors.votesNumberError = votes[catId][userId].length < 5 || votes[catId][userId].length > 10;
                            }
                            // une fois qu'on a analysé tout les vote d'un utilisateur pour une catégorie, on décide si on en tient compte ou pas.
                            stats.valid =
                                !stats.errors.authorError &&
                                    !stats.errors.categoryError &&
                                    !stats.errors.yearError &&
                                    !stats.errors.votesNumberError &&
                                    !stats.errors.scoreError &&
                                    !stats.errors.childError;
                            ctx.categories[catId].votes.push(stats);
                        }
                    }
                    return [2 /*return*/, ctx];
            }
        });
    });
}
exports.p4CheckVotes = p4CheckVotes;
/**
 * Calcul les notes de chaques photos suivant l'algorithme du réglement 2008 des AGPA
 * @param ctx les données retournées lors de l'étape 1 (cf p4CheckVotes)
 *
 * @return le contexte des agpa avec les notes calculées pour chaque photos
 */
function p4ComputeNotes(ctx) {
    return __awaiter(this, void 0, void 0, function () {
        var repo, sql, raw, _i, raw_2, p, catId, userId, _a, _b, vote, scoreCoef, votesCoef, photoId, photo, cat, scoreNote, votesScore;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    sql = "SELECT p.*, u.username FROM agpa_photo p INNER JOIN \"user\" u ON u.id = p.\"userId\" WHERE year=".concat(ctx.year);
                    return [4 /*yield*/, repo.query(sql)];
                case 1:
                    raw = _c.sent();
                    ctx.photos = {};
                    for (_i = 0, raw_2 = raw; _i < raw_2.length; _i++) {
                        p = raw_2[_i];
                        // On garde en mémoire les anciennes valeurs calculées pour comparer si besoin
                        p.formerStats = {
                            votes: p.votes,
                            votesTitle: p.votesTitle,
                            score: p.score,
                            gscore: p.gscore
                        };
                        // On réinitialise les scores
                        p.votes = 0; // Le nombre de vote "étoile" d'utilisateurs différents obtenu
                        p.votesTitle = 0; // Le nombre de vote "plume" d'utilisateurs différents obtenu
                        p.score = 0; // Le score "étoile" total obtenu
                        p.gscore = 0; // Le score calculé
                        p.awards = null; // Les récompenses obtenues
                        ctx.photos[p.id] = p;
                    }
                    // Décompte des votes (passe 1 -> calcul note simple)
                    for (catId in ctx.categories) {
                        // On ignore les catégories spéciales meilleur auteur et meilleur photo pour l'instant
                        if (!(+catId > 0 || +catId === -3)) {
                            continue;
                        }
                        ctx.categories[catId].judgesNumber = 0; // Nombre de jurés dont les votes sont pris en compte dans la catégorie
                        ctx.categories[catId].scoresSum = 0; // Somme total du nombre de points attribués par l'ensemble des jurés dans la catégorie
                        ctx.categories[catId].votesSum = 0; // Somme total du nombre de vote attribués par l'ensemble des jurés dans la catégorie
                        for (userId in ctx.categories[catId].votes) {
                            // Si les votes ne sont pas valides, on les ignores
                            if (!ctx.categories[catId].votes[userId].valid)
                                continue;
                            ctx.categories[catId].judgesNumber += 1;
                            for (_a = 0, _b = ctx.categories[catId].votes[userId].votes; _a < _b.length; _a++) {
                                vote = _b[_a];
                                if (+catId === -3) {
                                    // calculs pour les plumes
                                    ctx.photos[vote.photoId].votesTitle += 1;
                                }
                                else {
                                    // calculs des étoiles
                                    // Décompte pour la photo concernée
                                    ctx.photos[vote.photoId].votes += 1;
                                    ctx.photos[vote.photoId].score += vote.score;
                                    // Décompte total pour la catégorie
                                    ctx.categories[catId].scoresSum += vote.score;
                                    ctx.categories[catId].votesSum += 1;
                                }
                            }
                        }
                    }
                    scoreCoef = 9990.00999001;
                    votesCoef = 9.99000999001;
                    sql = "";
                    for (photoId in ctx.photos) {
                        photo = ctx.photos[photoId];
                        cat = ctx.categories[photo.categoryId];
                        scoreNote = photo.score * (cat.totalPhotos / cat.scoresSum) * scoreCoef;
                        votesScore = photo.votes * (cat.totalPhotos / cat.votesSum) * votesCoef;
                        ctx.photos[photoId].gscore = Math.round(scoreNote + votesScore);
                        sql += "UPDATE agpa_photos SET g_score=".concat(ctx.photos[photoId].gscore, ", votes=").concat(photo.votes, ", score=").concat(photo.score, " WHERE id=").concat(photo.id, ";");
                    }
                    // 3- On trie les photos par ordre decroissant de note globale
                    ctx.photosOrder = Object.values(ctx.photos)
                        .sort(function (a, b) { return b.gscore - a.gscore; })
                        .map(function (e) { return e.id; });
                    return [2 /*return*/, ctx];
            }
        });
    });
}
exports.p4ComputeNotes = p4ComputeNotes;
/**
 * Classe les photos pour toutes les catégories afin d'attribuer les AGPA et établie le palmares
 * @param ctx les données retournées lors de l'étape 2 (cf p4ComputeNotes)
 *
 * @return le contexte des agpa avec les awards obtenu pour chaque photos et utilisateurs
 */
function p4AgpaAttribution(ctx) {
    return __awaiter(this, void 0, void 0, function () {
        // Définition des méthodes pour trier et départager les ex-aequos
        function sortPhotos(aId, bId) {
            var a = ctx.photos[aId];
            var b = ctx.photos[bId];
            // On trie dans l'ordre décroissant
            var res = b.gscore - a.gsscore;
            if (res != 0)
                return res;
            // Si exaquo, photo ayant titre gagne
            res = (b.title != "" ? 1 : 0) - (a.title != "" ? 1 : 0);
            if (res != 0)
                return res;
            // Si exaequo, avantage à la photo appartenant à la categorie la plus importante (en nombre de photo)
            res = ctx.categories[b.categoryId].photosNumber - ctx.categories[a.categoryId].photosNumber;
            if (res != 0)
                return res;
            // Si exaequo, avantage à la photo de l'édition la plus récente
            res = b.year - a.year;
            if (res != 0)
                return res;
            // Si exaequo, avantage au photographe ayant le moins bon palamarès cumulé sur l'ensemble des éditions précédentes
            res = ctx.users[a.userId].formerPalmares - ctx.users[b.userId].formerPalmares;
            if (res != 0)
                return res;
            // Si toujours exaequos, on tire au sort
            res = Math.random();
            return res > 0.5 ? 1 : -1;
        }
        function sortPhotographes(a, b) {
            // On trie dans l'ordre décroissant en fonction de la moyenne des 8 meilleurs photos des photographes
            var res = b.scoreOf8 - a.scoreOf8;
            if (res != 0)
                return res;
            // Si exaequo, avantage au photographe dont la note moyenne sur l'ensemble de ses photos est la plus élevée pour l'édition en cours
            res = b.average - a.average;
            if (res != 0)
                return res;
            // Si exaequo, avantage au photographe dont la plus mauvaise photo a la meilleur note
            res = b.lower - a.lower;
            if (res != 0)
                return res;
            // Si exaequo, avantage au photograhe ayant le meilleur palmarès sur l'édition en cours
            res = ctx.users[b.userId].palmares - ctx.users[a.userId].palmares;
            if (res != 0)
                return res;
            // Si exaequo, avantage au photographe ayant le moins bon palamarès cumulé sur l'ensemble des éditions précédentes
            res = ctx.users[a.userId].formerPalmares - ctx.users[b.userId].formerPalmares;
            if (res != 0)
                return res;
            // Si toujours exaequos, on tire au sort
            res = Math.random();
            return res > 0.5 ? 1 : -1;
        }
        function sortTitles(aId, bId) {
            var a = ctx.photos[aId];
            var b = ctx.photos[bId];
            // On trie dans l'ordre décroissant en fonction du nombre de fois où une photo a été sélectionné pour le meilleur titre
            var res = b.votesTitle - a.votesTitle;
            if (res !== 0)
                return res;
            // Si exaequo, avantage à la photo ayant le plus petit score
            res = b.gscore - a.gscore;
            if (res !== 0)
                return res;
            // Si exaequo, avantage au photograhe ayant le moins bon palmarès sur l'édition en cours
            res = ctx.users[a.userId].palmares - ctx.users[b.userId].palmares;
            if (res !== 0)
                return res;
            // Si exaequo, avantage au photographe ayant le moins bon palamarès cumulé sur l'ensemble des éditions précédentes
            res = ctx.users[a.userId].formerPalmares - ctx.users[b.userId].formerPalmares;
            if (res !== 0)
                return res;
            // Si toujours exaequos, on tire au sort
            res = Math.random();
            return res > 0.5 ? 1 : -1;
        }
        var repo, userData, catNumber, pId, p, photos, _loop_1, uId, sql, raw, _i, raw_3, r, _a, raw_4, p, _loop_2, catId;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    userData = {};
                    catNumber = Object.values(ctx.categories).filter(function (c) { return c.id > 0; }).length;
                    // Intialisation et calcul de différentes infos pour chaque participants de l'édition
                    for (pId in ctx.photos) {
                        p = ctx.photos[pId];
                        if (!(p.userId in userData)) {
                            userData[p.userId] = {
                                id: p.userId,
                                username: p.username,
                                photos: [],
                                scoreOf8: 0,
                                scoreOf4: 0,
                                average: 0,
                                lower: 0,
                                formerPalmares: 0,
                                palmares: 0,
                                age: 0 // L'age de l'utilisateur
                            };
                        }
                        if (userData[p.userId].photos.length < catNumber) {
                            userData[p.userId].photos.push(p);
                            userData[p.userId].scoreOf8 += p.gscore;
                            if (userData[p.userId].photos.length <= 4) {
                                userData[p.userId].scoreOf4 += p.gscore;
                            }
                        }
                    }
                    photos = Object.values(ctx.photos);
                    _loop_1 = function (uId) {
                        var uPhotos = photos.filter(function (p) { return +p.userId === +uId; });
                        var count = uPhotos.length;
                        userData[uId].lower = uPhotos[count - 1].gscore;
                        userData[uId].average = uPhotos.reduce(function (sum, e) { return e.gscore + sum; }, 0) / count;
                    };
                    for (uId in userData) {
                        _loop_1(uId);
                    }
                    sql = "SELECT DISTINCT (p.\"userId\"), a.\"dateOfBirth\" \n        FROM agpa_photo p\n        INNER JOIN \"user\" u ON p.\"userId\" = u.id\n        INNER JOIN person a ON u.\"personId\" = a.id\n        WHERE p.year=".concat(ctx.year);
                    return [4 /*yield*/, repo.query(sql)];
                case 1:
                    raw = _b.sent();
                    for (_i = 0, raw_3 = raw; _i < raw_3.length; _i++) {
                        r = raw_3[_i];
                        userData[r.userId].age = ctx.year - new Date(r.dateOfBirth).getFullYear();
                    }
                    ctx.users = userData;
                    // Calcul des palmares des editions précédentes
                    sql = "SELECT * FROM agpa_award WHERE year < ".concat(ctx.year, " ORDER BY \"userId\" ASC, year ASC");
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    raw = _b.sent();
                    for (_a = 0, raw_4 = raw; _a < raw_4.length; _a++) {
                        p = raw_4[_a];
                        // On ne prend en compte que les palmarès des utilisateurs qui ont participés cette année
                        if (p.userId in ctx.users) {
                            ctx.users[p.userId].formerPalmares += (0, agpaPalmaresHelper_1.palmaresPoints)(p.award);
                        }
                    }
                    _loop_2 = function (catId) {
                        if (+catId < 0)
                            return "continue";
                        ctx.categories[catId].photos = ctx.photosOrder
                            .filter(function (pId) { return ctx.photos[pId].categoryId == catId; })
                            .sort(sortPhotos);
                        deliverAwardsPhotos(ctx.categories[catId].photos, +catId, ctx);
                    };
                    // Palmarès des catégories "simples"
                    // (afin de calculer un premier palmarès de l'édition en cours utilisé pour départager les ex-aequos des catégories spéciales)
                    for (catId in ctx.categories) {
                        _loop_2(catId);
                    }
                    // Palmarès "Meilleur titre" (à partir de 2011)
                    if (ctx.categories[-3]) {
                        ctx.categories[-3].photos = ctx.photosOrder.filter(function (pId) { return ctx.photos[pId].votesTitle > 0; }).sort(sortTitles);
                        if (ctx.categories[-3].photos.length > 0) {
                            deliverAwardsPhotos(ctx.categories[-3].photos, -3, ctx);
                        }
                    }
                    // Palmarès "Meilleur photographie"
                    ctx.photosOrder.sort(sortPhotos);
                    deliverAwardsPhotos(ctx.photosOrder, -2, ctx);
                    // Palmarès "Meilleur photographe"
                    ctx.usersOrder = Object.values(ctx.users)
                        .sort(sortPhotographes)
                        .map(function (u) { return u.id; });
                    deliverAwardsPhotographes(ctx.usersOrder, ctx);
                    return [2 /*return*/, ctx];
            }
        });
    });
}
exports.p4AgpaAttribution = p4AgpaAttribution;
/**
 * Modifie les AGPA d'or en AGPA de diamant si les conditions sont réunis.
 * @param ctx les données retournées lors de l'étape 3 (cf p4AgpaAttribution)
 *
 * @return boolean, vraie si diamant, faux sinon
 */
function p4DiamondAttribution(ctx) {
    return __awaiter(this, void 0, void 0, function () {
        var _loop_3, _i, _a, cat, userId, pId, photo, _b, _c, a;
        return __generator(this, function (_d) {
            _loop_3 = function (cat) {
                // Il faut au moins 2 photos dans la catégorie
                if (cat.photos.length <= 2)
                    return "continue";
                var p1 = ctx.photos[cat.photos[0]];
                var p2 = ctx.photos[cat.photos[1]];
                if (cat.id > 0 && p1.gscore > 2 * p2.gscore && p1.gscore > 50000) {
                    // Catégorie "simple"
                    var idxAward = ctx.photos[cat.photos[0]].awards.findIndex(function (a) { return a.categoryId === cat.id; });
                    ctx.photos[cat.photos[0]].awards[idxAward].award = entities_1.AgpaAwardType.diamond;
                }
                else if (cat.id === -3 && p1.votesTitle > 2 * p2.votesTitle) {
                    // Catégorie "Meilleur titre"
                    var idxAward = ctx.photos[cat.photos[0]].awards.findIndex(function (a) { return a.categoryId === cat.id; });
                    ctx.photos[cat.photos[0]].awards[idxAward].award = entities_1.AgpaAwardType.diamond;
                }
                else if (cat.id === -2) {
                    // Catégorie "Meilleure photo"
                    var isDiamond = p1.awards.find(function (a) { return a.categoryId > 0; });
                    isDiamond = isDiamond ? isDiamond.award === entities_1.AgpaAwardType.diamond : false;
                    var maxJudgesNumber = ctx.categories[p1.categoryId].votes.filter(function (j) { return j.age >= 12; }).length;
                    if (isDiamond && p1.votes >= maxJudgesNumber - 1) {
                        var idxAward = ctx.photos[cat.photos[0]].awards.findIndex(function (a) { return a.categoryId === cat.id; });
                        ctx.photos[cat.photos[0]].awards[idxAward].award = entities_1.AgpaAwardType.diamond;
                    }
                }
                else if (cat.id === -1) {
                    // Catégorie "Meilleur photographe"
                    var p3 = ctx.photos[ctx.categories[-2][2]];
                    var author = p1.userId === p2.userId && p2.userId === p3.userId;
                    var total = p1.gscore + p2.gscore + p3.gscore;
                    if (author && p1.userId === ctx.usersOrder[0] && total >= 100000) {
                        ctx.users[p1.userId].award = entities_1.AgpaAwardType.diamond;
                    }
                }
            };
            // Pour chaque catégories:
            for (_i = 0, _a = ctx.categories; _i < _a.length; _i++) {
                cat = _a[_i];
                _loop_3(cat);
            }
            // On emet à zéros le palmarès de tout le monde
            for (userId in ctx.users) {
                ctx.users[userId].awards = [];
                ctx.users[userId].palmares = 0;
                // On en profite pour compte l'agpa du meilleur photographe
                if (ctx.users[userId].award) {
                    ctx.users[userId].awards.push({ categoryId: -1, award: ctx.users[userId].award });
                    ctx.users[userId].palmares += (0, agpaPalmaresHelper_1.palmaresPoints)(ctx.users[userId].award);
                }
            }
            // On recompte les palmarès photos de chaque personnes
            for (pId in ctx.photos) {
                photo = ctx.photos[pId];
                if (Array.isArray(photo.awards)) {
                    for (_b = 0, _c = photo.awards; _b < _c.length; _b++) {
                        a = _c[_b];
                        ctx.users[photo.userId].awards.push(a);
                        ctx.users[photo.userId].palmares += (0, agpaPalmaresHelper_1.palmaresPoints)(a.award);
                    }
                }
            }
            return [2 /*return*/, ctx];
        });
    });
}
exports.p4DiamondAttribution = p4DiamondAttribution;
/**
 * Attribue les agpa d'honneur aux enfants de moins de 12 ans qui ont participés.
 * @param ctx les données retournées lors de l'étape 4 (cf p4DiamondAttribution)
 */
function p4HonorAttribution(ctx) {
    return __awaiter(this, void 0, void 0, function () {
        var uid, u;
        return __generator(this, function (_a) {
            for (uid in ctx.users) {
                u = ctx.users[uid];
                if (u.age < 12 && (!Array.isArray(u.awards) || u.awards.length === 0)) {
                    u.awards = [
                        {
                            categoryId: u.photos[0].categoryId,
                            userId: u.id,
                            photoId: u.photos[0].id,
                            award: entities_1.AgpaAwardType.honor
                        }
                    ];
                }
            }
            return [2 /*return*/, ctx];
        });
    });
}
exports.p4HonorAttribution = p4HonorAttribution;
/**
 * Calcul les statistiques affichées dans la section "monitoring" de l'édition des agpa
 * @param ctx les données "contexte" de l'édition des agPA
 * @returns
 */
function monitoringStats(ctx) {
    return __awaiter(this, void 0, void 0, function () {
        var repo, users, _i, users_1, u, total, _loop_4, _a, _b, pId, sql, _c;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    return [4 /*yield*/, repo.query('SELECT * from "user"')];
                case 1:
                    users = _d.sent();
                    for (_i = 0, users_1 = users; _i < users_1.length; _i++) {
                        u = users_1[_i];
                        if (!ctx.users[u.id]) {
                            continue;
                        }
                        ctx.users[u.id].rootFamily = u.rootFamily;
                    }
                    total = {
                        catId: 0,
                        name: "Total",
                        total: 0,
                        totalByAge: {
                            adults: 0,
                            childdren: 0
                        },
                        totalByFamilies: {
                            gueudelot: 0,
                            guibert: 0,
                            guyomard: 0
                        }
                    };
                    ctx.photosStats = ctx.categoriesOrders.map(function (e) { return ({
                        catId: e,
                        name: ctx.categories[e].title,
                        total: 0,
                        totalByAge: {
                            adults: 0,
                            childdren: 0
                        },
                        totalByFamilies: {
                            gueudelot: 0,
                            guibert: 0,
                            guyomard: 0
                        }
                    }); });
                    _loop_4 = function (pId) {
                        var p = ctx.photos[pId];
                        var cat = ctx.photosStats.find(function (c) { return c.catId === p.categoryId; });
                        cat.total += 1;
                        total.total += 1;
                        cat.totalByAge[ctx.users[p.userId].age < 12 ? "childdren" : "adults"] += 1;
                        total.totalByAge[ctx.users[p.userId].age < 12 ? "childdren" : "adults"] += 1;
                        cat.totalByFamilies[ctx.users[p.userId].rootFamily] += 1;
                        total.totalByFamilies[ctx.users[p.userId].rootFamily] += 1;
                    };
                    for (_a = 0, _b = Object.keys(ctx.photos); _a < _b.length; _a++) {
                        pId = _b[_a];
                        _loop_4(pId);
                    }
                    ctx.photosStats.push(total);
                    sql = "SELECT u1.username as \"from\", u2.username as \"to\", SUM(v.score)\n        FROM public.agpa_vote v\n        INNER JOIN \"user\" u1 ON v.\"userId\" = u1.id\n        INNER JOIN \"agpa_photo\" p ON p.id = v.\"photoId\"\n        INNER JOIN \"user\" u2 ON p.\"userId\" = u2.id\n        WHERE v.year = ".concat(ctx.year, " AND v.score > 0\n        GROUP BY \"from\", \"to\"");
                    _c = ctx;
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    _c.votesStats = _d.sent();
                    ctx.votesStats = ctx.votesStats.map(function (r) { return [r.from, r.to, +r.sum]; });
                    return [2 /*return*/, ctx];
            }
        });
    });
}
exports.monitoringStats = monitoringStats;
