"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgpaContext = void 0;
var entities_1 = require("../../entities");
var typeorm_1 = require("typeorm");
var agpaCommonHelpers_1 = require("../agpaCommonHelpers");
var AgpaContext = /** @class */ (function () {
    function AgpaContext() {
        this.phase = null;
        this.totalPhotos = 0;
        this.totalAuthors = 0;
        this.lastUpdateRefDate = null; // La date de référence utilisé pour la dernière maj du contexte
    }
    /**
     * Vérifie en fonction de la date courante si les infos du contexte doivent être rafraichient
     * @param refYear, l'année de référence pour le contexte (par défaut prend l'année en cours)
     */
    AgpaContext.prototype.checkForReset = function (refYear) {
        if (refYear === void 0) { refYear = null; }
        return __awaiter(this, void 0, void 0, function () {
            var currentYear, needToRefresh;
            return __generator(this, function (_a) {
                currentYear = refYear ? refYear : (0, agpaCommonHelpers_1.getCurrentEdition)();
                needToRefresh = true;
                // On recalcul le contexte
                if (needToRefresh) {
                    return [2 /*return*/, this.reset(new Date())];
                }
                return [2 /*return*/, agpaCommonHelpers_1.agpaCtx];
            });
        });
    };
    /**
     *
     * @param date
     */
    AgpaContext.prototype.reset = function (date) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, _i, _b, p, repo, sql, result, _c, result_1, row, cat, _d, result_2, row, awards, photo;
            return __generator(this, function (_e) {
                switch (_e.label) {
                    case 0:
                        this.categories = new Map();
                        this.photos = new Map();
                        this.authors = new Map();
                        this.totalPhotos = 0;
                        this.totalAuthors = 0;
                        this.lastUpdateRefDate = date;
                        // On récupère les dates butoires des différentes phases
                        this.editionYear = (0, agpaCommonHelpers_1.getCurrentEdition)();
                        _a = this;
                        return [4 /*yield*/, (0, agpaCommonHelpers_1.getPhasesBoundaries)()];
                    case 1:
                        _a.phases = _e.sent();
                        // On en déduis la phase actuelle pour l'édition en cours
                        for (_i = 0, _b = this.phases; _i < _b.length; _i++) {
                            p = _b[_i];
                            if (date >= p.startDate) {
                                this.phase = p.id;
                            }
                        }
                        repo = (0, typeorm_1.getRepository)(entities_1.AgpaCategory);
                        sql = "SELECT c.*, v.title as \"sTitle\", v.description as \"sDescription\"\n            FROM agpa_category c\n            LEFT JOIN agpa_category_variation v ON c.id = v.id AND v.year=".concat(this.editionYear, "\n            ORDER BY c.order ASC");
                        return [4 /*yield*/, repo.query(sql)];
                    case 2:
                        result = _e.sent();
                        for (_c = 0, result_1 = result; _c < result_1.length; _c++) {
                            row = result_1[_c];
                            cat = new entities_1.AgpaCategory();
                            cat.fromJSON(row);
                            cat.photos = [];
                            cat.nbrPhotos = 0;
                            cat.authors = [];
                            this.categories.set(cat.id, cat);
                        }
                        // On récupère les photos
                        sql = "SELECT p.*, U.username, a.award, a.\"categoryId\" as \"awardCategoryId\"\n            FROM agpa_photo p \n                INNER JOIN \"user\" u ON U.id = p.\"userId\" \n                LEFT JOIN agpa_award a ON a.\"photoId\" = p.id \n            WHERE p.year=".concat(this.editionYear, "\n            ORDER BY p.\"categoryId\" ASC, p.gscore DESC, p.number ASC");
                        return [4 /*yield*/, repo.query(sql)];
                    case 3:
                        // On récupère les données
                        result = _e.sent();
                        for (_d = 0, result_2 = result; _d < result_2.length; _d++) {
                            row = result_2[_d];
                            // On vérifie que la photo n'est pas déjà enregistré (peux arriver si la photo à plusieurs award (Agpa bronze + meilleur titre par exemple)
                            if (!this.photos.has(row.id)) {
                                // On augmente le nombre de photo inscrite dans la catégorie concernée
                                this.categories.get(row.categoryId).photos.push(row.id);
                                this.categories.get(row.categoryId).nbrPhotos++;
                                this.totalPhotos++;
                                // On ajoute l'autheur si il ne l'a pas déjà été
                                if (!this.authors.has(row.userId)) {
                                    this.authors.set(row.userId, row.username);
                                    this.totalAuthors++;
                                }
                                awards = new Map();
                                if (row.award != null) {
                                    awards.set(row.awardCategoryId, row.award);
                                }
                                photo = new entities_1.AgpaPhoto();
                                photo.fromJSON(row);
                                photo.awards = awards;
                                this.photos.set(photo.id, photo);
                            }
                            else {
                                // on ajoute l'award
                                this.photos.get(row.id).awards.set(row.awardCategoryId, row.award);
                            }
                        }
                        return [2 /*return*/, this];
                }
            });
        });
    };
    return AgpaContext;
}());
exports.AgpaContext = AgpaContext;
