"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgpaPalmares = void 0;
var agpaPalmaresHelper_1 = require("../agpaPalmaresHelper");
/**
 * Décris une entrée de palmarès pour un user donnée
 */
var AgpaPalmares = /** @class */ (function () {
    function AgpaPalmares(userId, from, to) {
        this.userId = userId;
        this.from = from;
        this.to = to;
        this.awards = { total: 0, diamond: 0, gold: 0, sylver: 0, bronze: 0, nominated: 0, honor: 0 };
        this.totalPoints = 0;
        this.statsByCategories = [];
        this.statsByYears = [];
        this.bestCat = null;
        this.bestYear = null;
    }
    // Ajoute un award au palmares et met à jours les stats
    AgpaPalmares.prototype.addAward = function (award) {
        if (award.userId === this.userId && award.year >= this.from && award.year <= this.to) {
            var cat = this.statsByCategories.find(function (e) { return e.id === award.categoryId; });
            if (!cat) {
                cat = {
                    id: award.categoryId,
                    title: award.catTitle,
                    order: award.order,
                    stats: [0, 0, 0, 0, 0, 0, 0] // nominated, bronze, sylver, gold, diamond, totalAgpa, totalPoints
                };
                this.statsByCategories.push(cat);
            }
            var year = this.statsByYears.find(function (e) { return e.year === award.year; });
            if (!year) {
                year = {
                    year: award.year,
                    stats: [0, 0, 0, 0, 0, 0, 0, 0] // honor, nominated, bronze, sylver, gold, diamond, totalAgpa, totalPoints
                };
                this.statsByYears.push(year);
            }
            switch (award.award) {
                case "honor":
                    this.awards.honor += 1;
                    year.stats.splice(0, 1, year.stats[0] + 1);
                    break;
                case "nominated":
                    cat.stats.splice(0, 1, cat.stats[0] + 1);
                    year.stats.splice(1, 1, year.stats[1] + 1);
                    this.awards.nominated += 1;
                    break;
                case "bronze":
                    cat.stats.splice(1, 1, cat.stats[1] + 1);
                    cat.stats.splice(5, 1, cat.stats[5] + 1);
                    cat.stats.splice(6, 1, cat.stats[6] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    year.stats.splice(2, 1, year.stats[2] + 1);
                    year.stats.splice(6, 1, year.stats[6] + 1);
                    year.stats.splice(7, 1, year.stats[7] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    this.awards.bronze += 1;
                    this.awards.total += 1;
                    break;
                case "sylver":
                    cat.stats.splice(2, 1, cat.stats[2] + 1);
                    cat.stats.splice(5, 1, cat.stats[5] + 1);
                    cat.stats.splice(6, 1, cat.stats[6] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    year.stats.splice(3, 1, year.stats[3] + 1);
                    year.stats.splice(6, 1, year.stats[6] + 1);
                    year.stats.splice(7, 1, year.stats[7] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    this.awards.sylver += 1;
                    this.awards.total += 1;
                    break;
                case "gold":
                    cat.stats.splice(3, 1, cat.stats[3] + 1);
                    cat.stats.splice(5, 1, cat.stats[5] + 1);
                    cat.stats.splice(6, 1, cat.stats[6] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    year.stats.splice(4, 1, year.stats[4] + 1);
                    year.stats.splice(6, 1, year.stats[6] + 1);
                    year.stats.splice(7, 1, year.stats[7] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    this.awards.gold += 1;
                    this.awards.total += 1;
                    break;
                case "diamond":
                    cat.stats.splice(4, 1, cat.stats[4] + 1);
                    cat.stats.splice(5, 1, cat.stats[5] + 1);
                    cat.stats.splice(6, 1, cat.stats[6] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    year.stats.splice(5, 1, year.stats[5] + 1);
                    year.stats.splice(6, 1, year.stats[6] + 1);
                    year.stats.splice(7, 1, year.stats[7] + (0, agpaPalmaresHelper_1.palmaresPoints)(award.award));
                    this.awards.diamond += 1;
                    this.awards.total += 1;
                    break;
            }
            this.awards.total += ["nominated", "honor"].find(function (e) { return e === award.award; }) ? 0 : 1;
            this.totalPoints += (0, agpaPalmaresHelper_1.palmaresPoints)(award.award);
            // On récupère la meilleure année/catégorie pour le jouruer
            this.statsByYears.sort(function (a, b) { return b.stats[7] - a.stats[7]; });
            this.statsByCategories.sort(function (a, b) { return b.stats[6] - a.stats[6]; });
            this.bestYear = this.statsByYears[0];
            this.bestCat = this.statsByCategories[0];
        }
    };
    return AgpaPalmares;
}());
exports.AgpaPalmares = AgpaPalmares;
