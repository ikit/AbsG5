"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgpaPhase = void 0;
var AgpaPhase = /** @class */ (function () {
    function AgpaPhase() {
    }
    AgpaPhase.factory = function (id, startDate) {
        var result = new AgpaPhase();
        result.id = id;
        result.startDate = startDate;
        return result;
    };
    return AgpaPhase;
}());
exports.AgpaPhase = AgpaPhase;
