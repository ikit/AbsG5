"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.palmaresData = exports.palmaresPoints = void 0;
var typeorm_1 = require("typeorm");
var entities_1 = require("../entities");
var agpaCommonHelpers_1 = require("./agpaCommonHelpers");
var AgpaPalmares_1 = require("./model/AgpaPalmares");
// // PALMARES -----------------------------------------------------------------------------------------------------------------------------------------
// /**
//  * buildPalmaresMenu
//  * Construit la requête sql qui permettra de récupérer les infos palmarès a afficher en fonction des filtres
//  *
//  * @param $ctx [array], le contexte avec toutes les infos nécessaire.
//  * @param $feature 	[string]
//  * @param user  [dynamic]	si int : user_id (0 = current user)
//  *			 		si string : { 'gueudelot', 'guyomard', 'guibert'}
//  * @param year	[int]		si int : year (0 = all)
//  *
//  *
//  * @return [array]
//  */
// if ( ! function_exists('buildPalmaresMenu'))
// {
//     function buildPalmaresMenu(&$ctx, $feature, user, year )
//     {
//         $CI = get_instance();
// 		$menu = array(
// 			'features' => array(
// 				'ranking' => 'Classement',
// 				'palmares' => 'Palmares'
// 			),
// 			'select' => array(
// 				'features'=> $feature,
// 				'userFilter' => user,
// 				'yearFilter' => year
// 			)
// 		);
// 		// On construit le menu user
// 		$members = array();
// 		foreach($ctx['members'] as $member)
// 		{
// 			if (!empty($member->rootfamilly))
// 			{
// 				$members[$member->rootfamilly][$member->user_id] = $member->username;
// 			}
// 		}
// 		asort($members['gueudelot']);
// 		asort($members['guibert']);
// 		asort($members['guyomard']);
// 		$menu['userFilter'] = $members;
// 		// On construit les années
// 		$menu['yearFilter'] = array(0=> 'Global');
// 		// On détermine la date limite
// 		$maxYear = date("Y");
// 		if ($ctx['current_phase'] <= 4) $maxYear--;
// 		for($i=$maxYear; $i>= 2006; $i--)
// 		{
// 			$menu['yearFilter'][$i] = $i;
// 		}
// 		return $menu;
//     }
// }
/**
 * Retourne le nombre de point palmares correspondant à une récompense
 * @param award, le type de l'award (lice, bronze, argent, or, diamant)
 * @return la valeur en point
 */
function palmaresPoints(award) {
    switch (award) {
        case entities_1.AgpaAwardType.diamond:
            return 5;
        case entities_1.AgpaAwardType.gold:
            return 4;
        case entities_1.AgpaAwardType.sylver:
            return 3;
        case entities_1.AgpaAwardType.bronze:
            return 2;
        case entities_1.AgpaAwardType.nominated:
            return 1;
    }
    return 0;
}
exports.palmaresPoints = palmaresPoints;
/**
 * Récupère l'ensemble des données palmares pour une période demandé
 * @param from  première année prise en compte (par défaut 2006)
 * @param to  dernière année à prendre en compte (par défaut l'année de la dernière édition terminée)
 */
function palmaresData(from, to) {
    if (from === void 0) { from = null; }
    if (to === void 0) { to = null; }
    return __awaiter(this, void 0, void 0, function () {
        var repo, sql, result, tmp, _i, result_1, a, k, participation, _loop_1, _a, participation_1, row;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    from = (0, agpaCommonHelpers_1.checkValidYear)(from, 2006);
                    to = (0, agpaCommonHelpers_1.checkValidYear)(to, (0, agpaCommonHelpers_1.getMaxArchiveEdition)());
                    repo = (0, typeorm_1.getRepository)(entities_1.AgpaPhoto);
                    sql = "SELECT a.year, a.award, a.\"photoId\", a.\"categoryId\", c.title as \"catTitle\", c.order, c.color, p.title, p.filename, a.\"userId\", u.username, u.\"rootFamily\"\n        FROM agpa_award a\n        INNER JOIN agpa_category c ON a.\"categoryId\" = c.id\n        INNER JOIN public.\"user\" u ON a.\"userId\" = u.id\n        INNER JOIN person up ON u.\"personId\" = up.id\n        LEFT JOIN agpa_photo p ON a.\"photoId\" = p.id \n        ORDER BY a.\"categoryId\" ASC, a.year ASC";
                    return [4 /*yield*/, repo.query(sql)];
                case 1:
                    result = _b.sent();
                    tmp = new Map();
                    for (_i = 0, result_1 = result; _i < result_1.length; _i++) {
                        a = result_1[_i];
                        if (a.userId in tmp) {
                            tmp[a.userId].addAward(a);
                        }
                        else {
                            tmp[a.userId] = new AgpaPalmares_1.AgpaPalmares(a.userId, from, to);
                            tmp[a.userId].username = a.username;
                            tmp[a.userId].rootFamily = a.rootFamily;
                            tmp[a.userId].addAward(a);
                        }
                    }
                    // On reforme sous forme de liste le palmarès
                    result = [];
                    for (k in tmp) {
                        result.push(tmp[k]);
                    }
                    // On trie par ordre décroissant
                    result.sort(function (a, b) {
                        return b.totalPoints - a.totalPoints;
                    });
                    // On récupère la participation de chaque photographe
                    sql = "SELECT \"userId\", COUNT(DISTINCT(year)) as total, MIN(year) as first, MAX(year) as last\n        FROM agpa_photo GROUP BY \"userId\"";
                    return [4 /*yield*/, repo.query(sql)];
                case 2:
                    participation = _b.sent();
                    _loop_1 = function (row) {
                        var item = result.find(function (e) { return e.userId === row.userId; });
                        if (item) {
                            item.participation = { total: row.total, first: row.first, last: row.last };
                        }
                    };
                    for (_a = 0, participation_1 = participation; _a < participation_1.length; _a++) {
                        row = participation_1[_a];
                        _loop_1(row);
                    }
                    return [2 /*return*/, result];
            }
        });
    });
}
exports.palmaresData = palmaresData;
